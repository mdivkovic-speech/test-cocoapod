#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SLCLAttachmentEntity, SLCLRuntimeQuery<__covariant RowType>, SLCLDictationEntity, SLCLQueuedDictationEntity, SLCLSpeechLiveDbCompanion, SLCLUserEntity, SLCLSetting, SLCLMultipleChoiceOption, SLCLSettingsPresenterCompanion, SLCLDefaultGetHelpUrlCompanion, SLCLDefaultAppSettingsCompanion, SLCLSettingType, SLCLSettingData, SLCLSettingDataBooleanData, SLCLSettingDataFilePath, SLCLSettingDataIntData, SLCLSettingDataMultipleChoice, SLCLSettingDataNone, SLCLKotlinEnumCompanion, SLCLKotlinEnum<E>, SLCLKotlinArray<T>, SLCLAudioFileRecorderMode, SLCLAssignee, SLCLRecorderDoneAction, SLCLDictation, SLCLDictationProperty, SLCLSpeechRecognitionLanguage, SLCLSpeechToTextCommandList, SLCLApiError, SLCLEither<__covariant V, __covariant E>, SLCLKotlinByteArray, SLCLSpeechToTextServiceState, SLCLRecognizedText, SLCLBeginNewRecognitionForDesktopAppMethodCompanion, SLCLBeginNewRecognitionForDesktopAppMethod, SLCLCloseDictationMethodCompanion, SLCLCloseDictationMethod, SLCLCloseDictationReason, SLCLCreateSttSessionResponseCompanion, SLCLCreateSttSessionResponse, SLCLErrorEventCompanion, SLCLErrorEvent, SLCLRecognitionCompletedEvent, SLCLRecognizedTextEventCompanion, SLCLRecognizedTextEvent, SLCLStopRecognitionMethodCompanion, SLCLStopRecognitionMethod, SLCLSttApplicationTypeId, SLCLUploadAudioChunkMethodCompanion, SLCLUploadAudioChunkMethod, SLCLRecognizedTextStability, SLCLSpeechToTextCommand, SLCLSpeechToTextCommandCategory, SLCLCombineRecognizedTextOutput, SLCLAudioSettings, SLCLLoginToSpeechExecEnterpriseOutput, SLCLSpeechExecEnterpriseSettings, SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors, SLCLWriteDictationTranscriptOutput, SLCLGetPreferredLanguageCodeFromSettingsCompanion, SLCLLoginToSpeechExecEnterpriseOutputLicenseNotAvailable, SLCLLoginToSpeechExecEnterpriseOutputNetworkError, SLCLLoginToSpeechExecEnterpriseOutputNoAuthorRoleFound, SLCLLoginToSpeechExecEnterpriseOutputNoUserFound, SLCLLoginToSpeechExecEnterpriseOutputServerError, SLCLUser, SLCLLoginToSpeechExecEnterpriseOutputSuccess, SLCLLoginToSpeechExecEnterpriseOutputUnexpectedError, SLCLLoginToSpeechExecEnterpriseOutputWrongCredentials, SLCLSavePreferredRecorderModeToSettingsCompanion, SLCLWriteDictationTranscriptOutputFileSystemError, SLCLAttachmentFile, SLCLWriteDictationTranscriptOutputSuccess, SLCLWriteDictationTranscriptOutputUnexpectedError, SLCLDefaultUuidFactory, SLCLKotlinNothing, SLCLTextUtils, SLCLAudioFileRecorderAudioInput, SLCLAudioFileRecorderAudioInputFileInput, SLCLAudioFileRecorderAudioInputMicrophoneInput, SLCLAudioFileRecorderCompositionInfo, SLCLAudioFileRecorderModeCompanion, SLCLAudioType, SLCLAudioTypeCompanion, SLCLUnknownAudioFormat, SLCLWavFormatCompanion, SLCLWavFormat, SLCLDefaultFeatureFlagsConfigCompanion, SLCLDefaultMdmConfigCompanion, SLCLApiServerEnvironment, SLCLKotlinThrowable, SLCLClientError, SLCLNetworkConnectivityMonitorConnectionType, SLCLNetworkError, SLCLServerError, SLCLUnexpectedError, SLCLJsonWebToken, SLCLSignalRConnectionState, SLCLKtor_client_coreHttpClient, SLCLDatabaseDefinition, SLCLLogLevel, SLCLRotatingFileLogWriterCompanion, SLCLTimestampedLogFormatterCompanion, SLCLService, SLCLAttachment, SLCLCheckImageAttachmentLimitOutput, SLCLCheckImageAttachmentLimitOutputLimitNotReached, SLCLCheckImageAttachmentLimitOutputLimitReached, SLCLCheckImageAttachmentLimitOutputUserNotAuthenticated, SLCLDictationFileCategory, SLCLCreateAttachmentOutput, SLCLCreateAttachmentOutputFileSystemError, SLCLCreateAttachmentOutputSuccess, SLCLCreateAttachmentOutputUnexpectedError, SLCLDeleteAttachmentOutput, SLCLDeleteAttachmentOutputFileSystemError, SLCLDeleteAttachmentOutputSuccess, SLCLDictationPropertyData, SLCLBooleanData, SLCLDictationPropertyType, SLCLIntData, SLCLMillisecondsUtcData, SLCLPriorityCompanion, SLCLPriority, SLCLPriorityData, SLCLTextData, SLCLPropertySuggestionsCompanion, SLCLPropertySuggestions, SLCLDefaultComponentRegistryCompanion, SLCLAboutPresenterCompanion, SLCLDictationGroup, SLCLPerformAllPendingAppMigrationsCompanion, SLCLGetAuthorAccountsWithEmailAndPasswordOutput, SLCLGetAuthorAccountsWithIdentityTokenOutput, SLCLUpdateMfaStatusOutput, SLCLGetAuthorAccountsWithEmailAndPasswordOutputNetworkError, SLCLGetAuthorAccountsWithEmailAndPasswordOutputNoAuthorRoleFound, SLCLGetAuthorAccountsWithEmailAndPasswordOutputServerError, SLCLGetAuthorAccountsWithEmailAndPasswordOutputSuccess, SLCLGetAuthorAccountsWithEmailAndPasswordOutputUnexpectedError, SLCLGetAuthorAccountsWithIdentityTokenOutputNetworkError, SLCLGetAuthorAccountsWithIdentityTokenOutputNoAuthorRoleFound, SLCLGetAuthorAccountsWithIdentityTokenOutputServerError, SLCLGetAuthorAccountsWithIdentityTokenOutputSuccess, SLCLGetAuthorAccountsWithIdentityTokenOutputUnexpectedError, SLCLLogInUserWithAccountOutput, SLCLLogInUserWithAccountOutputFileSystemError, SLCLLogInUserWithAccountOutputNetworkError, SLCLLogInUserWithAccountOutputServerError, SLCLLogInUserWithAccountOutputSuccess, SLCLLogInUserWithAccountOutputUnexpectedError, SLCLUpdateMfaStatusOutputApiError, SLCLUpdateMfaStatusOutputSuccess, SLCLAzureAppProxyCompanion, SLCLApiEndpoint, SLCLKotlinUnit, SLCLSpeechExecEnterpriseSettingsCompanion, SLCLErrorResponseDtoCompanion, SLCLErrorResponseDto, SLCLTokenRequestDtoCompanion, SLCLTokenRequestDto, SLCLTokenResponseDtoCompanion, SLCLTokenResponseDto, SLCLSpeechLiveIdentityServiceCompanion, SLCLEndpointConfigurationResponseDto, SLCLEndpointConfigurationListResponseDtoCompanion, SLCLEndpointConfigurationListResponseDto, SLCLEndpointConfigurationResponseDtoCompanion, SLCLLoginRequestCompanion, SLCLLoginRequest, SLCLUserAccountDto, SLCLLoginResponseCompanion, SLCLLoginResponse, SLCLLogoutRequestCompanion, SLCLLogoutRequest, SLCLRenewServiceLoginRequestCompanion, SLCLRenewServiceLoginRequest, SLCLRenewServiceLoginResponseCompanion, SLCLRenewServiceLoginResponse, SLCLServiceLoginRequestCompanion, SLCLServiceLoginRequest, SLCLServiceLoginResponseCompanion, SLCLServiceLoginResponse, SLCLUpdateMfaStatusRequestDtoCompanion, SLCLUpdateMfaStatusRequestDto, SLCLUpdateMfaStatusResponseDtoCompanion, SLCLUpdateMfaStatusResponseDto, SLCLUserAccountDtoCompanion, SLCLApiEndpointCompanion, SLCLServiceCompanion, SLCLSubscriptionPackageCompanion, SLCLSubscriptionPackage, SLCLUserRole, SLCLUserRoleCompanion, SLCLDictationListNewItemAction, SLCLDictationState, SLCLSubscriptionAndUserInfo, SLCLSpeechExecEnterpriseUserSettingsDto, SLCLSpeechExecEnterpriseGetDictationsByIdRequestDtoCompanion, SLCLSpeechExecEnterpriseGetDictationsByIdRequestDto, SLCLSpeechKitSrSettingsDto, SLCLSpeechExecEnterpriseUserSettingsDtoCompanion, SLCLSpeechKitLanguageAndTopicDtoCompanion, SLCLSpeechKitLanguageAndTopicDto, SLCLSpeechKitSrSettingsDtoCompanion, SLCLDeleteRequestDtoCompanion, SLCLDeleteRequestDto, SLCLDesktopAppSettingsDtoCompanion, SLCLDesktopAppSettingsDto, SLCLSubscriptionAndUserInfoDtoCompanion, SLCLSubscriptionAndUserInfoDto, SLCLUpdateDictationPropertiesResponseDtoCompanion, SLCLUpdateDictationPropertiesResponseDto, SLCLUpdateDictationStateRequestDtoCompanion, SLCLUpdateDictationStateRequestDto, SLCLChangeRemoteDictationStateOutput, SLCLChangeRemoteDictationStateOutputNetworkError, SLCLChangeRemoteDictationStateOutputServerError, SLCLChangeRemoteDictationStateOutputSuccess, SLCLChangeRemoteDictationStateOutputUnexpectedError, SLCLChangeRemoteDictationStateOutputUserNotAuthenticated, SLCLCheckWorkingCopyHasUnmergedChangesOutput, SLCLCheckWorkingCopyHasUnmergedChangesOutputNo, SLCLCheckWorkingCopyHasUnmergedChangesOutputUnexpectedError, SLCLCheckWorkingCopyHasUnmergedChangesOutputYes, SLCLConvertWorkingCopyToNewDictationOutput, SLCLConvertWorkingCopyToNewDictationOutputFileSystemError, SLCLConvertWorkingCopyToNewDictationOutputSuccess, SLCLCreateDictationOutput, SLCLCreateDictationOutputFileSystemError, SLCLCreateDictationOutputSuccess, SLCLCreateDictationOutputUnexpectedError, SLCLCreateDictationWorkingCopyOutput, SLCLCreateDictationWorkingCopyOutputFileSystemError, SLCLCreateDictationWorkingCopyOutputSuccess, SLCLCreateEmptyAudioFileOutput, SLCLCreateEmptyAudioFileOutputFileSystemError, SLCLCreateEmptyAudioFileOutputSuccess, SLCLDefaultGenerateDictationFileHash, SLCLDeleteDictationOutput, SLCLDeleteLocalDictationDataOutput, SLCLDeleteLocalDictationIfDeletedRemotelyOutput, SLCLDiscardDictationWorkingCopyOutput, SLCLDownloadDictationFilesOutput, SLCLDefaultGenerateAutoIncrementingFileNameCompanion, SLCLKotlinRegex, SLCLGetOriginalDictationFromWorkingCopyOutput, SLCLLoadRemoteDictationsByGroupOutput, SLCLMergeWorkingCopyWithOriginalOutput, SLCLPrepareDictationForOpenOutput, SLCLRenameDictationAudioFileOutput, SLCLSaveAllDictationChangesOutput, SLCLDeleteDictationOutputFileSystemError, SLCLDeleteDictationOutputNetworkError, SLCLDeleteDictationOutputServerError, SLCLDeleteDictationOutputSuccess, SLCLDeleteDictationOutputUnexpectedError, SLCLDeleteDictationOutputUserNotAuthenticated, SLCLDeleteLocalDictationDataOutputFileSystemError, SLCLDeleteLocalDictationDataOutputSuccess, SLCLDeleteLocalDictationIfDeletedRemotelyOutputDeleted, SLCLDeleteLocalDictationIfDeletedRemotelyOutputDeletionNotRequired, SLCLDeleteLocalDictationIfDeletedRemotelyOutputFileSystemError, SLCLDeleteLocalDictationIfDeletedRemotelyOutputNetworkError, SLCLDeleteLocalDictationIfDeletedRemotelyOutputServerError, SLCLDeleteLocalDictationIfDeletedRemotelyOutputUnexpectedError, SLCLDeleteLocalDictationIfDeletedRemotelyOutputUserNotAuthenticated, SLCLDiscardDictationWorkingCopyOutputFileSystemError, SLCLDiscardDictationWorkingCopyOutputSuccess, SLCLDownloadDictationFilesOutputFileSystemError, SLCLDownloadDictationFilesOutputNetworkError, SLCLDownloadDictationFilesOutputServerError, SLCLDownloadDictationFilesOutputSuccess, SLCLDownloadDictationFilesOutputUnexpectedError, SLCLDownloadDictationFilesOutputUserNotAuthenticated, SLCLGetOriginalDictationFromWorkingCopyOutputSuccess, SLCLGetOriginalDictationFromWorkingCopyOutputUnexpectedError, SLCLLoadRemoteDictationsByGroupOutputNetworkError, SLCLLoadRemoteDictationsByGroupOutputServerError, SLCLLoadRemoteDictationsByGroupOutputSuccess, SLCLLoadRemoteDictationsByGroupOutputUnexpectedError, SLCLLoadRemoteDictationsByGroupOutputUserNotAuthenticated, SLCLMergeWorkingCopyWithOriginalOutputFileSystemError, SLCLMergeWorkingCopyWithOriginalOutputSuccess, SLCLMergeWorkingCopyWithOriginalOutputUnexpectedError, SLCLPrepareDictationForOpenOutputDictationUploading, SLCLPrepareDictationForOpenOutputFileSystemError, SLCLPrepareDictationForOpenOutputReadOnlyDueToDownloadError, SLCLPrepareDictationForOpenOutputReadOnlyDueToRemoteLocking, SLCLPrepareDictationForOpenOutputReadWrite, SLCLPrepareDictationForOpenOutputRecoveredWorkingCopy, SLCLPrepareDictationForOpenOutputUnavailable, SLCLPrepareDictationForOpenOutputUnexpectedError, SLCLPrepareDictationForOpenOutputUserNotAuthenticated, SLCLRenameDictationAudioFileOutputFileSystemError, SLCLRenameDictationAudioFileOutputSuccess, SLCLRenameDictationAudioFileOutputUnexpectedError, SLCLSaveAllDictationChangesOutputAssigningToTranscriptionistFailed, SLCLSaveAllDictationChangesOutputChangesSavedToNewDictation, SLCLSaveAllDictationChangesOutputFileSystemError, SLCLSaveAllDictationChangesOutputSavedAndUploaded, SLCLSaveAllDictationChangesOutputSavedLocally, SLCLSaveAllDictationChangesOutputSendingToSpeechRecognitionFailed, SLCLSaveAllDictationChangesOutputSendingToTranscriptionServiceFailed, SLCLSaveAllDictationChangesOutputUnexpectedError, SLCLSpeechExecEnterpriseDictationApi, SLCLDefaultGetSupportedOfflineSpeechRecognitionLanguages, SLCLUploadNewDictationOutput, SLCLSpeechExecEnterpriseUploadNewDictationUploadDictationErrors, SLCLUploadNewDictationOutputApiError, SLCLUploadNewDictationOutputFileSystemError, SLCLUploadNewDictationOutputSuccess, SLCLUploadNewDictationOutputUnexpectedError, SLCLUploadNewDictationOutputUserNotAuthenticated, SLCLQueuedDictation, SLCLUploadState, SLCLAssignRequestDtoCompanion, SLCLAssignRequestDto, SLCLAssigneeType, SLCLAssigneeTypeCompanion, SLCLDictationFileCategoryCompanion, SLCLDictationGroupCompanion, SLCLDictationStateCompanion, SLCLUploadStateCompanion, SLCLKotlinStringBuilder, SLCLKotlinCharArray, SLCLKotlinx_coroutines_coreCoroutineDispatcher, SLCLRuntimeTransacterTransaction, SLCLKotlinException, SLCLKotlinRuntimeException, SLCLKotlinIllegalStateException, SLCLKotlinByteIterator, SLCLKotlinCancellationException, SLCLKtor_client_coreHttpClientEngineConfig, SLCLKtor_client_coreHttpClientConfig<T>, SLCLKtor_eventsEvents, SLCLKtor_client_coreHttpReceivePipeline, SLCLKtor_client_coreHttpRequestPipeline, SLCLKtor_client_coreHttpResponsePipeline, SLCLKtor_client_coreHttpSendPipeline, SLCLKtor_client_coreHttpRequestData, SLCLKtor_client_coreHttpResponseData, SLCLKotlinRegexOption, SLCLKotlinRegexCompanion, SLCLKotlinCharIterator, SLCLKotlinAbstractCoroutineContextElement, SLCLKotlinx_coroutines_coreCoroutineDispatcherKey, SLCLKotlinx_serialization_coreSerializersModule, SLCLKotlinx_serialization_coreSerialKind, SLCLKtor_client_coreProxyConfig, SLCLKtor_utilsAttributeKey<T>, SLCLKtor_eventsEventDefinition<T>, SLCLKtor_utilsPipelinePhase, SLCLKtor_utilsPipeline<TSubject, TContext>, SLCLKtor_client_coreHttpReceivePipelinePhases, SLCLKtor_client_coreHttpResponse, SLCLKtor_client_coreHttpRequestPipelinePhases, SLCLKtor_client_coreHttpRequestBuilder, SLCLKtor_client_coreHttpResponsePipelinePhases, SLCLKtor_client_coreHttpResponseContainer, SLCLKtor_client_coreHttpClientCall, SLCLKtor_client_coreHttpSendPipelinePhases, SLCLKtor_httpUrl, SLCLKtor_httpHttpMethod, SLCLKtor_httpOutgoingContent, SLCLKtor_httpHttpStatusCode, SLCLKtor_utilsGMTDate, SLCLKtor_httpHttpProtocolVersion, SLCLKotlinMatchResultDestructured, SLCLKotlinIntRange, SLCLKotlinAbstractCoroutineContextKey<B, E>, SLCLKotlinx_coroutines_coreAtomicDesc, SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp, SLCLKtor_httpHeadersBuilder, SLCLKtor_client_coreHttpRequestBuilderCompanion, SLCLKtor_httpURLBuilder, SLCLKtor_utilsTypeInfo, SLCLKtor_client_coreHttpClientCallCompanion, SLCLKtor_httpUrlCompanion, SLCLKtor_httpURLProtocol, SLCLKtor_httpHttpMethodCompanion, SLCLKtor_httpContentType, SLCLKtor_httpHttpStatusCodeCompanion, SLCLKtor_utilsGMTDateCompanion, SLCLKtor_utilsWeekDay, SLCLKtor_utilsMonth, SLCLKtor_httpHttpProtocolVersionCompanion, SLCLKotlinMatchGroup, SLCLKotlinIntProgressionCompanion, SLCLKotlinIntIterator, SLCLKotlinIntProgression, SLCLKotlinIntRangeCompanion, SLCLKotlinx_coroutines_coreAtomicOp<__contravariant T>, SLCLKotlinx_coroutines_coreOpDescriptor, SLCLKotlinx_coroutines_coreLockFreeLinkedListNode, SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc, SLCLKtor_ioMemory, SLCLKtor_ioChunkBuffer, SLCLKtor_ioBuffer, SLCLKtor_ioByteReadPacket, SLCLKtor_utilsStringValuesBuilderImpl, SLCLKtor_httpURLBuilderCompanion, SLCLKtor_httpURLProtocolCompanion, SLCLKtor_httpHeaderValueParam, SLCLKtor_httpHeaderValueWithParametersCompanion, SLCLKtor_httpHeaderValueWithParameters, SLCLKtor_httpContentTypeCompanion, SLCLKtor_utilsWeekDayCompanion, SLCLKtor_utilsMonthCompanion, SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T>, SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T>, SLCLKtor_ioMemoryCompanion, SLCLKtor_ioBufferCompanion, SLCLKtor_ioChunkBufferCompanion, SLCLKtor_ioInputCompanion, SLCLKtor_ioInput, SLCLKtor_ioByteReadPacketCompanion, SLCLKotlinKTypeProjection, SLCLKotlinKVariance, SLCLKotlinKTypeProjectionCompanion;

@protocol SLCLRuntimeTransactionWithoutReturn, SLCLRuntimeTransactionWithReturn, SLCLRuntimeTransacter, SLCLAttachmentQueries, SLCLDictationQueries, SLCLQueuedDictationQueries, SLCLUserQueries, SLCLSpeechLiveDb, SLCLRuntimeSqlDriver, SLCLRuntimeSqlDriverSchema, SLCLBaseView, SLCLLogger, SLCLBasePresenter, SLCLSettingsContractPresenter, SLCLKotlinCoroutineContext, SLCLKotlinx_coroutines_coreCoroutineScope, SLCLPresenterCoroutineScope, SLCLLogOutUser, SLCLGetAvailableSettings, SLCLGetHelpUrl, SLCLApplySetting, SLCLDeleteAllLocalDictationData, SLCLSettingsContractView, SLCLAppSettings, SLCLGetCurrentUser, SLCLDictationApi, SLCLAdminApi, SLCLPropertySuggestionsRepository, SLCLEnvironmentInfo, SLCLDictationRepository, SLCLDeleteLocalDictationData, SLCLSettings, SLCLKotlinComparable, SLCLSpeechToTextServiceListener, SLCLKotlinx_serialization_coreKSerializer, SLCLFile, SLCLCombineRecognizedText, SLCLDecryptFile, SLCLEncryptionProvider, SLCLDirectory, SLCLEncryptFile, SLCLEncryptTempAudio, SLCLDictationFilesRepository, SLCLGetCurrentAudioSettings, SLCLInitializeLanguage, SLCLLoginToSpeechExecEnterprise, SLCLIdentityService, SLCLUserRepository, SLCLKotlinx_coroutines_coreJob, SLCLMonitorRecordingProgress, SLCLAudioFileRecorder, SLCLUpdateDictationOnAudioChange, SLCLTimeProvider, SLCLWriteDictationTranscript, SLCLAttachmentRepository, SLCLCreateAttachment, SLCLGetPreferredLanguageCode, SLCLGetPreferredRecorderMode, SLCLGetRecorderDoneActions, SLCLCheckIfTranscriptionServiceAvailable, SLCLCheckIfSpeechToTextAvailable, SLCLPrepareDictationForSharing, SLCLFileArchiver, SLCLSavePreferredRecorderMode, SLCLSetPreferredLanguageCode, SLCLUuidFactory, SLCLKotlinx_coroutines_coreCoroutineExceptionHandler, SLCLAudioFilePlayerListener, SLCLAudioFilePlayer, SLCLAudioFileRecorderBufferListener, SLCLAudioFileRecorderListener, SLCLAudioFormat, SLCLFeatureFlagsConfig, SLCLConfigSource, SLCLMdmConfig, SLCLNetworkConnectivityMonitor, SLCLEndpointConfigStore, SLCLTokenStore, SLCLSignalRConnection, SLCLKtor_client_coreHttpClientEngine, SLCLHttpClientFactory, SLCLAppInfo, SLCLPath, SLCLContentTypeExtractor, SLCLFileSizeFormatter, SLCLPerformAppMigration, SLCLDeleteAppTemporaryFiles, SLCLLogFormatter, SLCLLogWriter, SLCLKotlinx_coroutines_coreFlow, SLCLLogReader, SLCLTimeFormatter, SLCLDictationPropertiesContractPresenter, SLCLApplyDictationPropertyChange, SLCLGetDictationPropertyList, SLCLGetAttachmentFiles, SLCLSortAttachmentFiles, SLCLCheckImageAttachmentLimit, SLCLDeleteAttachment, SLCLDictationPropertiesContractView, SLCLAboutContractPresenter, SLCLApplicationContractPresenter, SLCLDictationListContractPresenter, SLCLPlayerContractPresenter, SLCLRecorderContractPresenter, SLCLSecurityPromptContractPresenter, SLCLSpeechExecEnterpriseLoginContractPresenter, SLCLSpeechLiveLoginContractPresenter, SLCLSpeechToTextRecorderContractPresenter, SLCLStartContractPresenter, SLCLSupportContractPresenter, SLCLErrorReporter, SLCLComponentRegistry, SLCLSettingsFactory, SLCLAudioFileRecorderFactory, SLCLAudioFilePlayerFactory, SLCLBase64Encoder, SLCLHasher, SLCLNetworkConnectivityMonitorFactory, SLCLSignalR, SLCLAnalyticsLogger, SLCLJwtDecoder, SLCLAzureAppProxy, SLCLAzureB2CAuthenticator, SLCLAppcuesClient, SLCLAboutContractView, SLCLCheckIfShouldShowSecurityPrompt, SLCLApplicationContractView, SLCLSecurityPromptContractView, SLCLCheckUserAuthenticated, SLCLDeleteOldDictationFiles, SLCLApplyMdmSettings, SLCLStartContractView, SLCLIdentifyUserForAnalytics, SLCLResetUserForAnalytics, SLCLGetAuthorAccountsWithEmailAndPassword, SLCLGetAuthorAccountsWithIdentityToken, SLCLUpdateMfaStatus, SLCLLogInUserWithAccount, SLCLUserFilesRepository, SLCLGetLogFile, SLCLSupportContractView, SLCLCheckIfAudioFormatSupported, SLCLAddOfflineDictationsToQueue, SLCLAddToUploadQueue, SLCLUploadQueueRepository, SLCLStartUploadingNextAvailableDictation, SLCLGetOriginalDictationFromWorkingCopy, SLCLCreateDictationWorkingCopy, SLCLGetWorkingCopyFromOriginalDictation, SLCLMergeWorkingCopyWithOriginal, SLCLChangeRemoteDictationState, SLCLCheckIfDirectAssignmentForSpeechToTextEnabled, SLCLCheckWorkingCopyHasUnmergedChanges, SLCLConvertWorkingCopyToNewDictation, SLCLGenerateAutoIncrementingFileName, SLCLCreateDictation, SLCLGetDictationAudioFileNamePattern, SLCLCreateEmptyAudioFile, SLCLDecryptAttachments, SLCLDeleteDictation, SLCLDiscardDictationWorkingCopy, SLCLDeleteLocalDictationIfDeletedRemotely, SLCLDownloadDictationFiles, SLCLGenerateDictationFileHash, SLCLGetAvailableAssignees, SLCLGetSupportedOfflineSpeechRecognitionLanguages, SLCLLoadRemoteDictationsByGroup, SLCLFindNewOrUpdatedDictationIds, SLCLSetUploadStateOfDictation, SLCLPrepareDictationForOpen, SLCLGetDictationEditableStates, SLCLRenameDictationAudioFile, SLCLResetDictationUploadQueueState, SLCLSaveAllDictationChanges, SLCLUploadNewDictation, SLCLGetDictationById, SLCLGetDictationListNewItemActions, SLCLUploadingQueueListener, SLCLMonitorPlaybackProgress, SLCLContinuousSeek, SLCLGetDictationAudioFile, SLCLPlayerContractView, SLCLKotlinCharSequence, SLCLKotlinAppendable, SLCLKotlinSuspendFunction0, SLCLRuntimeSqlCursor, SLCLRuntimeQueryListener, SLCLRuntimeTransactionCallbacks, SLCLRuntimeSqlPreparedStatement, SLCLRuntimeCloseable, SLCLKotlinCoroutineContextElement, SLCLKotlinCoroutineContextKey, SLCLKotlinIterator, SLCLKotlinx_serialization_coreEncoder, SLCLKotlinx_serialization_coreSerialDescriptor, SLCLKotlinx_serialization_coreSerializationStrategy, SLCLKotlinx_serialization_coreDecoder, SLCLKotlinx_serialization_coreDeserializationStrategy, SLCLKotlinx_coroutines_coreChildHandle, SLCLKotlinx_coroutines_coreChildJob, SLCLKotlinx_coroutines_coreDisposableHandle, SLCLKotlinSequence, SLCLKotlinx_coroutines_coreSelectClause0, SLCLKtor_ioCloseable, SLCLKtor_client_coreHttpClientEngineCapability, SLCLKtor_utilsAttributes, SLCLKotlinx_coroutines_coreFlowCollector, SLCLKotlinMatchResult, SLCLKotlinFunction, SLCLKotlinContinuation, SLCLKotlinContinuationInterceptor, SLCLKotlinx_coroutines_coreRunnable, SLCLKotlinx_serialization_coreCompositeEncoder, SLCLKotlinAnnotation, SLCLKotlinx_serialization_coreCompositeDecoder, SLCLKotlinx_coroutines_coreParentJob, SLCLKotlinx_coroutines_coreSelectInstance, SLCLKtor_client_coreHttpClientPlugin, SLCLKotlinSuspendFunction2, SLCLKtor_httpHeaders, SLCLKotlinMatchGroupCollection, SLCLKotlinx_serialization_coreSerializersModuleCollector, SLCLKotlinKClass, SLCLKtor_httpHttpMessage, SLCLKtor_ioByteReadChannel, SLCLKtor_httpHttpMessageBuilder, SLCLKtor_client_coreHttpRequest, SLCLKtor_httpParameters, SLCLKotlinMapEntry, SLCLKtor_utilsStringValues, SLCLKotlinIterable, SLCLKotlinCollection, SLCLKotlinClosedRange, SLCLKotlinKDeclarationContainer, SLCLKotlinKAnnotatedElement, SLCLKotlinKClassifier, SLCLKtor_ioReadSession, SLCLKotlinSuspendFunction1, SLCLKtor_utilsStringValuesBuilder, SLCLKtor_httpParametersBuilder, SLCLKotlinKType, SLCLKtor_ioObjectPool;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SLCLBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface SLCLBase (SLCLBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface SLCLMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SLCLMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorSLCLKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface SLCLNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface SLCLByte : SLCLNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface SLCLUByte : SLCLNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface SLCLShort : SLCLNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface SLCLUShort : SLCLNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface SLCLInt : SLCLNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface SLCLUInt : SLCLNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface SLCLLong : SLCLNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface SLCLULong : SLCLNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface SLCLFloat : SLCLNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface SLCLDouble : SLCLNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface SLCLBoolean : SLCLNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AttachmentEntity")))
@interface SLCLAttachmentEntity : SLCLBase
- (instancetype)initWithId:(NSString *)id dictationId:(NSString *)dictationId name:(NSString *)name sizeBytes:(int64_t)sizeBytes originalFileHash:(NSString *)originalFileHash createdMillisecondsUtc:(int64_t)createdMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc mimeType:(NSString *)mimeType categoryId:(NSString *)categoryId createdByUserId:(NSString *)createdByUserId modifiedByUserId:(NSString *)modifiedByUserId originalId:(NSString * _Nullable)originalId __attribute__((swift_name("init(id:dictationId:name:sizeBytes:originalFileHash:createdMillisecondsUtc:uploadedMillisecondsUtc:lastModifiedMillisecondsUtc:mimeType:categoryId:createdByUserId:modifiedByUserId:originalId:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component11 __attribute__((swift_name("component11()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component12 __attribute__((swift_name("component12()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component13 __attribute__((swift_name("component13()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAttachmentEntity *)doCopyId:(NSString *)id dictationId:(NSString *)dictationId name:(NSString *)name sizeBytes:(int64_t)sizeBytes originalFileHash:(NSString *)originalFileHash createdMillisecondsUtc:(int64_t)createdMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc mimeType:(NSString *)mimeType categoryId:(NSString *)categoryId createdByUserId:(NSString *)createdByUserId modifiedByUserId:(NSString *)modifiedByUserId originalId:(NSString * _Nullable)originalId __attribute__((swift_name("doCopy(id:dictationId:name:sizeBytes:originalFileHash:createdMillisecondsUtc:uploadedMillisecondsUtc:lastModifiedMillisecondsUtc:mimeType:categoryId:createdByUserId:modifiedByUserId:originalId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *categoryId __attribute__((swift_name("categoryId")));
@property (readonly) NSString *createdByUserId __attribute__((swift_name("createdByUserId")));
@property (readonly) int64_t createdMillisecondsUtc __attribute__((swift_name("createdMillisecondsUtc")));
@property (readonly) NSString *dictationId __attribute__((swift_name("dictationId")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) NSString *mimeType __attribute__((swift_name("mimeType")));
@property (readonly) NSString *modifiedByUserId __attribute__((swift_name("modifiedByUserId")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *originalFileHash __attribute__((swift_name("originalFileHash")));
@property (readonly) NSString * _Nullable originalId __attribute__((swift_name("originalId")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@property (readonly) int64_t uploadedMillisecondsUtc __attribute__((swift_name("uploadedMillisecondsUtc")));
@end;

__attribute__((swift_name("RuntimeTransacter")))
@protocol SLCLRuntimeTransacter
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<SLCLRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<SLCLRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end;

__attribute__((swift_name("AttachmentQueries")))
@protocol SLCLAttachmentQueries <SLCLRuntimeTransacter>
@required
- (void)deleteByIdId:(NSString *)id __attribute__((swift_name("deleteById(id:)")));
- (SLCLRuntimeQuery<SLCLAttachmentEntity *> *)selectByDictationIdDictationId:(NSString *)dictationId __attribute__((swift_name("selectByDictationId(dictationId:)")));
- (SLCLRuntimeQuery<id> *)selectByDictationIdDictationId:(NSString *)dictationId mapper:(id (^)(NSString *, NSString *, NSString *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString * _Nullable))mapper __attribute__((swift_name("selectByDictationId(dictationId:mapper:)")));
- (SLCLRuntimeQuery<SLCLAttachmentEntity *> *)selectByIdId:(NSString *)id __attribute__((swift_name("selectById(id:)")));
- (SLCLRuntimeQuery<id> *)selectByIdId:(NSString *)id mapper:(id (^)(NSString *, NSString *, NSString *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString * _Nullable))mapper __attribute__((swift_name("selectById(id:mapper:)")));
- (SLCLRuntimeQuery<SLCLAttachmentEntity *> *)selectByOriginalAttachmentIdOriginalId:(NSString * _Nullable)originalId __attribute__((swift_name("selectByOriginalAttachmentId(originalId:)")));
- (SLCLRuntimeQuery<id> *)selectByOriginalAttachmentIdOriginalId:(NSString * _Nullable)originalId mapper:(id (^)(NSString *, NSString *, NSString *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString * _Nullable))mapper __attribute__((swift_name("selectByOriginalAttachmentId(originalId:mapper:)")));
- (SLCLRuntimeQuery<SLCLAttachmentEntity *> *)selectOrderedByLastModifiedDescendingDictationId:(NSString *)dictationId __attribute__((swift_name("selectOrderedByLastModifiedDescending(dictationId:)")));
- (SLCLRuntimeQuery<id> *)selectOrderedByLastModifiedDescendingDictationId:(NSString *)dictationId mapper:(id (^)(NSString *, NSString *, NSString *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString * _Nullable))mapper __attribute__((swift_name("selectOrderedByLastModifiedDescending(dictationId:mapper:)")));
- (void)upsertAttachmentDictationId:(NSString *)dictationId name:(NSString *)name sizeBytes:(int64_t)sizeBytes originalFileHash:(NSString *)originalFileHash createdMillisecondsUtc:(int64_t)createdMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc mimeType:(NSString *)mimeType categoryId:(NSString *)categoryId createdByUserId:(NSString *)createdByUserId modifiedByUserId:(NSString *)modifiedByUserId originalId:(NSString * _Nullable)originalId id:(NSString *)id __attribute__((swift_name("upsertAttachment(dictationId:name:sizeBytes:originalFileHash:createdMillisecondsUtc:uploadedMillisecondsUtc:lastModifiedMillisecondsUtc:mimeType:categoryId:createdByUserId:modifiedByUserId:originalId:id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationEntity")))
@interface SLCLDictationEntity : SLCLBase
- (instancetype)initWithId:(NSString *)id stateId:(int64_t)stateId isArchived:(int64_t)isArchived authorId:(NSString *)authorId authorName:(NSString *)authorName lastModifiedByUserId:(NSString *)lastModifiedByUserId lastModifiedByUserName:(NSString *)lastModifiedByUserName priority:(int64_t)priority hasTranscription:(int64_t)hasTranscription hasAttachments:(int64_t)hasAttachments originalMetadataFileHash:(NSString *)originalMetadataFileHash lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc createdMillisecondsLocal:(int64_t)createdMillisecondsLocal title:(NSString *)title workType:(NSString *)workType category:(NSString *)category comment:(NSString *)comment department:(NSString *)department keyword:(NSString *)keyword dpmBarcode:(NSString *)dpmBarcode custom1:(NSString *)custom1 custom2:(NSString *)custom2 custom3:(NSString *)custom3 custom4:(NSString *)custom4 custom5:(NSString *)custom5 audioFileName:(NSString *)audioFileName durationMilliseconds:(int64_t)durationMilliseconds audioTypeId:(int64_t)audioTypeId audioFormatId:(int64_t)audioFormatId numOfChannels:(int64_t)numOfChannels sampleRate:(int64_t)sampleRate byteRate:(int64_t)byteRate blockAlign:(int64_t)blockAlign bitsPerSample:(int64_t)bitsPerSample originalId:(NSString * _Nullable)originalId assigneeId:(NSString *)assigneeId assigneeName:(NSString *)assigneeName assigneeTypeId:(int64_t)assigneeTypeId dueDateMillisecondsUtc:(int64_t)dueDateMillisecondsUtc __attribute__((swift_name("init(id:stateId:isArchived:authorId:authorName:lastModifiedByUserId:lastModifiedByUserName:priority:hasTranscription:hasAttachments:originalMetadataFileHash:lastModifiedMillisecondsUtc:uploadedMillisecondsUtc:createdMillisecondsLocal:title:workType:category:comment:department:keyword:dpmBarcode:custom1:custom2:custom3:custom4:custom5:audioFileName:durationMilliseconds:audioTypeId:audioFormatId:numOfChannels:sampleRate:byteRate:blockAlign:bitsPerSample:originalId:assigneeId:assigneeName:assigneeTypeId:dueDateMillisecondsUtc:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component11 __attribute__((swift_name("component11()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component12 __attribute__((swift_name("component12()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component13 __attribute__((swift_name("component13()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component14 __attribute__((swift_name("component14()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component15 __attribute__((swift_name("component15()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component16 __attribute__((swift_name("component16()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component17 __attribute__((swift_name("component17()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component18 __attribute__((swift_name("component18()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component19 __attribute__((swift_name("component19()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component20 __attribute__((swift_name("component20()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component21 __attribute__((swift_name("component21()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component22 __attribute__((swift_name("component22()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component23 __attribute__((swift_name("component23()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component24 __attribute__((swift_name("component24()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component25 __attribute__((swift_name("component25()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component26 __attribute__((swift_name("component26()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component27 __attribute__((swift_name("component27()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component28 __attribute__((swift_name("component28()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component29 __attribute__((swift_name("component29()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component30 __attribute__((swift_name("component30()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component31 __attribute__((swift_name("component31()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component32 __attribute__((swift_name("component32()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component33 __attribute__((swift_name("component33()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component34 __attribute__((swift_name("component34()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component35 __attribute__((swift_name("component35()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component36 __attribute__((swift_name("component36()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component37 __attribute__((swift_name("component37()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component38 __attribute__((swift_name("component38()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component39 __attribute__((swift_name("component39()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component40 __attribute__((swift_name("component40()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictationEntity *)doCopyId:(NSString *)id stateId:(int64_t)stateId isArchived:(int64_t)isArchived authorId:(NSString *)authorId authorName:(NSString *)authorName lastModifiedByUserId:(NSString *)lastModifiedByUserId lastModifiedByUserName:(NSString *)lastModifiedByUserName priority:(int64_t)priority hasTranscription:(int64_t)hasTranscription hasAttachments:(int64_t)hasAttachments originalMetadataFileHash:(NSString *)originalMetadataFileHash lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc createdMillisecondsLocal:(int64_t)createdMillisecondsLocal title:(NSString *)title workType:(NSString *)workType category:(NSString *)category comment:(NSString *)comment department:(NSString *)department keyword:(NSString *)keyword dpmBarcode:(NSString *)dpmBarcode custom1:(NSString *)custom1 custom2:(NSString *)custom2 custom3:(NSString *)custom3 custom4:(NSString *)custom4 custom5:(NSString *)custom5 audioFileName:(NSString *)audioFileName durationMilliseconds:(int64_t)durationMilliseconds audioTypeId:(int64_t)audioTypeId audioFormatId:(int64_t)audioFormatId numOfChannels:(int64_t)numOfChannels sampleRate:(int64_t)sampleRate byteRate:(int64_t)byteRate blockAlign:(int64_t)blockAlign bitsPerSample:(int64_t)bitsPerSample originalId:(NSString * _Nullable)originalId assigneeId:(NSString *)assigneeId assigneeName:(NSString *)assigneeName assigneeTypeId:(int64_t)assigneeTypeId dueDateMillisecondsUtc:(int64_t)dueDateMillisecondsUtc __attribute__((swift_name("doCopy(id:stateId:isArchived:authorId:authorName:lastModifiedByUserId:lastModifiedByUserName:priority:hasTranscription:hasAttachments:originalMetadataFileHash:lastModifiedMillisecondsUtc:uploadedMillisecondsUtc:createdMillisecondsLocal:title:workType:category:comment:department:keyword:dpmBarcode:custom1:custom2:custom3:custom4:custom5:audioFileName:durationMilliseconds:audioTypeId:audioFormatId:numOfChannels:sampleRate:byteRate:blockAlign:bitsPerSample:originalId:assigneeId:assigneeName:assigneeTypeId:dueDateMillisecondsUtc:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *assigneeId __attribute__((swift_name("assigneeId")));
@property (readonly) NSString *assigneeName __attribute__((swift_name("assigneeName")));
@property (readonly) int64_t assigneeTypeId __attribute__((swift_name("assigneeTypeId")));
@property (readonly) NSString *audioFileName __attribute__((swift_name("audioFileName")));
@property (readonly) int64_t audioFormatId __attribute__((swift_name("audioFormatId")));
@property (readonly) int64_t audioTypeId __attribute__((swift_name("audioTypeId")));
@property (readonly) NSString *authorId __attribute__((swift_name("authorId")));
@property (readonly) NSString *authorName __attribute__((swift_name("authorName")));
@property (readonly) int64_t bitsPerSample __attribute__((swift_name("bitsPerSample")));
@property (readonly) int64_t blockAlign __attribute__((swift_name("blockAlign")));
@property (readonly) int64_t byteRate __attribute__((swift_name("byteRate")));
@property (readonly) NSString *category __attribute__((swift_name("category")));
@property (readonly) NSString *comment __attribute__((swift_name("comment")));
@property (readonly) int64_t createdMillisecondsLocal __attribute__((swift_name("createdMillisecondsLocal")));
@property (readonly) NSString *custom1 __attribute__((swift_name("custom1")));
@property (readonly) NSString *custom2 __attribute__((swift_name("custom2")));
@property (readonly) NSString *custom3 __attribute__((swift_name("custom3")));
@property (readonly) NSString *custom4 __attribute__((swift_name("custom4")));
@property (readonly) NSString *custom5 __attribute__((swift_name("custom5")));
@property (readonly) NSString *department __attribute__((swift_name("department")));
@property (readonly) NSString *dpmBarcode __attribute__((swift_name("dpmBarcode")));
@property (readonly) int64_t dueDateMillisecondsUtc __attribute__((swift_name("dueDateMillisecondsUtc")));
@property (readonly) int64_t durationMilliseconds __attribute__((swift_name("durationMilliseconds")));
@property (readonly) int64_t hasAttachments __attribute__((swift_name("hasAttachments")));
@property (readonly) int64_t hasTranscription __attribute__((swift_name("hasTranscription")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) int64_t isArchived __attribute__((swift_name("isArchived")));
@property (readonly) NSString *keyword __attribute__((swift_name("keyword")));
@property (readonly) NSString *lastModifiedByUserId __attribute__((swift_name("lastModifiedByUserId")));
@property (readonly) NSString *lastModifiedByUserName __attribute__((swift_name("lastModifiedByUserName")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) int64_t numOfChannels __attribute__((swift_name("numOfChannels")));
@property (readonly) NSString * _Nullable originalId __attribute__((swift_name("originalId")));
@property (readonly) NSString *originalMetadataFileHash __attribute__((swift_name("originalMetadataFileHash")));
@property (readonly) int64_t priority __attribute__((swift_name("priority")));
@property (readonly) int64_t sampleRate __attribute__((swift_name("sampleRate")));
@property (readonly) int64_t stateId __attribute__((swift_name("stateId")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@property (readonly) int64_t uploadedMillisecondsUtc __attribute__((swift_name("uploadedMillisecondsUtc")));
@property (readonly) NSString *workType __attribute__((swift_name("workType")));
@end;

__attribute__((swift_name("DictationQueries")))
@protocol SLCLDictationQueries <SLCLRuntimeTransacter>
@required
- (void)deleteByIdId:(NSString *)id __attribute__((swift_name("deleteById(id:)")));
- (SLCLRuntimeQuery<SLCLDictationEntity *> *)selectAll __attribute__((swift_name("selectAll()")));
- (SLCLRuntimeQuery<id> *)selectAllMapper:(id (^)(NSString *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, NSString * _Nullable, NSString *, NSString *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectAll(mapper:)")));
- (SLCLRuntimeQuery<SLCLDictationEntity *> *)selectByAuthorIdAuthorId:(NSString *)authorId __attribute__((swift_name("selectByAuthorId(authorId:)")));
- (SLCLRuntimeQuery<id> *)selectByAuthorIdAuthorId:(NSString *)authorId mapper:(id (^)(NSString *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, NSString * _Nullable, NSString *, NSString *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectByAuthorId(authorId:mapper:)")));
- (SLCLRuntimeQuery<SLCLDictationEntity *> *)selectByIdId:(NSString *)id __attribute__((swift_name("selectById(id:)")));
- (SLCLRuntimeQuery<id> *)selectByIdId:(NSString *)id mapper_:(id (^)(NSString *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, NSString * _Nullable, NSString *, NSString *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectById(id:mapper_:)")));
- (SLCLRuntimeQuery<SLCLDictationEntity *> *)selectByOriginalIdOriginalId:(NSString * _Nullable)originalId __attribute__((swift_name("selectByOriginalId(originalId:)")));
- (SLCLRuntimeQuery<id> *)selectByOriginalIdOriginalId:(NSString * _Nullable)originalId mapper:(id (^)(NSString *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, NSString * _Nullable, NSString *, NSString *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectByOriginalId(originalId:mapper:)")));
- (SLCLRuntimeQuery<SLCLDictationEntity *> *)selectOrderedByLastModifiedDescendingAuthorId:(NSString *)authorId isArchived:(int64_t)isArchived stateId:(id)stateId offset:(int64_t)offset limit:(int64_t)limit __attribute__((swift_name("selectOrderedByLastModifiedDescending(authorId:isArchived:stateId:offset:limit:)")));
- (SLCLRuntimeQuery<id> *)selectOrderedByLastModifiedDescendingAuthorId:(NSString *)authorId isArchived:(int64_t)isArchived stateId:(id)stateId offset:(int64_t)offset limit:(int64_t)limit mapper:(id (^)(NSString *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, SLCLLong *, NSString * _Nullable, NSString *, NSString *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectOrderedByLastModifiedDescending(authorId:isArchived:stateId:offset:limit:mapper:)")));
- (void)upsertDictationStateId:(int64_t)stateId isArchived:(int64_t)isArchived authorId:(NSString *)authorId authorName:(NSString *)authorName lastModifiedByUserId:(NSString *)lastModifiedByUserId lastModifiedByUserName:(NSString *)lastModifiedByUserName priority:(int64_t)priority hasTranscription:(int64_t)hasTranscription hasAttachments:(int64_t)hasAttachments originalMetadataFileHash:(NSString *)originalMetadataFileHash lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc createdMillisecondsLocal:(int64_t)createdMillisecondsLocal title:(NSString *)title workType:(NSString *)workType category:(NSString *)category comment:(NSString *)comment department:(NSString *)department keyword:(NSString *)keyword dpmBarcode:(NSString *)dpmBarcode custom1:(NSString *)custom1 custom2:(NSString *)custom2 custom3:(NSString *)custom3 custom4:(NSString *)custom4 custom5:(NSString *)custom5 audioFileName:(NSString *)audioFileName durationMilliseconds:(int64_t)durationMilliseconds audioTypeId:(int64_t)audioTypeId audioFormatId:(int64_t)audioFormatId numOfChannels:(int64_t)numOfChannels sampleRate:(int64_t)sampleRate byteRate:(int64_t)byteRate blockAlign:(int64_t)blockAlign bitsPerSample:(int64_t)bitsPerSample originalId:(NSString * _Nullable)originalId assigneeId:(NSString *)assigneeId assigneeName:(NSString *)assigneeName assigneeTypeId:(int64_t)assigneeTypeId dueDateMillisecondsUtc:(int64_t)dueDateMillisecondsUtc id:(NSString *)id __attribute__((swift_name("upsertDictation(stateId:isArchived:authorId:authorName:lastModifiedByUserId:lastModifiedByUserName:priority:hasTranscription:hasAttachments:originalMetadataFileHash:lastModifiedMillisecondsUtc:uploadedMillisecondsUtc:createdMillisecondsLocal:title:workType:category:comment:department:keyword:dpmBarcode:custom1:custom2:custom3:custom4:custom5:audioFileName:durationMilliseconds:audioTypeId:audioFormatId:numOfChannels:sampleRate:byteRate:blockAlign:bitsPerSample:originalId:assigneeId:assigneeName:assigneeTypeId:dueDateMillisecondsUtc:id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QueuedDictationEntity")))
@interface SLCLQueuedDictationEntity : SLCLBase
- (instancetype)initWithDictationId:(NSString *)dictationId targetState:(int64_t)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId uploadState:(int64_t)uploadState retryCount:(int64_t)retryCount createdMillisecondsUtc:(int64_t)createdMillisecondsUtc __attribute__((swift_name("init(dictationId:targetState:speechRecognitionLanguageCode:teamId:uploadState:retryCount:createdMillisecondsUtc:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLQueuedDictationEntity *)doCopyDictationId:(NSString *)dictationId targetState:(int64_t)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId uploadState:(int64_t)uploadState retryCount:(int64_t)retryCount createdMillisecondsUtc:(int64_t)createdMillisecondsUtc __attribute__((swift_name("doCopy(dictationId:targetState:speechRecognitionLanguageCode:teamId:uploadState:retryCount:createdMillisecondsUtc:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t createdMillisecondsUtc __attribute__((swift_name("createdMillisecondsUtc")));
@property (readonly) NSString *dictationId __attribute__((swift_name("dictationId")));
@property (readonly) int64_t retryCount __attribute__((swift_name("retryCount")));
@property (readonly) NSString *speechRecognitionLanguageCode __attribute__((swift_name("speechRecognitionLanguageCode")));
@property (readonly) int64_t targetState __attribute__((swift_name("targetState")));
@property (readonly) NSString * _Nullable teamId __attribute__((swift_name("teamId")));
@property (readonly) int64_t uploadState __attribute__((swift_name("uploadState")));
@end;

__attribute__((swift_name("QueuedDictationQueries")))
@protocol SLCLQueuedDictationQueries <SLCLRuntimeTransacter>
@required
- (void)deleteByDictationIdDictationId:(NSString *)dictationId __attribute__((swift_name("deleteByDictationId(dictationId:)")));
- (SLCLRuntimeQuery<SLCLQueuedDictationEntity *> *)selectAll __attribute__((swift_name("selectAll()")));
- (SLCLRuntimeQuery<id> *)selectAllMapper_:(id (^)(NSString *, SLCLLong *, NSString *, NSString * _Nullable, SLCLLong *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectAll(mapper_:)")));
- (SLCLRuntimeQuery<SLCLQueuedDictationEntity *> *)selectAllOrderedByCreatedDate __attribute__((swift_name("selectAllOrderedByCreatedDate()")));
- (SLCLRuntimeQuery<id> *)selectAllOrderedByCreatedDateMapper:(id (^)(NSString *, SLCLLong *, NSString *, NSString * _Nullable, SLCLLong *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectAllOrderedByCreatedDate(mapper:)")));
- (SLCLRuntimeQuery<SLCLQueuedDictationEntity *> *)selectByDictationIdDictationId:(NSString *)dictationId __attribute__((swift_name("selectByDictationId(dictationId:)")));
- (SLCLRuntimeQuery<id> *)selectByDictationIdDictationId:(NSString *)dictationId mapper_:(id (^)(NSString *, SLCLLong *, NSString *, NSString * _Nullable, SLCLLong *, SLCLLong *, SLCLLong *))mapper __attribute__((swift_name("selectByDictationId(dictationId:mapper_:)")));
- (void)upsertUploadQueueDictationId:(NSString *)dictationId targetState:(int64_t)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId uploadState:(int64_t)uploadState retryCount:(int64_t)retryCount __attribute__((swift_name("upsertUploadQueue(dictationId:targetState:speechRecognitionLanguageCode:teamId:uploadState:retryCount:)")));
@end;

__attribute__((swift_name("SpeechLiveDb")))
@protocol SLCLSpeechLiveDb <SLCLRuntimeTransacter>
@required
@property (readonly) id<SLCLAttachmentQueries> attachmentQueries __attribute__((swift_name("attachmentQueries")));
@property (readonly) id<SLCLDictationQueries> dictationQueries __attribute__((swift_name("dictationQueries")));
@property (readonly) id<SLCLQueuedDictationQueries> queuedDictationQueries __attribute__((swift_name("queuedDictationQueries")));
@property (readonly) id<SLCLUserQueries> userQueries __attribute__((swift_name("userQueries")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechLiveDbCompanion")))
@interface SLCLSpeechLiveDbCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechLiveDbCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLSpeechLiveDb>)invokeDriver:(id<SLCLRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<SLCLRuntimeSqlDriverSchema> Schema __attribute__((swift_name("Schema")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserEntity")))
@interface SLCLUserEntity : SLCLBase
- (instancetype)initWithId:(NSString *)id email:(NSString *)email region:(NSString *)region roleIds:(NSString *)roleIds subscriptionId:(int64_t)subscriptionId subscriptionState:(NSString *)subscriptionState name:(NSString *)name subscriptionPackageId:(NSString *)subscriptionPackageId isTrial:(int64_t)isTrial isCurrent:(int64_t)isCurrent subscriptionName:(NSString *)subscriptionName isMfaRequirementSatisfied:(int64_t)isMfaRequirementSatisfied serviceId:(NSString *)serviceId __attribute__((swift_name("init(id:email:region:roleIds:subscriptionId:subscriptionState:name:subscriptionPackageId:isTrial:isCurrent:subscriptionName:isMfaRequirementSatisfied:serviceId:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component11 __attribute__((swift_name("component11()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component12 __attribute__((swift_name("component12()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component13 __attribute__((swift_name("component13()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUserEntity *)doCopyId:(NSString *)id email:(NSString *)email region:(NSString *)region roleIds:(NSString *)roleIds subscriptionId:(int64_t)subscriptionId subscriptionState:(NSString *)subscriptionState name:(NSString *)name subscriptionPackageId:(NSString *)subscriptionPackageId isTrial:(int64_t)isTrial isCurrent:(int64_t)isCurrent subscriptionName:(NSString *)subscriptionName isMfaRequirementSatisfied:(int64_t)isMfaRequirementSatisfied serviceId:(NSString *)serviceId __attribute__((swift_name("doCopy(id:email:region:roleIds:subscriptionId:subscriptionState:name:subscriptionPackageId:isTrial:isCurrent:subscriptionName:isMfaRequirementSatisfied:serviceId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) int64_t isCurrent __attribute__((swift_name("isCurrent")));
@property (readonly) int64_t isMfaRequirementSatisfied __attribute__((swift_name("isMfaRequirementSatisfied")));
@property (readonly) int64_t isTrial __attribute__((swift_name("isTrial")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *region __attribute__((swift_name("region")));
@property (readonly) NSString *roleIds __attribute__((swift_name("roleIds")));
@property (readonly) NSString *serviceId __attribute__((swift_name("serviceId")));
@property (readonly) int64_t subscriptionId __attribute__((swift_name("subscriptionId")));
@property (readonly) NSString *subscriptionName __attribute__((swift_name("subscriptionName")));
@property (readonly) NSString *subscriptionPackageId __attribute__((swift_name("subscriptionPackageId")));
@property (readonly) NSString *subscriptionState __attribute__((swift_name("subscriptionState")));
@end;

__attribute__((swift_name("UserQueries")))
@protocol SLCLUserQueries <SLCLRuntimeTransacter>
@required
- (void)deleteByIdId:(NSString *)id __attribute__((swift_name("deleteById(id:)")));
- (SLCLRuntimeQuery<SLCLUserEntity *> *)selectAll __attribute__((swift_name("selectAll()")));
- (SLCLRuntimeQuery<id> *)selectAllMapper__:(id (^)(NSString *, NSString *, NSString *, NSString *, SLCLLong *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, NSString *))mapper __attribute__((swift_name("selectAll(mapper__:)")));
- (SLCLRuntimeQuery<SLCLUserEntity *> *)selectByIdId:(NSString *)id __attribute__((swift_name("selectById(id:)")));
- (SLCLRuntimeQuery<id> *)selectByIdId:(NSString *)id mapper__:(id (^)(NSString *, NSString *, NSString *, NSString *, SLCLLong *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, NSString *))mapper __attribute__((swift_name("selectById(id:mapper__:)")));
- (SLCLRuntimeQuery<SLCLUserEntity *> *)selectCurrent __attribute__((swift_name("selectCurrent()")));
- (SLCLRuntimeQuery<id> *)selectCurrentMapper:(id (^)(NSString *, NSString *, NSString *, NSString *, SLCLLong *, NSString *, NSString *, NSString *, SLCLLong *, SLCLLong *, NSString *, SLCLLong *, NSString *))mapper __attribute__((swift_name("selectCurrent(mapper:)")));
- (void)updateCurrentIsCurrent:(int64_t)isCurrent id:(NSString *)id __attribute__((swift_name("updateCurrent(isCurrent:id:)")));
- (void)upsertUserId:(NSString *)id email:(NSString *)email region:(NSString *)region roleIds:(NSString *)roleIds subscriptionId:(int64_t)subscriptionId subscriptionState:(NSString *)subscriptionState name:(NSString *)name subscriptionPackageId:(NSString *)subscriptionPackageId isTrial:(int64_t)isTrial isCurrent:(int64_t)isCurrent subscriptionName:(NSString *)subscriptionName isMfaRequirementSatisfied:(int64_t)isMfaRequirementSatisfied serviceId:(NSString *)serviceId __attribute__((swift_name("upsertUser(id:email:region:roleIds:subscriptionId:subscriptionState:name:subscriptionPackageId:isTrial:isCurrent:subscriptionName:isMfaRequirementSatisfied:serviceId:)")));
@end;

__attribute__((swift_name("SettingsContract")))
@protocol SLCLSettingsContract
@required
@end;

__attribute__((swift_name("BasePresenter")))
@protocol SLCLBasePresenter
@required
- (void)attachViewView:(id<SLCLBaseView>)view __attribute__((swift_name("attachView(view:)")));
- (void)detachView __attribute__((swift_name("detachView()")));
- (void)onAttachViewView:(id<SLCLBaseView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onFocus __attribute__((swift_name("onFocus()")));
- (void)onFocusLost __attribute__((swift_name("onFocusLost()")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLBaseView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("SettingsContractPresenter")))
@protocol SLCLSettingsContractPresenter <SLCLBasePresenter>
@required
- (void)onCloseClick __attribute__((swift_name("onCloseClick()")));
- (void)onDeleteLocalDictationDataWarningAccepted __attribute__((swift_name("onDeleteLocalDictationDataWarningAccepted()")));
- (void)onFilePathSelectedSetting:(SLCLSetting *)setting newValue:(NSString *)newValue __attribute__((swift_name("onFilePathSelected(setting:newValue:)")));
- (void)onIntValueEnteredSetting:(SLCLSetting *)setting newValue:(int32_t)newValue __attribute__((swift_name("onIntValueEntered(setting:newValue:)")));
- (void)onMultipleChoiceOptionSelectedSetting:(SLCLSetting *)setting option:(SLCLMultipleChoiceOption * _Nullable)option __attribute__((swift_name("onMultipleChoiceOptionSelected(setting:option:)")));
- (void)onSettingClickSetting:(SLCLSetting *)setting __attribute__((swift_name("onSettingClick(setting:)")));
- (void)onSettingToggledSetting:(SLCLSetting *)setting newValue:(BOOL)newValue __attribute__((swift_name("onSettingToggled(setting:newValue:)")));
@end;

__attribute__((swift_name("BaseView")))
@protocol SLCLBaseView
@required
@end;

__attribute__((swift_name("SettingsContractView")))
@protocol SLCLSettingsContractView <SLCLBaseView>
@required
- (void)close __attribute__((swift_name("close()")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)openUrlUrl:(NSString *)url __attribute__((swift_name("openUrl(url:)")));
- (void)restartApp __attribute__((swift_name("restartApp()")));
- (void)showDeleteLocalDictationDataWarning __attribute__((swift_name("showDeleteLocalDictationDataWarning()")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showSettingInNewScreenSetting:(SLCLSetting *)setting __attribute__((swift_name("showSettingInNewScreen(setting:)")));
- (void)showSettingsSettings:(NSArray<SLCLSetting *> *)settings __attribute__((swift_name("showSettings(settings:)")));
- (void)showSuccessMessage __attribute__((swift_name("showSuccessMessage()")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol SLCLKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((swift_name("PresenterCoroutineScope")))
@protocol SLCLPresenterCoroutineScope <SLCLKotlinx_coroutines_coreCoroutineScope>
@required
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingsPresenter")))
@interface SLCLSettingsPresenter : SLCLBase <SLCLSettingsContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger logOutUser:(id<SLCLLogOutUser>)logOutUser getAvailableSettings:(id<SLCLGetAvailableSettings>)getAvailableSettings getHelpUrl:(id<SLCLGetHelpUrl>)getHelpUrl applySetting:(id<SLCLApplySetting>)applySetting deleteAllLocalDictationData:(id<SLCLDeleteAllLocalDictationData>)deleteAllLocalDictationData __attribute__((swift_name("init(mainContext:logger:logOutUser:getAvailableSettings:getHelpUrl:applySetting:deleteAllLocalDictationData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSettingsPresenterCompanion *companion __attribute__((swift_name("companion")));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLSettingsContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onCloseClick __attribute__((swift_name("onCloseClick()")));
- (void)onDeleteLocalDictationDataWarningAccepted __attribute__((swift_name("onDeleteLocalDictationDataWarningAccepted()")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onFilePathSelectedSetting:(SLCLSetting *)setting newValue:(NSString *)newValue __attribute__((swift_name("onFilePathSelected(setting:newValue:)")));
- (void)onFocus __attribute__((swift_name("onFocus()")));
- (void)onIntValueEnteredSetting:(SLCLSetting *)setting newValue:(int32_t)newValue __attribute__((swift_name("onIntValueEntered(setting:newValue:)")));
- (void)onMultipleChoiceOptionSelectedSetting:(SLCLSetting *)setting option:(SLCLMultipleChoiceOption * _Nullable)option __attribute__((swift_name("onMultipleChoiceOptionSelected(setting:option:)")));
- (void)onSettingClickSetting:(SLCLSetting *)setting __attribute__((swift_name("onSettingClick(setting:)")));
- (void)onSettingToggledSetting:(SLCLSetting *)setting newValue:(BOOL)newValue __attribute__((swift_name("onSettingToggled(setting:newValue:)")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLSettingsContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingsPresenter.Companion")))
@interface SLCLSettingsPresenterCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSettingsPresenterCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *WHATS_COMING_UP_URL __attribute__((swift_name("WHATS_COMING_UP_URL")));
@property (readonly) NSString *WHATS_NEW_URL __attribute__((swift_name("WHATS_NEW_URL")));
@end;

__attribute__((swift_name("ApplySetting")))
@protocol SLCLApplySetting
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeSetting:(SLCLSetting *)setting completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(setting:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultApplySetting")))
@interface SLCLDefaultApplySetting : SLCLBase <SLCLApplySetting>
- (instancetype)initWithAppSettings:(id<SLCLAppSettings>)appSettings logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(appSettings:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeSetting:(SLCLSetting *)setting completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(setting:completionHandler:)")));
@end;

__attribute__((swift_name("GetAvailableSettings")))
@protocol SLCLGetAvailableSettings
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLSetting *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetAvailableSettings")))
@interface SLCLDefaultGetAvailableSettings : SLCLBase <SLCLGetAvailableSettings>
- (instancetype)initWithAppSettings:(id<SLCLAppSettings>)appSettings getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi adminApi:(id<SLCLAdminApi>)adminApi propertySuggestionsRepository:(id<SLCLPropertySuggestionsRepository>)propertySuggestionsRepository logger:(id<SLCLLogger>)logger environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo __attribute__((swift_name("init(appSettings:getCurrentUser:dictationApi:adminApi:propertySuggestionsRepository:logger:environmentInfo:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLSetting *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("GetHelpUrl")))
@protocol SLCLGetHelpUrl
@required
- (NSString *)invoke __attribute__((swift_name("invoke()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetHelpUrl")))
@interface SLCLDefaultGetHelpUrl : SLCLBase <SLCLGetHelpUrl>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SLCLDefaultGetHelpUrlCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)invoke __attribute__((swift_name("invoke()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetHelpUrl.Companion")))
@interface SLCLDefaultGetHelpUrlCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultGetHelpUrlCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *HELP_URL __attribute__((swift_name("HELP_URL")));
@end;

__attribute__((swift_name("DeleteAllLocalDictationData")))
@protocol SLCLDeleteAllLocalDictationData
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationDataForCurrentUser")))
@interface SLCLDeleteLocalDictationDataForCurrentUser : SLCLBase <SLCLDeleteAllLocalDictationData>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationRepository:(id<SLCLDictationRepository>)dictationRepository deleteLocalDictationData:(id<SLCLDeleteLocalDictationData>)deleteLocalDictationData logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationRepository:deleteLocalDictationData:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("AppSettings")))
@protocol SLCLAppSettings
@required
@property NSString * _Nullable defaultDictationCategory __attribute__((swift_name("defaultDictationCategory")));
@property NSString * _Nullable defaultDictationWorkType __attribute__((swift_name("defaultDictationWorkType")));
@property BOOL enableSpeechToText __attribute__((swift_name("enableSpeechToText")));
@property BOOL keepDisplayOnDuringRecording __attribute__((swift_name("keepDisplayOnDuringRecording")));
@property NSString * _Nullable preferredAssigneeId __attribute__((swift_name("preferredAssigneeId")));
@property int32_t recorderInputFileIterationCount __attribute__((swift_name("recorderInputFileIterationCount")));
@property NSString *recorderInputFilePath __attribute__((swift_name("recorderInputFilePath")));
@property BOOL showDeveloperOptions __attribute__((swift_name("showDeveloperOptions")));
@property BOOL showSecurityPromptOnAppStart __attribute__((swift_name("showSecurityPromptOnAppStart")));
@property BOOL useFileAsRecorderInput __attribute__((swift_name("useFileAsRecorderInput")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultAppSettings")))
@interface SLCLDefaultAppSettings : SLCLBase <SLCLAppSettings>
- (instancetype)initWithSettings:(id<SLCLSettings>)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDefaultAppSettingsCompanion *companion __attribute__((swift_name("companion")));
@property NSString * _Nullable defaultDictationCategory __attribute__((swift_name("defaultDictationCategory")));
@property NSString * _Nullable defaultDictationWorkType __attribute__((swift_name("defaultDictationWorkType")));
@property BOOL enableSpeechToText __attribute__((swift_name("enableSpeechToText")));
@property BOOL keepDisplayOnDuringRecording __attribute__((swift_name("keepDisplayOnDuringRecording")));
@property NSString * _Nullable preferredAssigneeId __attribute__((swift_name("preferredAssigneeId")));
@property int32_t recorderInputFileIterationCount __attribute__((swift_name("recorderInputFileIterationCount")));
@property NSString *recorderInputFilePath __attribute__((swift_name("recorderInputFilePath")));
@property BOOL showDeveloperOptions __attribute__((swift_name("showDeveloperOptions")));
@property BOOL showSecurityPromptOnAppStart __attribute__((swift_name("showSecurityPromptOnAppStart")));
@property BOOL useFileAsRecorderInput __attribute__((swift_name("useFileAsRecorderInput")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultAppSettings.Companion")))
@interface SLCLDefaultAppSettingsCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultAppSettingsCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MultipleChoiceOption")))
@interface SLCLMultipleChoiceOption : SLCLBase
- (instancetype)initWithId:(NSString *)id name:(NSString *)name __attribute__((swift_name("init(id:name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLMultipleChoiceOption *)doCopyId:(NSString *)id name:(NSString *)name __attribute__((swift_name("doCopy(id:name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Setting")))
@interface SLCLSetting : SLCLBase
- (instancetype)initWithType:(SLCLSettingType *)type data:(SLCLSettingData *)data __attribute__((swift_name("init(type:data:)"))) __attribute__((objc_designated_initializer));
- (SLCLSettingType *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSettingData *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSetting *)doCopyType:(SLCLSettingType *)type data:(SLCLSettingData *)data __attribute__((swift_name("doCopy(type:data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLSettingData *data __attribute__((swift_name("data")));
@property (readonly) SLCLSettingType *type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("SettingData")))
@interface SLCLSettingData : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingData.BooleanData")))
@interface SLCLSettingDataBooleanData : SLCLSettingData
- (instancetype)initWithValue:(BOOL)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSettingDataBooleanData *)doCopyValue:(BOOL)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingData.FilePath")))
@interface SLCLSettingDataFilePath : SLCLSettingData
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSettingDataFilePath *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingData.IntData")))
@interface SLCLSettingDataIntData : SLCLSettingData
- (instancetype)initWithValue:(int32_t)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSettingDataIntData *)doCopyValue:(int32_t)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingData.MultipleChoice")))
@interface SLCLSettingDataMultipleChoice : SLCLSettingData
- (instancetype)initWithSelected:(SLCLMultipleChoiceOption * _Nullable)selected options:(NSArray<SLCLMultipleChoiceOption *> *)options __attribute__((swift_name("init(selected:options:)"))) __attribute__((objc_designated_initializer));
- (SLCLMultipleChoiceOption * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<SLCLMultipleChoiceOption *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSettingDataMultipleChoice *)doCopySelected:(SLCLMultipleChoiceOption * _Nullable)selected options:(NSArray<SLCLMultipleChoiceOption *> *)options __attribute__((swift_name("doCopy(selected:options:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLMultipleChoiceOption *> *options __attribute__((swift_name("options")));
@property (readonly) SLCLMultipleChoiceOption * _Nullable selected __attribute__((swift_name("selected")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingData.None")))
@interface SLCLSettingDataNone : SLCLSettingData
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)none __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSettingDataNone *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol SLCLKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface SLCLKotlinEnum<E> : SLCLBase <SLCLKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingType")))
@interface SLCLSettingType : SLCLKotlinEnum<SLCLSettingType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLSettingType *about __attribute__((swift_name("about")));
@property (class, readonly) SLCLSettingType *help __attribute__((swift_name("help")));
@property (class, readonly) SLCLSettingType *signOut __attribute__((swift_name("signOut")));
@property (class, readonly) SLCLSettingType *keepDisplayOnDuringRecording __attribute__((swift_name("keepDisplayOnDuringRecording")));
@property (class, readonly) SLCLSettingType *enableSpeechToText __attribute__((swift_name("enableSpeechToText")));
@property (class, readonly) SLCLSettingType *preferredAssignee __attribute__((swift_name("preferredAssignee")));
@property (class, readonly) SLCLSettingType *showSecurityPromptOnAppStart __attribute__((swift_name("showSecurityPromptOnAppStart")));
@property (class, readonly) SLCLSettingType *defaultDictationWorkType __attribute__((swift_name("defaultDictationWorkType")));
@property (class, readonly) SLCLSettingType *defaultDictationCategory __attribute__((swift_name("defaultDictationCategory")));
@property (class, readonly) SLCLSettingType *showDeveloperOptions __attribute__((swift_name("showDeveloperOptions")));
@property (class, readonly) SLCLSettingType *recorderInputFilePath __attribute__((swift_name("recorderInputFilePath")));
@property (class, readonly) SLCLSettingType *recorderInputFileIterationCount __attribute__((swift_name("recorderInputFileIterationCount")));
@property (class, readonly) SLCLSettingType *useFileAsRecorderInput __attribute__((swift_name("useFileAsRecorderInput")));
@property (class, readonly) SLCLSettingType *deleteLocalDictationData __attribute__((swift_name("deleteLocalDictationData")));
@property (class, readonly) SLCLSettingType *whatsNew __attribute__((swift_name("whatsNew")));
@property (class, readonly) SLCLSettingType *whatsComingUp __attribute__((swift_name("whatsComingUp")));
@property (class, readonly) SLCLSettingType *doNotDisturbDuringRecording __attribute__((swift_name("doNotDisturbDuringRecording")));
+ (SLCLKotlinArray<SLCLSettingType *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((swift_name("RecorderContract")))
@protocol SLCLRecorderContract
@required
@end;

__attribute__((swift_name("RecorderContractPresenter")))
@protocol SLCLRecorderContractPresenter <SLCLBasePresenter>
@required
- (void)onAssigneeSelectedTeamId:(NSString *)teamId rememberAssignee:(BOOL)rememberAssignee __attribute__((swift_name("onAssigneeSelected(teamId:rememberAssignee:)")));
- (void)onBluetoothConnectPermissionRequestDenied __attribute__((swift_name("onBluetoothConnectPermissionRequestDenied()")));
- (void)onBluetoothConnectPermissionRequestGranted __attribute__((swift_name("onBluetoothConnectPermissionRequestGranted()")));
- (void)onCloseClick __attribute__((swift_name("onCloseClick()")));
- (void)onDeleteClick __attribute__((swift_name("onDeleteClick()")));
- (void)onDeleteWarningAccepted __attribute__((swift_name("onDeleteWarningAccepted()")));
- (void)onDiscardChangesWarningAccepted __attribute__((swift_name("onDiscardChangesWarningAccepted()")));
- (void)onFastForwardClick __attribute__((swift_name("onFastForwardClick()")));
- (void)onFastForwardHoldStart __attribute__((swift_name("onFastForwardHoldStart()")));
- (void)onFastForwardHoldStop __attribute__((swift_name("onFastForwardHoldStop()")));
- (void)onPauseClick __attribute__((swift_name("onPauseClick()")));
- (void)onPauseRecordingClick __attribute__((swift_name("onPauseRecordingClick()")));
- (void)onPlayClick __attribute__((swift_name("onPlayClick()")));
- (void)onRecordClick __attribute__((swift_name("onRecordClick()")));
- (void)onRecorderModeClick __attribute__((swift_name("onRecorderModeClick()")));
- (void)onRecorderModeSelectedMode:(SLCLAudioFileRecorderMode *)mode __attribute__((swift_name("onRecorderModeSelected(mode:)")));
- (void)onRecordingPermissionRequestDenied __attribute__((swift_name("onRecordingPermissionRequestDenied()")));
- (void)onRecordingPermissionRequestGranted __attribute__((swift_name("onRecordingPermissionRequestGranted()")));
- (void)onRewindClick __attribute__((swift_name("onRewindClick()")));
- (void)onRewindHoldStart __attribute__((swift_name("onRewindHoldStart()")));
- (void)onRewindHoldStop __attribute__((swift_name("onRewindHoldStop()")));
- (void)onSaveAsDraftClick __attribute__((swift_name("onSaveAsDraftClick()")));
- (void)onSeekDragFinishedTimeMilliseconds:(int64_t)timeMilliseconds __attribute__((swift_name("onSeekDragFinished(timeMilliseconds:)")));
- (void)onSeekDragStarted __attribute__((swift_name("onSeekDragStarted()")));
- (void)onSendToEmailClick __attribute__((swift_name("onSendToEmailClick()")));
- (void)onSendToSpeechRecognitionClick __attribute__((swift_name("onSendToSpeechRecognitionClick()")));
- (void)onSendToTranscriptionServiceClick __attribute__((swift_name("onSendToTranscriptionServiceClick()")));
- (void)onSendToTranscriptionistClick __attribute__((swift_name("onSendToTranscriptionistClick()")));
- (void)onShareClick __attribute__((swift_name("onShareClick()")));
- (void)onShowDictationPropertiesClick __attribute__((swift_name("onShowDictationPropertiesClick()")));
- (void)onSpeechRecognitionLanguageSelectedLanguageCode:(NSString *)languageCode __attribute__((swift_name("onSpeechRecognitionLanguageSelected(languageCode:)")));
- (void)onTitleChangeTitle:(NSString *)title __attribute__((swift_name("onTitleChange(title:)")));
@end;

__attribute__((swift_name("RecorderContractView")))
@protocol SLCLRecorderContractView <SLCLBaseView>
@required
- (void)closeRecorder __attribute__((swift_name("closeRecorder()")));
- (void)disableCloseRecorderButton __attribute__((swift_name("disableCloseRecorderButton()")));
- (void)disableFastForwardButton __attribute__((swift_name("disableFastForwardButton()")));
- (void)disablePlayPauseButton __attribute__((swift_name("disablePlayPauseButton()")));
- (void)disableRecordStopButton __attribute__((swift_name("disableRecordStopButton()")));
- (void)disableRewindButton __attribute__((swift_name("disableRewindButton()")));
- (void)enableCloseRecorderButton __attribute__((swift_name("enableCloseRecorderButton()")));
- (void)enableFastForwardButton __attribute__((swift_name("enableFastForwardButton()")));
- (void)enablePlayPauseButton __attribute__((swift_name("enablePlayPauseButton()")));
- (void)enableRecordStopButton __attribute__((swift_name("enableRecordStopButton()")));
- (void)enableRewindButton __attribute__((swift_name("enableRewindButton()")));
- (void)hideAudioLevel __attribute__((swift_name("hideAudioLevel()")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)hideProgressIndicator __attribute__((swift_name("hideProgressIndicator()")));
- (void)hideQuickFact1 __attribute__((swift_name("hideQuickFact1()")));
- (void)hideQuickFact2 __attribute__((swift_name("hideQuickFact2()")));
- (void)hideQuickFact3 __attribute__((swift_name("hideQuickFact3()")));
- (void)hideWaveform __attribute__((swift_name("hideWaveform()")));
- (void)shareFilesWithEmailFilePaths:(NSArray<NSString *> *)filePaths dictationName:(NSString *)dictationName date:(int64_t)date fileSize:(NSString *)fileSize durationMilliseconds:(int64_t)durationMilliseconds __attribute__((swift_name("shareFilesWithEmail(filePaths:dictationName:date:fileSize:durationMilliseconds:)")));
- (void)showArchivingProgressIndicator __attribute__((swift_name("showArchivingProgressIndicator()")));
- (void)showAssignErrorMessage __attribute__((swift_name("showAssignErrorMessage()")));
- (void)showAssigneeSelectionAssignees:(NSArray<SLCLAssignee *> *)assignees __attribute__((swift_name("showAssigneeSelection(assignees:)")));
- (void)showAttachmentDeleteProgressIndicatorCurrentFile:(int32_t)currentFile totalFiles:(int32_t)totalFiles __attribute__((swift_name("showAttachmentDeleteProgressIndicator(currentFile:totalFiles:)")));
- (void)showAttachmentUploadProgressIndicatorCurrentFile:(int32_t)currentFile totalFiles:(int32_t)totalFiles __attribute__((swift_name("showAttachmentUploadProgressIndicator(currentFile:totalFiles:)")));
- (void)showAudioLevelLevel:(float)level __attribute__((swift_name("showAudioLevel(level:)")));
- (void)showAvailableRecorderDoneActionsActions:(NSArray<SLCLRecorderDoneAction *> *)actions __attribute__((swift_name("showAvailableRecorderDoneActions(actions:)")));
- (void)showBluetoothConnectPermissionRequest __attribute__((swift_name("showBluetoothConnectPermissionRequest()")));
- (void)showCurrentTimeMillisecondsTime:(int64_t)time __attribute__((swift_name("showCurrentTimeMilliseconds(time:)")));
- (void)showDeleteWarning __attribute__((swift_name("showDeleteWarning()")));
- (void)showDictationPropertiesDictation:(SLCLDictation *)dictation __attribute__((swift_name("showDictationProperties(dictation:)")));
- (void)showDiscardChangesWarning __attribute__((swift_name("showDiscardChangesWarning()")));
- (void)showDurationMillisecondsTime:(int64_t)time __attribute__((swift_name("showDurationMilliseconds(time:)")));
- (void)showFileSystemError __attribute__((swift_name("showFileSystemError()")));
- (void)showGeneralUploadingError __attribute__((swift_name("showGeneralUploadingError()")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showNetworkError __attribute__((swift_name("showNetworkError()")));
- (void)showPauseButton __attribute__((swift_name("showPauseButton()")));
- (void)showPlayButton __attribute__((swift_name("showPlayButton()")));
- (void)showQuickFact1Subtitle:(SLCLDictationProperty *)subtitle __attribute__((swift_name("showQuickFact1(subtitle:)")));
- (void)showQuickFact2Subtitle:(SLCLDictationProperty *)subtitle __attribute__((swift_name("showQuickFact2(subtitle:)")));
- (void)showQuickFact3Subtitle:(SLCLDictationProperty *)subtitle __attribute__((swift_name("showQuickFact3(subtitle:)")));
- (void)showRecordButton __attribute__((swift_name("showRecordButton()")));
- (void)showRecorderModeSelectorModes:(NSArray<SLCLAudioFileRecorderMode *> *)modes __attribute__((swift_name("showRecorderModeSelector(modes:)")));
- (void)showRecordingPermissionDeniedError __attribute__((swift_name("showRecordingPermissionDeniedError()")));
- (void)showRecordingPermissionRequest __attribute__((swift_name("showRecordingPermissionRequest()")));
- (void)showSaveDictationProgressIndicator __attribute__((swift_name("showSaveDictationProgressIndicator()")));
- (void)showSelectedRecorderModeMode:(SLCLAudioFileRecorderMode *)mode __attribute__((swift_name("showSelectedRecorderMode(mode:)")));
- (void)showSendingToSpeechRecognitionError __attribute__((swift_name("showSendingToSpeechRecognitionError()")));
- (void)showSendingToTranscriptionServiceError __attribute__((swift_name("showSendingToTranscriptionServiceError()")));
- (void)showServerError __attribute__((swift_name("showServerError()")));
- (void)showSpeechRecognitionLanguageSelectorSupportedLanguages:(NSArray<SLCLSpeechRecognitionLanguage *> *)supportedLanguages __attribute__((swift_name("showSpeechRecognitionLanguageSelector(supportedLanguages:)")));
- (void)showStopRecordingButton __attribute__((swift_name("showStopRecordingButton()")));
- (void)showTitleTitle:(NSString *)title __attribute__((swift_name("showTitle(title:)")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
- (void)showUploadingFailedAfterRetry __attribute__((swift_name("showUploadingFailedAfterRetry()")));
- (void)showWaveformDictationAudioPath:(NSString *)dictationAudioPath __attribute__((swift_name("showWaveform(dictationAudioPath:)")));
- (void)startKeepingDisplayOn __attribute__((swift_name("startKeepingDisplayOn()")));
- (void)stopKeepingDisplayOn __attribute__((swift_name("stopKeepingDisplayOn()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecorderDoneAction")))
@interface SLCLRecorderDoneAction : SLCLKotlinEnum<SLCLRecorderDoneAction *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLRecorderDoneAction *saveAsDraft __attribute__((swift_name("saveAsDraft")));
@property (class, readonly) SLCLRecorderDoneAction *sendToTranscriptionist __attribute__((swift_name("sendToTranscriptionist")));
@property (class, readonly) SLCLRecorderDoneAction *sendToSpeechToText __attribute__((swift_name("sendToSpeechToText")));
@property (class, readonly) SLCLRecorderDoneAction *sendViaEmail __attribute__((swift_name("sendViaEmail")));
@property (class, readonly) SLCLRecorderDoneAction *sendToTranscriptionService __attribute__((swift_name("sendToTranscriptionService")));
@property (class, readonly) SLCLRecorderDoneAction *delete_ __attribute__((swift_name("delete_")));
+ (SLCLKotlinArray<SLCLRecorderDoneAction *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((swift_name("SpeechToTextRecorderContract")))
@protocol SLCLSpeechToTextRecorderContract
@required
@end;

__attribute__((swift_name("SpeechToTextRecorderContractPresenter")))
@protocol SLCLSpeechToTextRecorderContractPresenter <SLCLBasePresenter>
@required
- (void)onAssigneeSelectedTeamId:(NSString *)teamId rememberAssignee:(BOOL)rememberAssignee __attribute__((swift_name("onAssigneeSelected(teamId:rememberAssignee:)")));
- (void)onBluetoothConnectPermissionRequestDenied __attribute__((swift_name("onBluetoothConnectPermissionRequestDenied()")));
- (void)onBluetoothConnectPermissionRequestGranted __attribute__((swift_name("onBluetoothConnectPermissionRequestGranted()")));
- (void)onCloseClick __attribute__((swift_name("onCloseClick()")));
- (void)onDeleteClick __attribute__((swift_name("onDeleteClick()")));
- (void)onDeleteWarningAccepted __attribute__((swift_name("onDeleteWarningAccepted()")));
- (void)onFatalErrorOkClicked __attribute__((swift_name("onFatalErrorOkClicked()")));
- (void)onFinishClick __attribute__((swift_name("onFinishClick()")));
- (void)onLanguageSelectionClick __attribute__((swift_name("onLanguageSelectionClick()")));
- (void)onPauseRecordingClick __attribute__((swift_name("onPauseRecordingClick()")));
- (void)onPropertiesDismiss __attribute__((swift_name("onPropertiesDismiss()")));
- (void)onRecordClickCursorPosition:(int32_t)cursorPosition __attribute__((swift_name("onRecordClick(cursorPosition:)")));
- (void)onRecordingPermissionRequestDenied __attribute__((swift_name("onRecordingPermissionRequestDenied()")));
- (void)onRecordingPermissionRequestGranted __attribute__((swift_name("onRecordingPermissionRequestGranted()")));
- (void)onSendToEmailClick __attribute__((swift_name("onSendToEmailClick()")));
- (void)onShowDictationPropertiesClick __attribute__((swift_name("onShowDictationPropertiesClick()")));
- (void)onSpeechToTextCommandsActionClick __attribute__((swift_name("onSpeechToTextCommandsActionClick()")));
- (void)onSpeechToTextCopyActionClick __attribute__((swift_name("onSpeechToTextCopyActionClick()")));
- (void)onSpeechToTextLanguageSelectedLanguageCode:(NSString *)languageCode __attribute__((swift_name("onSpeechToTextLanguageSelected(languageCode:)")));
- (void)onTitleChangeTitle:(NSString *)title __attribute__((swift_name("onTitleChange(title:)")));
- (void)onUserChangedTextText:(NSString *)text __attribute__((swift_name("onUserChangedText(text:)")));
@end;

__attribute__((swift_name("SpeechToTextRecorderContractView")))
@protocol SLCLSpeechToTextRecorderContractView <SLCLBaseView>
@required
- (void)closeRecorder __attribute__((swift_name("closeRecorder()")));
- (void)doCopyInputTextText:(NSString *)text __attribute__((swift_name("doCopyInputText(text:)")));
- (void)disableActionButtons __attribute__((swift_name("disableActionButtons()")));
- (void)disableCloseRecorderButton __attribute__((swift_name("disableCloseRecorderButton()")));
- (void)disableRecordStopButton __attribute__((swift_name("disableRecordStopButton()")));
- (void)disableTextInputField __attribute__((swift_name("disableTextInputField()")));
- (void)enableActionButtons __attribute__((swift_name("enableActionButtons()")));
- (void)enableCloseRecorderButton __attribute__((swift_name("enableCloseRecorderButton()")));
- (void)enableRecordStopButton __attribute__((swift_name("enableRecordStopButton()")));
- (void)enableTextInputField __attribute__((swift_name("enableTextInputField()")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)hideProgressIndicator __attribute__((swift_name("hideProgressIndicator()")));
- (void)hideQuickFact1 __attribute__((swift_name("hideQuickFact1()")));
- (void)hideQuickFact2 __attribute__((swift_name("hideQuickFact2()")));
- (void)hideQuickFact3 __attribute__((swift_name("hideQuickFact3()")));
- (void)shareFilesWithEmailFilePaths:(NSArray<NSString *> *)filePaths dictationName:(NSString *)dictationName date:(int64_t)date fileSize:(NSString *)fileSize durationMilliseconds:(int64_t)durationMilliseconds __attribute__((swift_name("shareFilesWithEmail(filePaths:dictationName:date:fileSize:durationMilliseconds:)")));
- (void)showArchivingProgressIndicator __attribute__((swift_name("showArchivingProgressIndicator()")));
- (void)showAssignErrorMessageAndClose __attribute__((swift_name("showAssignErrorMessageAndClose()")));
- (void)showAssigneeSelectionAssignees:(NSArray<SLCLAssignee *> *)assignees __attribute__((swift_name("showAssigneeSelection(assignees:)")));
- (void)showAttachmentDeleteProgressIndicatorCurrentFile:(int32_t)currentFile totalFiles:(int32_t)totalFiles __attribute__((swift_name("showAttachmentDeleteProgressIndicator(currentFile:totalFiles:)")));
- (void)showAttachmentUploadProgressIndicatorCurrentFile:(int32_t)currentFile totalFiles:(int32_t)totalFiles __attribute__((swift_name("showAttachmentUploadProgressIndicator(currentFile:totalFiles:)")));
- (void)showBluetoothConnectPermissionRequest __attribute__((swift_name("showBluetoothConnectPermissionRequest()")));
- (void)showChangesSavedToNewDictationMessageAndCloseCopyName:(NSString *)copyName __attribute__((swift_name("showChangesSavedToNewDictationMessageAndClose(copyName:)")));
- (void)showDeleteWarning __attribute__((swift_name("showDeleteWarning()")));
- (void)showDictationPropertiesDictation:(SLCLDictation *)dictation __attribute__((swift_name("showDictationProperties(dictation:)")));
- (void)showFatalError __attribute__((swift_name("showFatalError()")));
- (void)showFileSystemError __attribute__((swift_name("showFileSystemError()")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showNetworkError __attribute__((swift_name("showNetworkError()")));
- (void)showQuickFact1Subtitle:(SLCLDictationProperty *)subtitle __attribute__((swift_name("showQuickFact1(subtitle:)")));
- (void)showQuickFact2Subtitle:(SLCLDictationProperty *)subtitle __attribute__((swift_name("showQuickFact2(subtitle:)")));
- (void)showQuickFact3Subtitle:(SLCLDictationProperty *)subtitle __attribute__((swift_name("showQuickFact3(subtitle:)")));
- (void)showRecognizedTextRecognizedText:(NSString *)recognizedText cursorPosition:(int32_t)cursorPosition __attribute__((swift_name("showRecognizedText(recognizedText:cursorPosition:)")));
- (void)showRecordButton __attribute__((swift_name("showRecordButton()")));
- (void)showRecordingPermissionDeniedError __attribute__((swift_name("showRecordingPermissionDeniedError()")));
- (void)showRecordingPermissionRequest __attribute__((swift_name("showRecordingPermissionRequest()")));
- (void)showSaveDictationProgressIndicator __attribute__((swift_name("showSaveDictationProgressIndicator()")));
- (void)showSavedLocallyMessageAndClose __attribute__((swift_name("showSavedLocallyMessageAndClose()")));
- (void)showServerError __attribute__((swift_name("showServerError()")));
- (void)showSpeechToTextCommandsCommands:(SLCLSpeechToTextCommandList *)commands __attribute__((swift_name("showSpeechToTextCommands(commands:)")));
- (void)showSpeechToTextLanguageLocaleLanguage:(NSString *)localeLanguage __attribute__((swift_name("showSpeechToTextLanguage(localeLanguage:)")));
- (void)showSpeechToTextLanguageSelectorSupportedLanguages:(NSArray<SLCLSpeechRecognitionLanguage *> *)supportedLanguages __attribute__((swift_name("showSpeechToTextLanguageSelector(supportedLanguages:)")));
- (void)showStopRecordingButton __attribute__((swift_name("showStopRecordingButton()")));
- (void)showTitleTitle:(NSString *)title __attribute__((swift_name("showTitle(title:)")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
- (void)startKeepingDisplayOn __attribute__((swift_name("startKeepingDisplayOn()")));
- (void)stopKeepingDisplayOn __attribute__((swift_name("stopKeepingDisplayOn()")));
@end;

__attribute__((swift_name("SpeechToTextService")))
@protocol SLCLSpeechToTextService
@required
- (void)addSttListenerListener:(id<SLCLSpeechToTextServiceListener>)listener __attribute__((swift_name("addSttListener(listener:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)connectUserId:(NSString *)userId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("connect(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)disconnectWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("disconnect(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCommandsUserId:(NSString *)userId languageCode:(NSString *)languageCode completionHandler:(void (^)(SLCLEither<SLCLSpeechToTextCommandList *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCommands(userId:languageCode:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSupportedLanguagesUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<NSArray<SLCLSpeechRecognitionLanguage *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSupportedLanguages(userId:completionHandler:)")));
- (void)removeSttListenerListener:(id<SLCLSpeechToTextServiceListener>)listener __attribute__((swift_name("removeSttListener(listener:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendAudioChunk:(SLCLKotlinByteArray *)chunk completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("sendAudio(chunk:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)startRecognitionDictationId:(NSString *)dictationId sampleRate:(int32_t)sampleRate language:(SLCLSpeechRecognitionLanguage *)language completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("startRecognition(dictationId:sampleRate:language:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)stopRecognitionWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("stopRecognition(completionHandler:)")));
@property (readonly) int32_t maxAudioChunkSize __attribute__((swift_name("maxAudioChunkSize")));
@property (readonly) SLCLSpeechToTextServiceState *state __attribute__((swift_name("state")));
@end;

__attribute__((swift_name("SpeechToTextServiceListener")))
@protocol SLCLSpeechToTextServiceListener
@required
- (void)onConnectionStarted __attribute__((swift_name("onConnectionStarted()")));
- (void)onRecognitionError __attribute__((swift_name("onRecognitionError()")));
- (void)onRecognitionStateChangedFrom:(SLCLSpeechToTextServiceState *)from to:(SLCLSpeechToTextServiceState *)to __attribute__((swift_name("onRecognitionStateChanged(from:to:)")));
- (void)onRecognizedResult:(SLCLRecognizedText *)result __attribute__((swift_name("onRecognized(result:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechToTextServiceState")))
@interface SLCLSpeechToTextServiceState : SLCLKotlinEnum<SLCLSpeechToTextServiceState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLSpeechToTextServiceState *disconnected __attribute__((swift_name("disconnected")));
@property (class, readonly) SLCLSpeechToTextServiceState *connecting __attribute__((swift_name("connecting")));
@property (class, readonly) SLCLSpeechToTextServiceState *connected __attribute__((swift_name("connected")));
@property (class, readonly) SLCLSpeechToTextServiceState *startingRecognition __attribute__((swift_name("startingRecognition")));
@property (class, readonly) SLCLSpeechToTextServiceState *recognizing __attribute__((swift_name("recognizing")));
+ (SLCLKotlinArray<SLCLSpeechToTextServiceState *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSSet<SLCLSpeechToTextServiceState *> *transitionsTo __attribute__((swift_name("transitionsTo")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BeginNewRecognitionForDesktopAppMethod")))
@interface SLCLBeginNewRecognitionForDesktopAppMethod : SLCLBase
- (instancetype)initWithMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("init(map:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLBeginNewRecognitionForDesktopAppMethodCompanion *companion __attribute__((swift_name("companion")));
- (SLCLMutableDictionary<NSString *, id> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLBeginNewRecognitionForDesktopAppMethod *)doCopyMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("doCopy(map:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t ApplicationTypeId __attribute__((swift_name("ApplicationTypeId")));
@property NSString *DictationId __attribute__((swift_name("DictationId")));
@property NSString *RecognitionLanguage __attribute__((swift_name("RecognitionLanguage")));
@property int32_t SampleRate __attribute__((swift_name("SampleRate")));
@property NSString *WebAccessSessionId __attribute__((swift_name("WebAccessSessionId")));
@property (readonly) SLCLMutableDictionary<NSString *, id> *map __attribute__((swift_name("map")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BeginNewRecognitionForDesktopAppMethod.Companion")))
@interface SLCLBeginNewRecognitionForDesktopAppMethodCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLBeginNewRecognitionForDesktopAppMethodCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CloseDictationMethod")))
@interface SLCLCloseDictationMethod : SLCLBase
- (instancetype)initWithMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("init(map:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLCloseDictationMethodCompanion *companion __attribute__((swift_name("companion")));
- (SLCLMutableDictionary<NSString *, id> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLCloseDictationMethod *)doCopyMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("doCopy(map:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t ApplicationTypeId __attribute__((swift_name("ApplicationTypeId")));
@property NSString *DictationId __attribute__((swift_name("DictationId")));
@property NSString *Reason __attribute__((swift_name("Reason")));
@property NSString *WebAccessSessionId __attribute__((swift_name("WebAccessSessionId")));
@property (readonly) SLCLMutableDictionary<NSString *, id> *map __attribute__((swift_name("map")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CloseDictationMethod.Companion")))
@interface SLCLCloseDictationMethodCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCloseDictationMethodCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CloseDictationReason")))
@interface SLCLCloseDictationReason : SLCLKotlinEnum<SLCLCloseDictationReason *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLCloseDictationReason *cancel __attribute__((swift_name("cancel")));
@property (class, readonly) SLCLCloseDictationReason *finish __attribute__((swift_name("finish")));
@property (class, readonly) SLCLCloseDictationReason *error __attribute__((swift_name("error")));
+ (SLCLKotlinArray<SLCLCloseDictationReason *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *serverSideName __attribute__((swift_name("serverSideName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateSttSessionResponse")))
@interface SLCLCreateSttSessionResponse : SLCLBase
- (instancetype)initWithSessionID:(NSString *)sessionID __attribute__((swift_name("init(sessionID:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLCreateSttSessionResponseCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLCreateSttSessionResponse *)doCopySessionID:(NSString *)sessionID __attribute__((swift_name("doCopy(sessionID:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *sessionID __attribute__((swift_name("sessionID")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateSttSessionResponse.Companion")))
@interface SLCLCreateSttSessionResponseCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateSttSessionResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorEvent")))
@interface SLCLErrorEvent : SLCLBase
- (instancetype)initWithErrorMessageResourceId:(NSString *)ErrorMessageResourceId ErrorId:(NSString *)ErrorId __attribute__((swift_name("init(ErrorMessageResourceId:ErrorId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLErrorEventCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLErrorEvent *)doCopyErrorMessageResourceId:(NSString *)ErrorMessageResourceId ErrorId:(NSString *)ErrorId __attribute__((swift_name("doCopy(ErrorMessageResourceId:ErrorId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *ErrorId __attribute__((swift_name("ErrorId")));
@property (readonly) NSString *ErrorMessageResourceId __attribute__((swift_name("ErrorMessageResourceId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorEvent.Companion")))
@interface SLCLErrorEventCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLErrorEventCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecognitionCompletedEvent")))
@interface SLCLRecognitionCompletedEvent : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recognitionCompletedEvent __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRecognitionCompletedEvent *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecognizedTextEvent")))
@interface SLCLRecognizedTextEvent : SLCLBase
- (instancetype)initWithMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("init(map:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLRecognizedTextEventCompanion *companion __attribute__((swift_name("companion")));
- (SLCLMutableDictionary<NSString *, id> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLRecognizedTextEvent *)doCopyMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("doCopy(map:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *RecognizedText __attribute__((swift_name("RecognizedText")));
@property NSString *Type __attribute__((swift_name("Type")));
@property (readonly) SLCLMutableDictionary<NSString *, id> *map __attribute__((swift_name("map")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecognizedTextEvent.Companion")))
@interface SLCLRecognizedTextEventCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRecognizedTextEventCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StopRecognitionMethod")))
@interface SLCLStopRecognitionMethod : SLCLBase
- (instancetype)initWithMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("init(map:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLStopRecognitionMethodCompanion *companion __attribute__((swift_name("companion")));
- (SLCLMutableDictionary<NSString *, id> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLStopRecognitionMethod *)doCopyMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("doCopy(map:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t ApplicationTypeId __attribute__((swift_name("ApplicationTypeId")));
@property NSString *DictationId __attribute__((swift_name("DictationId")));
@property NSString *WebAccessSessionId __attribute__((swift_name("WebAccessSessionId")));
@property (readonly) SLCLMutableDictionary<NSString *, id> *map __attribute__((swift_name("map")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StopRecognitionMethod.Companion")))
@interface SLCLStopRecognitionMethodCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLStopRecognitionMethodCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SttApplicationTypeId")))
@interface SLCLSttApplicationTypeId : SLCLKotlinEnum<SLCLSttApplicationTypeId *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLSttApplicationTypeId *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLSttApplicationTypeId *android __attribute__((swift_name("android")));
@property (class, readonly) SLCLSttApplicationTypeId *ios __attribute__((swift_name("ios")));
@property (class, readonly) SLCLSttApplicationTypeId *electronWindows __attribute__((swift_name("electronWindows")));
@property (class, readonly) SLCLSttApplicationTypeId *electronMac __attribute__((swift_name("electronMac")));
@property (class, readonly) SLCLSttApplicationTypeId *web __attribute__((swift_name("web")));
+ (SLCLKotlinArray<SLCLSttApplicationTypeId *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadAudioChunkMethod")))
@interface SLCLUploadAudioChunkMethod : SLCLBase
- (instancetype)initWithMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("init(map:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLUploadAudioChunkMethodCompanion *companion __attribute__((swift_name("companion")));
- (SLCLMutableDictionary<NSString *, id> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUploadAudioChunkMethod *)doCopyMap:(SLCLMutableDictionary<NSString *, id> *)map __attribute__((swift_name("doCopy(map:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t ApplicationTypeId __attribute__((swift_name("ApplicationTypeId")));
@property NSString *DataAsBase64 __attribute__((swift_name("DataAsBase64")));
@property NSString *DictationId __attribute__((swift_name("DictationId")));
@property NSString *WebAccessSessionId __attribute__((swift_name("WebAccessSessionId")));
@property (readonly) SLCLMutableDictionary<NSString *, id> *map __attribute__((swift_name("map")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadAudioChunkMethod.Companion")))
@interface SLCLUploadAudioChunkMethodCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUploadAudioChunkMethodCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *NAME __attribute__((swift_name("NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecognizedText")))
@interface SLCLRecognizedText : SLCLBase
- (instancetype)initWithText:(NSString *)text stability:(SLCLRecognizedTextStability *)stability __attribute__((swift_name("init(text:stability:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLRecognizedTextStability *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLRecognizedText *)doCopyText:(NSString *)text stability:(SLCLRecognizedTextStability *)stability __attribute__((swift_name("doCopy(text:stability:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLRecognizedTextStability *stability __attribute__((swift_name("stability")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecognizedText.Stability")))
@interface SLCLRecognizedTextStability : SLCLKotlinEnum<SLCLRecognizedTextStability *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLRecognizedTextStability *low __attribute__((swift_name("low")));
@property (class, readonly) SLCLRecognizedTextStability *high __attribute__((swift_name("high")));
@property (class, readonly) SLCLRecognizedTextStability *final __attribute__((swift_name("final")));
+ (SLCLKotlinArray<SLCLRecognizedTextStability *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechToTextCommand")))
@interface SLCLSpeechToTextCommand : SLCLBase
- (instancetype)initWithSymbol:(NSString *)symbol text:(NSString *)text __attribute__((swift_name("init(symbol:text:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechToTextCommand *)doCopySymbol:(NSString *)symbol text:(NSString *)text __attribute__((swift_name("doCopy(symbol:text:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *symbol __attribute__((swift_name("symbol")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechToTextCommandCategory")))
@interface SLCLSpeechToTextCommandCategory : SLCLBase
- (instancetype)initWithTitle:(NSString *)title speechToTextCommands:(NSArray<SLCLSpeechToTextCommand *> *)speechToTextCommands __attribute__((swift_name("init(title:speechToTextCommands:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<SLCLSpeechToTextCommand *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechToTextCommandCategory *)doCopyTitle:(NSString *)title speechToTextCommands:(NSArray<SLCLSpeechToTextCommand *> *)speechToTextCommands __attribute__((swift_name("doCopy(title:speechToTextCommands:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLSpeechToTextCommand *> *speechToTextCommands __attribute__((swift_name("speechToTextCommands")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechToTextCommandList")))
@interface SLCLSpeechToTextCommandList : SLCLBase
- (instancetype)initWithTitle:(NSString *)title list:(NSArray<SLCLSpeechToTextCommandCategory *> *)list __attribute__((swift_name("init(title:list:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<SLCLSpeechToTextCommandCategory *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechToTextCommandList *)doCopyTitle:(NSString *)title list:(NSArray<SLCLSpeechToTextCommandCategory *> *)list __attribute__((swift_name("doCopy(title:list:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLSpeechToTextCommandCategory *> *list __attribute__((swift_name("list")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end;

__attribute__((swift_name("CombineRecognizedText")))
@protocol SLCLCombineRecognizedText
@required
- (SLCLCombineRecognizedTextOutput *)invokeFinalStability:(NSString *)finalStability highStability:(NSString *)highStability lowStability:(NSString *)lowStability recognizedText:(SLCLRecognizedText *)recognizedText cursorPosition:(int32_t)cursorPosition __attribute__((swift_name("invoke(finalStability:highStability:lowStability:recognizedText:cursorPosition:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CombineRecognizedTextOutput")))
@interface SLCLCombineRecognizedTextOutput : SLCLBase
- (instancetype)initWithFinalStability:(NSString *)finalStability highStability:(NSString *)highStability lowStability:(NSString *)lowStability joined:(NSString *)joined cursorPosition:(int32_t)cursorPosition __attribute__((swift_name("init(finalStability:highStability:lowStability:joined:cursorPosition:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLCombineRecognizedTextOutput *)doCopyFinalStability:(NSString *)finalStability highStability:(NSString *)highStability lowStability:(NSString *)lowStability joined:(NSString *)joined cursorPosition:(int32_t)cursorPosition __attribute__((swift_name("doCopy(finalStability:highStability:lowStability:joined:cursorPosition:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t cursorPosition __attribute__((swift_name("cursorPosition")));
@property (readonly) NSString *finalStability __attribute__((swift_name("finalStability")));
@property (readonly) NSString *highStability __attribute__((swift_name("highStability")));
@property (readonly) NSString *joined __attribute__((swift_name("joined")));
@property (readonly) NSString *lowStability __attribute__((swift_name("lowStability")));
@end;

__attribute__((swift_name("DecryptFile")))
@protocol SLCLDecryptFile
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeFile:(id<SLCLFile>)file completionHandler:(void (^)(id<SLCLFile> _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(file:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCombineRecognizedText")))
@interface SLCLDefaultCombineRecognizedText : SLCLBase <SLCLCombineRecognizedText>
- (instancetype)initWithLogger:(id<SLCLLogger>)logger __attribute__((swift_name("init(logger:)"))) __attribute__((objc_designated_initializer));
- (SLCLCombineRecognizedTextOutput *)invokeFinalStability:(NSString *)finalStability highStability:(NSString *)highStability lowStability:(NSString *)lowStability recognizedText:(SLCLRecognizedText *)recognizedText cursorPosition:(int32_t)cursorPosition __attribute__((swift_name("invoke(finalStability:highStability:lowStability:recognizedText:cursorPosition:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDecryptFile")))
@interface SLCLDefaultDecryptFile : SLCLBase <SLCLDecryptFile>
- (instancetype)initWithEncryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider logger:(id<SLCLLogger>)logger tmpDirectory:(id<SLCLDirectory>)tmpDirectory __attribute__((swift_name("init(encryptionProvider:logger:tmpDirectory:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeFile:(id<SLCLFile>)file completionHandler:(void (^)(id<SLCLFile> _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(file:completionHandler:)")));
@end;

__attribute__((swift_name("EncryptFile")))
@protocol SLCLEncryptFile
@required
- (void)invokeFile:(id<SLCLFile>)file __attribute__((swift_name("invoke(file:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultEncryptFile")))
@interface SLCLDefaultEncryptFile : SLCLBase <SLCLEncryptFile>
- (instancetype)initWithEncryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider isEncryptionEnabled:(BOOL)isEncryptionEnabled logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(encryptionProvider:isEncryptionEnabled:logger:)"))) __attribute__((objc_designated_initializer));
- (void)invokeFile:(id<SLCLFile>)file __attribute__((swift_name("invoke(file:)")));
@end;

__attribute__((swift_name("EncryptTempAudio")))
@protocol SLCLEncryptTempAudio
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDecryptedFile:(id<SLCLFile>)decryptedFile dictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(decryptedFile:dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultEncryptTempAudio")))
@interface SLCLDefaultEncryptTempAudio : SLCLBase <SLCLEncryptTempAudio>
- (instancetype)initWithDictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository encryptFile:(id<SLCLEncryptFile>)encryptFile logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationFilesRepository:encryptFile:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDecryptedFile:(id<SLCLFile>)decryptedFile dictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(decryptedFile:dictation:completionHandler:)")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@end;

__attribute__((swift_name("GetCurrentAudioSettings")))
@protocol SLCLGetCurrentAudioSettings
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLAudioSettings * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetCurrentAudioSettings")))
@interface SLCLDefaultGetCurrentAudioSettings : SLCLBase <SLCLGetCurrentAudioSettings>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLAudioSettings * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("InitializeLanguage")))
@protocol SLCLInitializeLanguage
@required
- (SLCLSpeechRecognitionLanguage *)invokeLanguageList:(NSArray<SLCLSpeechRecognitionLanguage *> *)languageList languageCode:(NSString *)languageCode __attribute__((swift_name("invoke(languageList:languageCode:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultInitializeLanguage")))
@interface SLCLDefaultInitializeLanguage : SLCLBase <SLCLInitializeLanguage>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SLCLSpeechRecognitionLanguage *)invokeLanguageList:(NSArray<SLCLSpeechRecognitionLanguage *> *)languageList languageCode:(NSString *)languageCode __attribute__((swift_name("invoke(languageList:languageCode:)")));
@end;

__attribute__((swift_name("LoginToSpeechExecEnterprise")))
@protocol SLCLLoginToSpeechExecEnterprise
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUsername:(NSString *)username password:(NSString *)password url:(NSString *)url appProxyAuthorityUrl:(NSString * _Nullable)appProxyAuthorityUrl appProxyClientId:(NSString * _Nullable)appProxyClientId appProxyRedirectUrl:(NSString * _Nullable)appProxyRedirectUrl completionHandler:(void (^)(SLCLLoginToSpeechExecEnterpriseOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(username:password:url:appProxyAuthorityUrl:appProxyClientId:appProxyRedirectUrl:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultLoginToSpeechExecEnterprise")))
@interface SLCLDefaultLoginToSpeechExecEnterprise : SLCLBase <SLCLLoginToSpeechExecEnterprise>
- (instancetype)initWithIdentityService:(id<SLCLIdentityService>)identityService speechExecEnterpriseSettings:(SLCLSpeechExecEnterpriseSettings *)speechExecEnterpriseSettings userRepository:(id<SLCLUserRepository>)userRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(identityService:speechExecEnterpriseSettings:userRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUsername:(NSString *)username password:(NSString *)password url:(NSString *)url appProxyAuthorityUrl:(NSString * _Nullable)appProxyAuthorityUrl appProxyClientId:(NSString * _Nullable)appProxyClientId appProxyRedirectUrl:(NSString * _Nullable)appProxyRedirectUrl completionHandler:(void (^)(SLCLLoginToSpeechExecEnterpriseOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(username:password:url:appProxyAuthorityUrl:appProxyClientId:appProxyRedirectUrl:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultLoginToSpeechExecEnterprise.LoginErrors")))
@interface SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors : SLCLKotlinEnum<SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors *wrongCredentials __attribute__((swift_name("wrongCredentials")));
@property (class, readonly) SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors *noUserFound __attribute__((swift_name("noUserFound")));
@property (class, readonly) SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors *licenseNotAvailable __attribute__((swift_name("licenseNotAvailable")));
+ (SLCLKotlinArray<SLCLDefaultLoginToSpeechExecEnterpriseLoginErrors *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *errorName __attribute__((swift_name("errorName")));
@end;

__attribute__((swift_name("MonitorRecordingProgress")))
@protocol SLCLMonitorRecordingProgress
@required
- (id<SLCLKotlinx_coroutines_coreJob>)invokeChannels:(NSArray<SLCLInt *> *)channels coroutine:(id<SLCLKotlinx_coroutines_coreCoroutineScope>)coroutine onUnexpectedError:(void (^)(void))onUnexpectedError onUpdate:(void (^)(NSArray<SLCLFloat *> *, SLCLLong *, SLCLLong *))onUpdate __attribute__((swift_name("invoke(channels:coroutine:onUnexpectedError:onUpdate:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultMonitorRecordingProgress")))
@interface SLCLDefaultMonitorRecordingProgress : SLCLBase <SLCLMonitorRecordingProgress>
- (instancetype)initWithAudioFileRecorder:(id<SLCLAudioFileRecorder>)audioFileRecorder updateFrequencyMilliseconds:(int64_t)updateFrequencyMilliseconds __attribute__((swift_name("init(audioFileRecorder:updateFrequencyMilliseconds:)"))) __attribute__((objc_designated_initializer));
- (id<SLCLKotlinx_coroutines_coreJob>)invokeChannels:(NSArray<SLCLInt *> *)channels coroutine:(id<SLCLKotlinx_coroutines_coreCoroutineScope>)coroutine onUnexpectedError:(void (^)(void))onUnexpectedError onUpdate:(void (^)(NSArray<SLCLFloat *> *, SLCLLong *, SLCLLong *))onUpdate __attribute__((swift_name("invoke(channels:coroutine:onUnexpectedError:onUpdate:)")));
@end;

__attribute__((swift_name("UpdateDictationOnAudioChange")))
@protocol SLCLUpdateDictationOnAudioChange
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation newDuration:(int64_t)newDuration completionHandler:(void (^)(SLCLDictation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:newDuration:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultUpdateDictationOnAudioChange")))
@interface SLCLDefaultUpdateDictationOnAudioChange : SLCLBase <SLCLUpdateDictationOnAudioChange>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository timeProvider:(id<SLCLTimeProvider>)timeProvider __attribute__((swift_name("init(dictationRepository:timeProvider:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation newDuration:(int64_t)newDuration completionHandler:(void (^)(SLCLDictation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:newDuration:completionHandler:)")));
@end;

__attribute__((swift_name("WriteDictationTranscript")))
@protocol SLCLWriteDictationTranscript
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation text:(NSString *)text append:(BOOL)append completionHandler:(void (^)(SLCLWriteDictationTranscriptOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:text:append:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultWriteDictationTranscript")))
@interface SLCLDefaultWriteDictationTranscript : SLCLBase <SLCLWriteDictationTranscript>
- (instancetype)initWithDictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository createAttachment:(id<SLCLCreateAttachment>)createAttachment getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser encryptFile:(id<SLCLEncryptFile>)encryptFile decryptFile:(id<SLCLDecryptFile>)decryptFile timeProvider:(id<SLCLTimeProvider>)timeProvider tmpDirectory:(id<SLCLDirectory>)tmpDirectory logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationFilesRepository:dictationRepository:attachmentRepository:createAttachment:getCurrentUser:encryptFile:decryptFile:timeProvider:tmpDirectory:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation text:(NSString *)text append:(BOOL)append completionHandler:(void (^)(SLCLWriteDictationTranscriptOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:text:append:completionHandler:)")));
@end;

__attribute__((swift_name("GetPreferredLanguageCode")))
@protocol SLCLGetPreferredLanguageCode
@required
- (NSString *)invoke __attribute__((swift_name("invoke()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetPreferredLanguageCodeFromSettings")))
@interface SLCLGetPreferredLanguageCodeFromSettings : SLCLBase <SLCLGetPreferredLanguageCode>
- (instancetype)initWithSettings:(id<SLCLSettings>)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLGetPreferredLanguageCodeFromSettingsCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)invoke __attribute__((swift_name("invoke()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetPreferredLanguageCodeFromSettings.Companion")))
@interface SLCLGetPreferredLanguageCodeFromSettingsCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetPreferredLanguageCodeFromSettingsCompanion *shared __attribute__((swift_name("shared")));
- (NSString *)getKey __attribute__((swift_name("getKey()")));
@end;

__attribute__((swift_name("GetPreferredRecorderMode")))
@protocol SLCLGetPreferredRecorderMode
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLAudioFileRecorderMode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetPreferredRecorderModeFromSettings")))
@interface SLCLGetPreferredRecorderModeFromSettings : SLCLBase <SLCLGetPreferredRecorderMode>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser settings:(id<SLCLSettings>)settings logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:settings:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLAudioFileRecorderMode * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("GetRecorderDoneActions")))
@protocol SLCLGetRecorderDoneActions
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSArray<SLCLRecorderDoneAction *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSpeechExecEnterpriseRecorderDoneActions")))
@interface SLCLGetSpeechExecEnterpriseRecorderDoneActions : SLCLBase <SLCLGetRecorderDoneActions>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi checkIfTranscriptionServiceAvailable:(id<SLCLCheckIfTranscriptionServiceAvailable>)checkIfTranscriptionServiceAvailable checkIfSpeechToTextAvailable:(id<SLCLCheckIfSpeechToTextAvailable>)checkIfSpeechToTextAvailable logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationApi:checkIfTranscriptionServiceAvailable:checkIfSpeechToTextAvailable:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSArray<SLCLRecorderDoneAction *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSpeechLiveRecorderDoneActions")))
@interface SLCLGetSpeechLiveRecorderDoneActions : SLCLBase <SLCLGetRecorderDoneActions>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi checkIfTranscriptionServiceAvailable:(id<SLCLCheckIfTranscriptionServiceAvailable>)checkIfTranscriptionServiceAvailable checkIfSpeechToTextAvailable:(id<SLCLCheckIfSpeechToTextAvailable>)checkIfSpeechToTextAvailable logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationApi:checkIfTranscriptionServiceAvailable:checkIfSpeechToTextAvailable:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSArray<SLCLRecorderDoneAction *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput")))
@interface SLCLLoginToSpeechExecEnterpriseOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.LicenseNotAvailable")))
@interface SLCLLoginToSpeechExecEnterpriseOutputLicenseNotAvailable : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)licenseNotAvailable __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputLicenseNotAvailable *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.NetworkError")))
@interface SLCLLoginToSpeechExecEnterpriseOutputNetworkError : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.NoAuthorRoleFound")))
@interface SLCLLoginToSpeechExecEnterpriseOutputNoAuthorRoleFound : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noAuthorRoleFound __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputNoAuthorRoleFound *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.NoUserFound")))
@interface SLCLLoginToSpeechExecEnterpriseOutputNoUserFound : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noUserFound __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputNoUserFound *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.ServerError")))
@interface SLCLLoginToSpeechExecEnterpriseOutputServerError : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.Success")))
@interface SLCLLoginToSpeechExecEnterpriseOutputSuccess : SLCLLoginToSpeechExecEnterpriseOutput
- (instancetype)initWithUser:(SLCLUser *)user __attribute__((swift_name("init(user:)"))) __attribute__((objc_designated_initializer));
- (SLCLUser *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoginToSpeechExecEnterpriseOutputSuccess *)doCopyUser:(SLCLUser *)user __attribute__((swift_name("doCopy(user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLUser *user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.UnexpectedError")))
@interface SLCLLoginToSpeechExecEnterpriseOutputUnexpectedError : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginToSpeechExecEnterpriseOutput.WrongCredentials")))
@interface SLCLLoginToSpeechExecEnterpriseOutputWrongCredentials : SLCLLoginToSpeechExecEnterpriseOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)wrongCredentials __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginToSpeechExecEnterpriseOutputWrongCredentials *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("PrepareDictationForSharing")))
@protocol SLCLPrepareDictationForSharing
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWorkingCopy:(SLCLDictation *)workingCopy completionHandler:(void (^)(NSArray<id<SLCLFile>> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(workingCopy:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationFilesForSharing")))
@interface SLCLPrepareDictationFilesForSharing : SLCLBase <SLCLPrepareDictationForSharing>
- (instancetype)initWithTempDirectory:(id<SLCLDirectory>)tempDirectory decryptFile:(id<SLCLDecryptFile>)decryptFile dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository fileArchiver:(id<SLCLFileArchiver>)fileArchiver attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(tempDirectory:decryptFile:dictationFilesRepository:fileArchiver:attachmentRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWorkingCopy:(SLCLDictation *)workingCopy completionHandler:(void (^)(NSArray<id<SLCLFile>> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(workingCopy:completionHandler:)")));
@end;

__attribute__((swift_name("SavePreferredRecorderMode")))
@protocol SLCLSavePreferredRecorderMode
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeMode:(SLCLAudioFileRecorderMode *)mode completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(mode:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SavePreferredRecorderModeToSettings")))
@interface SLCLSavePreferredRecorderModeToSettings : SLCLBase <SLCLSavePreferredRecorderMode>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser settings:(id<SLCLSettings>)settings logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:settings:logger:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSavePreferredRecorderModeToSettingsCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeMode:(SLCLAudioFileRecorderMode *)mode completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(mode:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SavePreferredRecorderModeToSettings.Companion")))
@interface SLCLSavePreferredRecorderModeToSettingsCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSavePreferredRecorderModeToSettingsCompanion *shared __attribute__((swift_name("shared")));
- (NSString *)getKeyUserId:(NSString *)userId __attribute__((swift_name("getKey(userId:)")));
@end;

__attribute__((swift_name("SetPreferredLanguageCode")))
@protocol SLCLSetPreferredLanguageCode
@required
- (void)invokeLanguageCode:(NSString *)languageCode __attribute__((swift_name("invoke(languageCode:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetPreferredLanguageCodeToSettings")))
@interface SLCLSetPreferredLanguageCodeToSettings : SLCLBase <SLCLSetPreferredLanguageCode>
- (instancetype)initWithSettings:(id<SLCLSettings>)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));
- (void)invokeLanguageCode:(NSString *)languageCode __attribute__((swift_name("invoke(languageCode:)")));
@end;

__attribute__((swift_name("WriteDictationTranscriptOutput")))
@interface SLCLWriteDictationTranscriptOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WriteDictationTranscriptOutput.FileSystemError")))
@interface SLCLWriteDictationTranscriptOutputFileSystemError : SLCLWriteDictationTranscriptOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLWriteDictationTranscriptOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WriteDictationTranscriptOutput.Success")))
@interface SLCLWriteDictationTranscriptOutputSuccess : SLCLWriteDictationTranscriptOutput
- (instancetype)initWithDictation:(SLCLDictation *)dictation file:(SLCLAttachmentFile *)file __attribute__((swift_name("init(dictation:file:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAttachmentFile *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLWriteDictationTranscriptOutputSuccess *)doCopyDictation:(SLCLDictation *)dictation file:(SLCLAttachmentFile *)file __attribute__((swift_name("doCopy(dictation:file:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictation __attribute__((swift_name("dictation")));
@property (readonly) SLCLAttachmentFile *file __attribute__((swift_name("file")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WriteDictationTranscriptOutput.UnexpectedError")))
@interface SLCLWriteDictationTranscriptOutputUnexpectedError : SLCLWriteDictationTranscriptOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLWriteDictationTranscriptOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("UuidFactory")))
@protocol SLCLUuidFactory
@required
- (NSString *)doNewUuid4 __attribute__((swift_name("doNewUuid4()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultUuidFactory")))
@interface SLCLDefaultUuidFactory : SLCLBase <SLCLUuidFactory>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)defaultUuidFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultUuidFactory *shared __attribute__((swift_name("shared")));
- (NSString *)doNewUuid4 __attribute__((swift_name("doNewUuid4()")));
@end;

__attribute__((swift_name("Either")))
@interface SLCLEither<__covariant V, __covariant E> : SLCLBase
- (V _Nullable)component1 __attribute__((swift_name("component1()")));
- (E _Nullable)component2 __attribute__((swift_name("component2()")));
- (V _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (SLCLEither<V, E> *)onFailureOnFailure:(void (^)(E _Nullable))onFailure __attribute__((swift_name("onFailure(onFailure:)")));
- (SLCLEither<V, E> *)onSuccessOnSuccess:(void (^)(V _Nullable))onSuccess __attribute__((swift_name("onSuccess(onSuccess:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Failure")))
@interface SLCLFailure<__covariant E> : SLCLEither<SLCLKotlinNothing *, E>
- (instancetype)initWithError:(E _Nullable)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (SLCLKotlinNothing * _Nullable)component1 __attribute__((swift_name("component1()")));
- (E _Nullable)component2 __attribute__((swift_name("component2()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) E _Nullable error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NonCapturingCoroutineExceptionHandler")))
@interface SLCLNonCapturingCoroutineExceptionHandler : SLCLBase
- (instancetype)initWithLogger:(id<SLCLLogger>)logger __attribute__((swift_name("init(logger:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<SLCLKotlinx_coroutines_coreCoroutineExceptionHandler> exceptionHandler __attribute__((swift_name("exceptionHandler")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Success")))
@interface SLCLSuccess<__covariant V> : SLCLEither<V, SLCLKotlinNothing *>
- (instancetype)initWithValue:(V _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (V _Nullable)component1 __attribute__((swift_name("component1()")));
- (SLCLKotlinNothing * _Nullable)component2 __attribute__((swift_name("component2()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) V _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TextUtils")))
@interface SLCLTextUtils : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)textUtils __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLTextUtils *shared __attribute__((swift_name("shared")));
- (BOOL)isValidEmailAddressEmail:(NSString *)email __attribute__((swift_name("isValidEmailAddress(email:)")));
@end;

__attribute__((swift_name("AudioFilePlayer")))
@protocol SLCLAudioFilePlayer
@required
- (void)addListenerListener:(id<SLCLAudioFilePlayerListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (void)pause __attribute__((swift_name("pause()")));
- (void)play __attribute__((swift_name("play()")));
- (void)prepareFilePath:(NSString *)filePath __attribute__((swift_name("prepare(filePath:)")));
- (void)removeListenerListener:(id<SLCLAudioFilePlayerListener>)listener __attribute__((swift_name("removeListener(listener:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)seekMillisecond:(int64_t)millisecond __attribute__((swift_name("seek(millisecond:)")));
@property (readonly) int64_t durationMilliseconds __attribute__((swift_name("durationMilliseconds")));
@property (readonly) int64_t elapsedMilliseconds __attribute__((swift_name("elapsedMilliseconds")));
@property (readonly) BOOL isPlaying __attribute__((swift_name("isPlaying")));
@property (readonly) BOOL isPrepared __attribute__((swift_name("isPrepared")));
@property float playbackSpeed __attribute__((swift_name("playbackSpeed")));
@end;

__attribute__((swift_name("AudioFilePlayerListener")))
@protocol SLCLAudioFilePlayerListener
@required
- (void)onPlaybackPaused __attribute__((swift_name("onPlaybackPaused()")));
- (void)onPlaybackStarted __attribute__((swift_name("onPlaybackStarted()")));
- (void)onPlayerErrorMessage:(NSString *)message __attribute__((swift_name("onPlayerError(message:)")));
- (void)onPlayerPrepared __attribute__((swift_name("onPlayerPrepared()")));
@end;

__attribute__((swift_name("AudioFilePlayerFactory")))
@protocol SLCLAudioFilePlayerFactory
@required
- (id<SLCLAudioFilePlayer>)doNewInstanceLogger:(id<SLCLLogger>)logger __attribute__((swift_name("doNewInstance(logger:)")));
@end;

__attribute__((swift_name("AudioFileRecorder")))
@protocol SLCLAudioFileRecorder
@required
- (void)addBufferListenerListener:(id<SLCLAudioFileRecorderBufferListener>)listener __attribute__((swift_name("addBufferListener(listener:)")));
- (void)addListenerListener_:(id<SLCLAudioFileRecorderListener>)listener __attribute__((swift_name("addListener(listener_:)")));
- (BOOL)createEmptyFileFilePath:(NSString *)filePath audioSettings:(SLCLAudioSettings *)audioSettings __attribute__((swift_name("createEmptyFile(filePath:audioSettings:)")));
- (float)getAudioLevelChannel:(int32_t)channel __attribute__((swift_name("getAudioLevel(channel:)")));
- (void)removeBufferListenerListener:(id<SLCLAudioFileRecorderBufferListener>)listener __attribute__((swift_name("removeBufferListener(listener:)")));
- (void)removeListenerListener_:(id<SLCLAudioFileRecorderListener>)listener __attribute__((swift_name("removeListener(listener_:)")));
- (void)startFilePath:(NSString *)filePath audioSettings:(SLCLAudioSettings *)audioSettings mode:(SLCLAudioFileRecorderMode *)mode startTimeMilliseconds:(int64_t)startTimeMilliseconds audioInput:(SLCLAudioFileRecorderAudioInput *)audioInput __attribute__((swift_name("start(filePath:audioSettings:mode:startTimeMilliseconds:audioInput:)")));
- (void)stop __attribute__((swift_name("stop()")));
@property (readonly) int64_t durationMilliseconds __attribute__((swift_name("durationMilliseconds")));
@property (readonly) int64_t elapsedMilliseconds __attribute__((swift_name("elapsedMilliseconds")));
@property (readonly) BOOL isRecording __attribute__((swift_name("isRecording")));
@end;

__attribute__((swift_name("AudioFileRecorderAudioInput")))
@interface SLCLAudioFileRecorderAudioInput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioFileRecorderAudioInput.FileInput")))
@interface SLCLAudioFileRecorderAudioInputFileInput : SLCLAudioFileRecorderAudioInput
- (instancetype)initWithAbsolutePath:(NSString *)absolutePath iterationCount:(int32_t)iterationCount __attribute__((swift_name("init(absolutePath:iterationCount:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAudioFileRecorderAudioInputFileInput *)doCopyAbsolutePath:(NSString *)absolutePath iterationCount:(int32_t)iterationCount __attribute__((swift_name("doCopy(absolutePath:iterationCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *absolutePath __attribute__((swift_name("absolutePath")));
@property (readonly) int32_t iterationCount __attribute__((swift_name("iterationCount")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioFileRecorderAudioInput.MicrophoneInput")))
@interface SLCLAudioFileRecorderAudioInputMicrophoneInput : SLCLAudioFileRecorderAudioInput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)microphoneInput __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAudioFileRecorderAudioInputMicrophoneInput *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("AudioFileRecorderBufferListener")))
@protocol SLCLAudioFileRecorderBufferListener
@required
- (void)onBufferedData:(SLCLKotlinByteArray *)data __attribute__((swift_name("onBuffered(data:)")));
@property (readonly) int32_t preferredRecordingBufferSize __attribute__((swift_name("preferredRecordingBufferSize")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioFileRecorderCompositionInfo")))
@interface SLCLAudioFileRecorderCompositionInfo : SLCLBase
- (instancetype)initWithTotalDurationMilliseconds:(int64_t)totalDurationMilliseconds startedAtMilliseconds:(int64_t)startedAtMilliseconds stoppedAtMilliseconds:(int64_t)stoppedAtMilliseconds __attribute__((swift_name("init(totalDurationMilliseconds:startedAtMilliseconds:stoppedAtMilliseconds:)"))) __attribute__((objc_designated_initializer));
- (int64_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAudioFileRecorderCompositionInfo *)doCopyTotalDurationMilliseconds:(int64_t)totalDurationMilliseconds startedAtMilliseconds:(int64_t)startedAtMilliseconds stoppedAtMilliseconds:(int64_t)stoppedAtMilliseconds __attribute__((swift_name("doCopy(totalDurationMilliseconds:startedAtMilliseconds:stoppedAtMilliseconds:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=doNewPartDurationMilliseconds) int64_t newPartDurationMilliseconds __attribute__((swift_name("newPartDurationMilliseconds")));
@property (readonly) int64_t startedAtMilliseconds __attribute__((swift_name("startedAtMilliseconds")));
@property (readonly) int64_t stoppedAtMilliseconds __attribute__((swift_name("stoppedAtMilliseconds")));
@property (readonly) int64_t totalDurationMilliseconds __attribute__((swift_name("totalDurationMilliseconds")));
@end;

__attribute__((swift_name("AudioFileRecorderListener")))
@protocol SLCLAudioFileRecorderListener
@required
- (void)onRecorderErrorMessage:(NSString *)message __attribute__((swift_name("onRecorderError(message:)")));
- (void)onRecordingStarted __attribute__((swift_name("onRecordingStarted()")));
- (void)onRecordingStoppedCompositionInfo:(SLCLAudioFileRecorderCompositionInfo *)compositionInfo interrupted:(BOOL)interrupted __attribute__((swift_name("onRecordingStopped(compositionInfo:interrupted:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioFileRecorderMode")))
@interface SLCLAudioFileRecorderMode : SLCLKotlinEnum<SLCLAudioFileRecorderMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLAudioFileRecorderModeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLAudioFileRecorderMode *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLAudioFileRecorderMode *append __attribute__((swift_name("append")));
@property (class, readonly) SLCLAudioFileRecorderMode *insert __attribute__((swift_name("insert")));
@property (class, readonly) SLCLAudioFileRecorderMode *overwrite __attribute__((swift_name("overwrite")));
+ (SLCLKotlinArray<SLCLAudioFileRecorderMode *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioFileRecorderMode.Companion")))
@interface SLCLAudioFileRecorderModeCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAudioFileRecorderModeCompanion *shared __attribute__((swift_name("shared")));
- (SLCLAudioFileRecorderMode *)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((swift_name("AudioFileRecorderFactory")))
@protocol SLCLAudioFileRecorderFactory
@required
- (id<SLCLAudioFileRecorder>)doNewInstanceLogger:(id<SLCLLogger>)logger __attribute__((swift_name("doNewInstance(logger:)")));
@end;

__attribute__((swift_name("AudioFormat")))
@protocol SLCLAudioFormat
@required
@property (readonly) NSString *formatName __attribute__((swift_name("formatName")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioSettings")))
@interface SLCLAudioSettings : SLCLBase
- (instancetype)initWithType:(SLCLAudioType *)type format:(id<SLCLAudioFormat>)format channels:(int32_t)channels sampleRateHz:(int32_t)sampleRateHz bitsPerSample:(int32_t)bitsPerSample bitRate:(int32_t)bitRate blockAlign:(int32_t)blockAlign __attribute__((swift_name("init(type:format:channels:sampleRateHz:bitsPerSample:bitRate:blockAlign:)"))) __attribute__((objc_designated_initializer));
- (SLCLAudioType *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (id<SLCLAudioFormat>)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAudioSettings *)doCopyType:(SLCLAudioType *)type format:(id<SLCLAudioFormat>)format channels:(int32_t)channels sampleRateHz:(int32_t)sampleRateHz bitsPerSample:(int32_t)bitsPerSample bitRate:(int32_t)bitRate blockAlign:(int32_t)blockAlign __attribute__((swift_name("doCopy(type:format:channels:sampleRateHz:bitsPerSample:bitRate:blockAlign:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t bitRate __attribute__((swift_name("bitRate")));
@property (readonly) int32_t bitsPerSample __attribute__((swift_name("bitsPerSample")));
@property (readonly) int32_t blockAlign __attribute__((swift_name("blockAlign")));
@property (readonly) int32_t byteRate __attribute__((swift_name("byteRate")));
@property (readonly) int32_t channels __attribute__((swift_name("channels")));
@property (readonly) id<SLCLAudioFormat> format __attribute__((swift_name("format")));
@property (readonly) int32_t sampleRateHz __attribute__((swift_name("sampleRateHz")));
@property (readonly) SLCLAudioType *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioType")))
@interface SLCLAudioType : SLCLKotlinEnum<SLCLAudioType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLAudioTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLAudioType *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLAudioType *wav __attribute__((swift_name("wav")));
@property (class, readonly) SLCLAudioType *ds2 __attribute__((swift_name("ds2")));
@property (class, readonly) SLCLAudioType *dss __attribute__((swift_name("dss")));
@property (class, readonly) SLCLAudioType *m4a __attribute__((swift_name("m4a")));
@property (class, readonly) SLCLAudioType *wma __attribute__((swift_name("wma")));
@property (class, readonly) SLCLAudioType *dra __attribute__((swift_name("dra")));
@property (class, readonly) SLCLAudioType *mp3 __attribute__((swift_name("mp3")));
+ (SLCLKotlinArray<SLCLAudioType *> *)values __attribute__((swift_name("values()")));
- (id<SLCLAudioFormat>)formatFromIdId:(int32_t)id __attribute__((swift_name("formatFromId(id:)")));
@property (readonly) NSString *extension __attribute__((swift_name("extension")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioType.Companion")))
@interface SLCLAudioTypeCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAudioTypeCompanion *shared __attribute__((swift_name("shared")));
- (SLCLAudioType *)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UnknownAudioFormat")))
@interface SLCLUnknownAudioFormat : SLCLBase <SLCLAudioFormat>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unknownAudioFormat __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUnknownAudioFormat *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *formatName __attribute__((swift_name("formatName")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WavFormat")))
@interface SLCLWavFormat : SLCLKotlinEnum<SLCLWavFormat *> <SLCLAudioFormat>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLWavFormatCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLWavFormat *linearPcm __attribute__((swift_name("linearPcm")));
@property (class, readonly) SLCLWavFormat *philipsAdpcm __attribute__((swift_name("philipsAdpcm")));
+ (SLCLKotlinArray<SLCLWavFormat *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *formatName __attribute__((swift_name("formatName")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WavFormat.Companion")))
@interface SLCLWavFormatCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLWavFormatCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLAudioFormat>)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((swift_name("ConfigSource")))
@protocol SLCLConfigSource
@required
- (BOOL)existsKey:(NSString *)key __attribute__((swift_name("exists(key:)")));
- (BOOL)getKey:(NSString *)key defaultBoolean:(BOOL)defaultBoolean __attribute__((swift_name("get(key:defaultBoolean:)")));
- (double)getKey:(NSString *)key defaultDouble:(double)defaultDouble __attribute__((swift_name("get(key:defaultDouble:)")));
- (float)getKey:(NSString *)key defaultFloat:(float)defaultFloat __attribute__((swift_name("get(key:defaultFloat:)")));
- (int32_t)getKey:(NSString *)key defaultInt:(int32_t)defaultInt __attribute__((swift_name("get(key:defaultInt:)")));
- (int64_t)getKey:(NSString *)key defaultLong:(int64_t)defaultLong __attribute__((swift_name("get(key:defaultLong:)")));
- (NSString *)getKey:(NSString *)key defaultString:(NSString *)defaultString __attribute__((swift_name("get(key:defaultString:)")));
- (NSArray<NSString *> *)getKey:(NSString *)key defaultList:(NSArray<NSString *> *)defaultList __attribute__((swift_name("get(key:defaultList:)")));
- (void)load __attribute__((swift_name("load()")));
@property id<SLCLLogger> _Nullable logger __attribute__((swift_name("logger")));
@property (readonly) NSString *sourceName __attribute__((swift_name("sourceName")));
@end;

__attribute__((swift_name("FeatureFlagsConfig")))
@protocol SLCLFeatureFlagsConfig
@required
- (void)load __attribute__((swift_name("load()")));
@property (readonly) BOOL isDictationFilesEncryptionEnabled __attribute__((swift_name("isDictationFilesEncryptionEnabled")));
@property (readonly) BOOL isDirectAssignmentForSpeechToTextEnabled __attribute__((swift_name("isDirectAssignmentForSpeechToTextEnabled")));
@property (readonly) BOOL isSpeechExecEnterpriseLoginEnabled __attribute__((swift_name("isSpeechExecEnterpriseLoginEnabled")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultFeatureFlagsConfig")))
@interface SLCLDefaultFeatureFlagsConfig : SLCLBase <SLCLFeatureFlagsConfig>
- (instancetype)initWithConfigSource:(id<SLCLConfigSource>)configSource __attribute__((swift_name("init(configSource:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDefaultFeatureFlagsConfigCompanion *companion __attribute__((swift_name("companion")));
- (void)load __attribute__((swift_name("load()")));
@property (readonly) BOOL isDictationFilesEncryptionEnabled __attribute__((swift_name("isDictationFilesEncryptionEnabled")));
@property (readonly) BOOL isDirectAssignmentForSpeechToTextEnabled __attribute__((swift_name("isDirectAssignmentForSpeechToTextEnabled")));
@property (readonly) BOOL isSpeechExecEnterpriseLoginEnabled __attribute__((swift_name("isSpeechExecEnterpriseLoginEnabled")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultFeatureFlagsConfig.Companion")))
@interface SLCLDefaultFeatureFlagsConfigCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultFeatureFlagsConfigCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *KEY_NAME_IS_DICTATION_FILES_ENCRYPTION_ENABLED __attribute__((swift_name("KEY_NAME_IS_DICTATION_FILES_ENCRYPTION_ENABLED")));
@property (readonly) NSString *KEY_NAME_IS_DIRECT_ASSIGNMENT_FOR_SPEECH_TO_TEXT_ENABLED __attribute__((swift_name("KEY_NAME_IS_DIRECT_ASSIGNMENT_FOR_SPEECH_TO_TEXT_ENABLED")));
@property (readonly) NSString *KEY_NAME_IS_SPEECHEXEC_ENTERPRISE_LOGIN_ENABLED __attribute__((swift_name("KEY_NAME_IS_SPEECHEXEC_ENTERPRISE_LOGIN_ENABLED")));
@end;

__attribute__((swift_name("MdmConfig")))
@protocol SLCLMdmConfig
@required
@property (readonly) NSArray<NSString *> *categories __attribute__((swift_name("categories")));
@property (readonly) NSString *defaultCategory __attribute__((swift_name("defaultCategory")));
@property (readonly) NSString *defaultWorktype __attribute__((swift_name("defaultWorktype")));
@property (readonly) NSString *speechExecEnterpriseAuthorityUrl __attribute__((swift_name("speechExecEnterpriseAuthorityUrl")));
@property (readonly) NSString *speechExecEnterpriseBaseUrl __attribute__((swift_name("speechExecEnterpriseBaseUrl")));
@property (readonly) NSString *speechExecEnterpriseClientId __attribute__((swift_name("speechExecEnterpriseClientId")));
@property (readonly) NSString *speechExecEnterpriseRedirectUrl __attribute__((swift_name("speechExecEnterpriseRedirectUrl")));
@property (readonly) NSString *speechExecEnterpriseUsername __attribute__((swift_name("speechExecEnterpriseUsername")));
@property (readonly) NSArray<NSString *> *worktypes __attribute__((swift_name("worktypes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultMdmConfig")))
@interface SLCLDefaultMdmConfig : SLCLBase <SLCLMdmConfig>
- (instancetype)initWithConfigSource:(id<SLCLConfigSource>)configSource __attribute__((swift_name("init(configSource:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDefaultMdmConfigCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSArray<NSString *> *categories __attribute__((swift_name("categories")));
@property (readonly) NSString *defaultCategory __attribute__((swift_name("defaultCategory")));
@property (readonly) NSString *defaultWorktype __attribute__((swift_name("defaultWorktype")));
@property (readonly) NSString *speechExecEnterpriseAuthorityUrl __attribute__((swift_name("speechExecEnterpriseAuthorityUrl")));
@property (readonly) NSString *speechExecEnterpriseBaseUrl __attribute__((swift_name("speechExecEnterpriseBaseUrl")));
@property (readonly) NSString *speechExecEnterpriseClientId __attribute__((swift_name("speechExecEnterpriseClientId")));
@property (readonly) NSString *speechExecEnterpriseRedirectUrl __attribute__((swift_name("speechExecEnterpriseRedirectUrl")));
@property (readonly) NSString *speechExecEnterpriseUsername __attribute__((swift_name("speechExecEnterpriseUsername")));
@property (readonly) NSArray<NSString *> *worktypes __attribute__((swift_name("worktypes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultMdmConfig.Companion")))
@interface SLCLDefaultMdmConfigCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultMdmConfigCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DEFAULT_DICTATION_CATEGORY __attribute__((swift_name("DEFAULT_DICTATION_CATEGORY")));
@property (readonly) NSString *DEFAULT_DICTATION_WORKTYPE __attribute__((swift_name("DEFAULT_DICTATION_WORKTYPE")));
@property (readonly) NSString *DICTATION_CATEGORY __attribute__((swift_name("DICTATION_CATEGORY")));
@property (readonly) NSString *DICTATION_WORKTYPE __attribute__((swift_name("DICTATION_WORKTYPE")));
@property (readonly) NSString *SPEECHEXEC_ENTERPRISE_API_URL_KEY __attribute__((swift_name("SPEECHEXEC_ENTERPRISE_API_URL_KEY")));
@property (readonly) NSString *SPEECHEXEC_ENTERPRISE_AUTHORITY_URL_KEY __attribute__((swift_name("SPEECHEXEC_ENTERPRISE_AUTHORITY_URL_KEY")));
@property (readonly) NSString *SPEECHEXEC_ENTERPRISE_CLIENT_ID_KEY __attribute__((swift_name("SPEECHEXEC_ENTERPRISE_CLIENT_ID_KEY")));
@property (readonly) NSString *SPEECHEXEC_ENTERPRISE_REDIRECT_URL_KEY __attribute__((swift_name("SPEECHEXEC_ENTERPRISE_REDIRECT_URL_KEY")));
@property (readonly) NSString *SPEECHEXEC_ENTERPRISE_USERNAME_KEY __attribute__((swift_name("SPEECHEXEC_ENTERPRISE_USERNAME_KEY")));
@end;

__attribute__((swift_name("ApiError")))
@interface SLCLApiError : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiServerEnvironment")))
@interface SLCLApiServerEnvironment : SLCLKotlinEnum<SLCLApiServerEnvironment *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLApiServerEnvironment *production __attribute__((swift_name("production")));
@property (class, readonly) SLCLApiServerEnvironment *test __attribute__((swift_name("test")));
+ (SLCLKotlinArray<SLCLApiServerEnvironment *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ClientError")))
@interface SLCLClientError : SLCLApiError
- (instancetype)initWithCode:(int32_t)code errorName:(NSString *)errorName message:(NSString *)message userMessage:(NSString *)userMessage cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(code:errorName:message:userMessage:cause:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKotlinThrowable * _Nullable)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLClientError *)doCopyCode:(int32_t)code errorName:(NSString *)errorName message:(NSString *)message userMessage:(NSString *)userMessage cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(code:errorName:message:userMessage:cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) int32_t code __attribute__((swift_name("code")));
@property (readonly) NSString *errorName __attribute__((swift_name("errorName")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *userMessage __attribute__((swift_name("userMessage")));
@end;

__attribute__((swift_name("EndpointConfigStore")))
@protocol SLCLEndpointConfigStore
@required
- (void)clearEndpointsConfiguration __attribute__((swift_name("clearEndpointsConfiguration()")));
- (NSString *)getDictationApiEndpoint __attribute__((swift_name("getDictationApiEndpoint()")));
- (NSString *)getIngestorApiEndpoint __attribute__((swift_name("getIngestorApiEndpoint()")));
- (NSString *)getSttApiEndpoint __attribute__((swift_name("getSttApiEndpoint()")));
- (void)setDictationApiEndpointEndpoint:(NSString *)endpoint __attribute__((swift_name("setDictationApiEndpoint(endpoint:)")));
- (void)setIngestorApiEndpointEndpoint:(NSString *)endpoint __attribute__((swift_name("setIngestorApiEndpoint(endpoint:)")));
- (void)setSttApiEndpointEndpoint:(NSString *)endpoint __attribute__((swift_name("setSttApiEndpoint(endpoint:)")));
@end;

__attribute__((swift_name("NetworkConnectivityMonitor")))
@protocol SLCLNetworkConnectivityMonitor
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getConnectionTypeWithCompletionHandler:(void (^)(SLCLNetworkConnectivityMonitorConnectionType * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getConnectionType(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkConnectivityMonitorConnectionType")))
@interface SLCLNetworkConnectivityMonitorConnectionType : SLCLKotlinEnum<SLCLNetworkConnectivityMonitorConnectionType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLNetworkConnectivityMonitorConnectionType *none __attribute__((swift_name("none")));
@property (class, readonly) SLCLNetworkConnectivityMonitorConnectionType *other __attribute__((swift_name("other")));
@property (class, readonly) SLCLNetworkConnectivityMonitorConnectionType *cellular __attribute__((swift_name("cellular")));
@property (class, readonly) SLCLNetworkConnectivityMonitorConnectionType *wifi __attribute__((swift_name("wifi")));
@property (class, readonly) SLCLNetworkConnectivityMonitorConnectionType *wired __attribute__((swift_name("wired")));
@property (class, readonly) SLCLNetworkConnectivityMonitorConnectionType *loopback __attribute__((swift_name("loopback")));
+ (SLCLKotlinArray<SLCLNetworkConnectivityMonitorConnectionType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((swift_name("NetworkConnectivityMonitorFactory")))
@protocol SLCLNetworkConnectivityMonitorFactory
@required
- (id<SLCLNetworkConnectivityMonitor>)doNewInstanceLogger:(id<SLCLLogger>)logger __attribute__((swift_name("doNewInstance(logger:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkError")))
@interface SLCLNetworkError : SLCLApiError
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (SLCLKotlinThrowable * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLNetworkError *)doCopyCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServerError")))
@interface SLCLServerError : SLCLApiError
- (instancetype)initWithCode:(int32_t)code errorName:(NSString *)errorName message:(NSString *)message userMessage:(NSString *)userMessage error:(SLCLKotlinThrowable * _Nullable)error __attribute__((swift_name("init(code:errorName:message:userMessage:error:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKotlinThrowable * _Nullable)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLServerError *)doCopyCode:(int32_t)code errorName:(NSString *)errorName message:(NSString *)message userMessage:(NSString *)userMessage error:(SLCLKotlinThrowable * _Nullable)error __attribute__((swift_name("doCopy(code:errorName:message:userMessage:error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t code __attribute__((swift_name("code")));
@property (readonly) SLCLKotlinThrowable * _Nullable error __attribute__((swift_name("error")));
@property (readonly) NSString *errorName __attribute__((swift_name("errorName")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *userMessage __attribute__((swift_name("userMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingsEndpointConfigStore")))
@interface SLCLSettingsEndpointConfigStore : SLCLBase <SLCLEndpointConfigStore>
- (instancetype)initWithSettings:(id<SLCLSettings>)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));
- (void)clearEndpointsConfiguration __attribute__((swift_name("clearEndpointsConfiguration()")));
- (NSString *)getDictationApiEndpoint __attribute__((swift_name("getDictationApiEndpoint()")));
- (NSString *)getIngestorApiEndpoint __attribute__((swift_name("getIngestorApiEndpoint()")));
- (NSString *)getSttApiEndpoint __attribute__((swift_name("getSttApiEndpoint()")));
- (void)setDictationApiEndpointEndpoint:(NSString *)endpoint __attribute__((swift_name("setDictationApiEndpoint(endpoint:)")));
- (void)setIngestorApiEndpointEndpoint:(NSString *)endpoint __attribute__((swift_name("setIngestorApiEndpoint(endpoint:)")));
- (void)setSttApiEndpointEndpoint:(NSString *)endpoint __attribute__((swift_name("setSttApiEndpoint(endpoint:)")));
@end;

__attribute__((swift_name("TokenStore")))
@protocol SLCLTokenStore
@required
- (void)clearTokensUserId:(NSString *)userId __attribute__((swift_name("clearTokens(userId:)")));
- (NSString *)getAccessTokenUserId:(NSString *)userId __attribute__((swift_name("getAccessToken(userId:)")));
- (NSString *)getRefreshTokenUserId:(NSString *)userId __attribute__((swift_name("getRefreshToken(userId:)")));
- (NSString *)getTemporaryToken __attribute__((swift_name("getTemporaryToken()")));
- (void)setAccessTokenUserId:(NSString *)userId accessToken:(NSString *)accessToken __attribute__((swift_name("setAccessToken(userId:accessToken:)")));
- (void)setRefreshTokenUserId:(NSString *)userId refreshToken:(NSString *)refreshToken __attribute__((swift_name("setRefreshToken(userId:refreshToken:)")));
- (void)setTemporaryTokenToken:(NSString *)token __attribute__((swift_name("setTemporaryToken(token:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SettingsTokenStore")))
@interface SLCLSettingsTokenStore : SLCLBase <SLCLTokenStore>
- (instancetype)initWithSettings:(id<SLCLSettings>)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));
- (void)clearTokensUserId:(NSString *)userId __attribute__((swift_name("clearTokens(userId:)")));
- (NSString *)getAccessTokenUserId:(NSString *)userId __attribute__((swift_name("getAccessToken(userId:)")));
- (NSString *)getRefreshTokenUserId:(NSString *)userId __attribute__((swift_name("getRefreshToken(userId:)")));
- (NSString *)getTemporaryToken __attribute__((swift_name("getTemporaryToken()")));
- (void)setAccessTokenUserId:(NSString *)userId accessToken:(NSString *)accessToken __attribute__((swift_name("setAccessToken(userId:accessToken:)")));
- (void)setRefreshTokenUserId:(NSString *)userId refreshToken:(NSString *)refreshToken __attribute__((swift_name("setRefreshToken(userId:refreshToken:)")));
- (void)setTemporaryTokenToken:(NSString *)token __attribute__((swift_name("setTemporaryToken(token:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UnexpectedError")))
@interface SLCLUnexpectedError : SLCLApiError
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (SLCLKotlinThrowable * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUnexpectedError *)doCopyCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("doCopy(cause:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JsonWebToken")))
@interface SLCLJsonWebToken : SLCLBase
- (instancetype)initWithHeader:(NSDictionary<NSString *, NSString *> *)header payloadClaims:(NSDictionary<NSString *, NSString *> *)payloadClaims signature:(NSString *)signature __attribute__((swift_name("init(header:payloadClaims:signature:)"))) __attribute__((objc_designated_initializer));
- (NSDictionary<NSString *, NSString *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSDictionary<NSString *, NSString *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLJsonWebToken *)doCopyHeader:(NSDictionary<NSString *, NSString *> *)header payloadClaims:(NSDictionary<NSString *, NSString *> *)payloadClaims signature:(NSString *)signature __attribute__((swift_name("doCopy(header:payloadClaims:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable email __attribute__((swift_name("email")));
@property (readonly) NSDictionary<NSString *, NSString *> *header __attribute__((swift_name("header")));
@property (readonly) NSDictionary<NSString *, NSString *> *payloadClaims __attribute__((swift_name("payloadClaims")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@end;

__attribute__((swift_name("JwtDecoder")))
@protocol SLCLJwtDecoder
@required
- (SLCLJsonWebToken * _Nullable)decodeJwtString:(NSString *)jwtString __attribute__((swift_name("decode(jwtString:)")));
@end;

__attribute__((swift_name("SignalR")))
@protocol SLCLSignalR
@required
- (void)connectUrl:(NSString *)url onError:(void (^)(NSString *))onError onSuccess:(void (^)(id<SLCLSignalRConnection>))onSuccess __attribute__((swift_name("connect(url:onError:onSuccess:)")));
@property id<SLCLLogger> _Nullable logger __attribute__((swift_name("logger")));
@end;

__attribute__((swift_name("SignalRConnection")))
@protocol SLCLSignalRConnection
@required
- (void)invokeMethod:(NSString *)method data:(NSDictionary<NSString *, id> *)data onError:(void (^)(NSString *))onError onSuccess:(void (^)(void))onSuccess __attribute__((swift_name("invoke(method:data:onError:onSuccess:)")));
- (void)onMethod:(NSString *)method listener:(void (^)(NSDictionary<NSString *, id> *))listener __attribute__((swift_name("on(method:listener:)")));
- (void)onCloseHandler:(void (^)(void))handler __attribute__((swift_name("onClose(handler:)")));
- (void)onVoidMethod:(NSString *)method listener:(void (^)(void))listener __attribute__((swift_name("onVoid(method:listener:)")));
- (void)stop __attribute__((swift_name("stop()")));
@property (readonly) SLCLSignalRConnectionState *state __attribute__((swift_name("state")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SignalRConnectionState")))
@interface SLCLSignalRConnectionState : SLCLKotlinEnum<SLCLSignalRConnectionState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLSignalRConnectionState *disconnected __attribute__((swift_name("disconnected")));
@property (class, readonly) SLCLSignalRConnectionState *connecting __attribute__((swift_name("connecting")));
@property (class, readonly) SLCLSignalRConnectionState *connected __attribute__((swift_name("connected")));
+ (SLCLKotlinArray<SLCLSignalRConnectionState *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((swift_name("HttpClientFactory")))
@protocol SLCLHttpClientFactory
@required
- (SLCLKtor_client_coreHttpClient *)doNewClientEngine:(id<SLCLKtor_client_coreHttpClientEngine>)engine __attribute__((swift_name("doNewClient(engine:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultHttpClientFactory")))
@interface SLCLDefaultHttpClientFactory : SLCLBase <SLCLHttpClientFactory>
- (instancetype)initWithAppInfo:(id<SLCLAppInfo>)appInfo environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo __attribute__((swift_name("init(appInfo:environmentInfo:)"))) __attribute__((objc_designated_initializer));
- (SLCLKtor_client_coreHttpClient *)doNewClientEngine:(id<SLCLKtor_client_coreHttpClientEngine>)engine __attribute__((swift_name("doNewClient(engine:)")));
@end;

__attribute__((swift_name("AppInfo")))
@protocol SLCLAppInfo
@required
@property (readonly) NSString *appName __attribute__((swift_name("appName")));
@property (readonly) NSString *appVersion __attribute__((swift_name("appVersion")));
@property (readonly) BOOL debugBuild __attribute__((swift_name("debugBuild")));
@property (readonly) NSString *installId __attribute__((swift_name("installId")));
@end;

__attribute__((swift_name("EnvironmentInfo")))
@protocol SLCLEnvironmentInfo
@required
@property (readonly) NSArray<id<SLCLPath>> *attachedAccessibleStoragePaths __attribute__((swift_name("attachedAccessibleStoragePaths")));
@property (readonly) BOOL isDoNotDisturbPermissionGranted __attribute__((swift_name("isDoNotDisturbPermissionGranted")));
@property (readonly) BOOL isDoNotDisturbPermissionSupported __attribute__((swift_name("isDoNotDisturbPermissionSupported")));
@property (readonly) NSString *iso2country __attribute__((swift_name("iso2country")));
@property (readonly) NSString *iso2language __attribute__((swift_name("iso2language")));
@property (readonly) NSString *manufacturerName __attribute__((swift_name("manufacturerName")));
@property (readonly) NSString *modelName __attribute__((swift_name("modelName")));
@property (readonly) NSString *osName __attribute__((swift_name("osName")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@end;

__attribute__((swift_name("Settings")))
@protocol SLCLSettings
@required
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)existsKey:(NSString *)key __attribute__((swift_name("exists(key:)")));
- (BOOL)getKey:(NSString *)key defaultBoolean:(BOOL)defaultBoolean __attribute__((swift_name("get(key:defaultBoolean:)")));
- (double)getKey:(NSString *)key defaultDouble:(double)defaultDouble __attribute__((swift_name("get(key:defaultDouble:)")));
- (float)getKey:(NSString *)key defaultFloat:(float)defaultFloat __attribute__((swift_name("get(key:defaultFloat:)")));
- (int32_t)getKey:(NSString *)key defaultInt:(int32_t)defaultInt __attribute__((swift_name("get(key:defaultInt:)")));
- (int64_t)getKey:(NSString *)key defaultLong:(int64_t)defaultLong __attribute__((swift_name("get(key:defaultLong:)")));
- (NSString *)getKey:(NSString *)key defaultString:(NSString *)defaultString __attribute__((swift_name("get(key:defaultString:)")));
- (void)putKey:(NSString *)key booleanValue:(BOOL)booleanValue __attribute__((swift_name("put(key:booleanValue:)")));
- (void)putKey:(NSString *)key doubleValue:(double)doubleValue __attribute__((swift_name("put(key:doubleValue:)")));
- (void)putKey:(NSString *)key floatValue:(float)floatValue __attribute__((swift_name("put(key:floatValue:)")));
- (void)putKey:(NSString *)key intValue:(int32_t)intValue __attribute__((swift_name("put(key:intValue:)")));
- (void)putKey:(NSString *)key longValue:(int64_t)longValue __attribute__((swift_name("put(key:longValue:)")));
- (void)putKey:(NSString *)key stringValue:(NSString *)stringValue __attribute__((swift_name("put(key:stringValue:)")));
- (void)removeKey:(NSString *)key __attribute__((swift_name("remove(key:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemorySettings")))
@interface SLCLInMemorySettings : SLCLBase <SLCLSettings>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)existsKey:(NSString *)key __attribute__((swift_name("exists(key:)")));
- (BOOL)getKey:(NSString *)key defaultBoolean:(BOOL)defaultBoolean __attribute__((swift_name("get(key:defaultBoolean:)")));
- (double)getKey:(NSString *)key defaultDouble:(double)defaultDouble __attribute__((swift_name("get(key:defaultDouble:)")));
- (float)getKey:(NSString *)key defaultFloat:(float)defaultFloat __attribute__((swift_name("get(key:defaultFloat:)")));
- (int32_t)getKey:(NSString *)key defaultInt:(int32_t)defaultInt __attribute__((swift_name("get(key:defaultInt:)")));
- (int64_t)getKey:(NSString *)key defaultLong:(int64_t)defaultLong __attribute__((swift_name("get(key:defaultLong:)")));
- (NSString *)getKey:(NSString *)key defaultString:(NSString *)defaultString __attribute__((swift_name("get(key:defaultString:)")));
- (void)putKey:(NSString *)key booleanValue:(BOOL)booleanValue __attribute__((swift_name("put(key:booleanValue:)")));
- (void)putKey:(NSString *)key doubleValue:(double)doubleValue __attribute__((swift_name("put(key:doubleValue:)")));
- (void)putKey:(NSString *)key floatValue:(float)floatValue __attribute__((swift_name("put(key:floatValue:)")));
- (void)putKey:(NSString *)key intValue:(int32_t)intValue __attribute__((swift_name("put(key:intValue:)")));
- (void)putKey:(NSString *)key longValue:(int64_t)longValue __attribute__((swift_name("put(key:longValue:)")));
- (void)putKey:(NSString *)key stringValue:(NSString *)stringValue __attribute__((swift_name("put(key:stringValue:)")));
- (void)removeKey:(NSString *)key __attribute__((swift_name("remove(key:)")));
@end;

__attribute__((swift_name("SettingsFactory")))
@protocol SLCLSettingsFactory
@required
- (id<SLCLSettings>)doNewSettingsLogger:(id<SLCLLogger>)logger __attribute__((swift_name("doNewSettings(logger:)")));
@end;

__attribute__((swift_name("Base64Encoder")))
@protocol SLCLBase64Encoder
@required
- (NSString *)encodeInput:(SLCLKotlinByteArray *)input __attribute__((swift_name("encode(input:)")));
- (NSString *)encodeInput:(NSString *)input inputIsHexString:(BOOL)inputIsHexString __attribute__((swift_name("encode(input:inputIsHexString:)")));
@end;

__attribute__((swift_name("ContentTypeExtractor")))
@protocol SLCLContentTypeExtractor
@required
- (NSString *)extractAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("extract(absolutePath:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ContentTypeExtractorFromExtension")))
@interface SLCLContentTypeExtractorFromExtension : SLCLBase <SLCLContentTypeExtractor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)extractAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("extract(absolutePath:)")));
@end;

__attribute__((swift_name("FileSizeFormatter")))
@protocol SLCLFileSizeFormatter
@required
- (NSString *)formatBytes:(int64_t)bytes __attribute__((swift_name("format(bytes:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultFileSizeFormatter")))
@interface SLCLDefaultFileSizeFormatter : SLCLBase <SLCLFileSizeFormatter>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)formatBytes:(int64_t)bytes __attribute__((swift_name("format(bytes:)")));
@end;

__attribute__((swift_name("Path")))
@protocol SLCLPath
@required
- (BOOL)doCopyAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("doCopy(absolutePath:)")));
- (BOOL)create __attribute__((swift_name("create()")));
- (BOOL)delete __attribute__((swift_name("delete()")));
- (BOOL)moveAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("move(absolutePath:)")));
@property (readonly) NSString *absolutePath __attribute__((swift_name("absolutePath")));
@property (readonly) BOOL exists __attribute__((swift_name("exists")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSArray<NSString *> *pathComponents __attribute__((swift_name("pathComponents")));
@property (readonly) int64_t remainingSpaceBytes __attribute__((swift_name("remainingSpaceBytes")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@end;

__attribute__((swift_name("Directory")))
@protocol SLCLDirectory <SLCLPath>
@required
- (id<SLCLDirectory>)childDirectoryName:(NSString *)name __attribute__((swift_name("childDirectory(name:)")));
- (id<SLCLFile>)childFileName:(NSString *)name __attribute__((swift_name("childFile(name:)")));
@property (readonly) NSArray<id<SLCLPath>> *children __attribute__((swift_name("children")));
@end;

__attribute__((swift_name("File")))
@protocol SLCLFile <SLCLPath>
@required
- (BOOL)appendBytes:(SLCLKotlinByteArray *)bytes __attribute__((swift_name("append(bytes:)")));
- (BOOL)appendContent:(NSString *)content __attribute__((swift_name("append(content:)")));
- (BOOL)overwriteBytes:(SLCLKotlinByteArray *)bytes __attribute__((swift_name("overwrite(bytes:)")));
- (BOOL)overwriteContent:(NSString *)content __attribute__((swift_name("overwrite(content:)")));
- (SLCLKotlinByteArray *)readBytes __attribute__((swift_name("readBytes()")));
- (NSArray<NSString *> *)readLines __attribute__((swift_name("readLines()")));
- (NSString *)readText __attribute__((swift_name("readText()")));
@end;

__attribute__((swift_name("FileArchiver")))
@protocol SLCLFileArchiver
@required
- (id<SLCLFile> _Nullable)archivePath:(NSString *)path overwriteExisting:(BOOL)overwriteExisting __attribute__((swift_name("archive(path:overwriteExisting:)")));
- (BOOL)unarchivePath:(NSString *)path __attribute__((swift_name("unarchive(path:)")));
@end;

__attribute__((swift_name("Hasher")))
@protocol SLCLHasher
@required
- (NSString * _Nullable)hashFileContentsToHexAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("hashFileContentsToHex(absolutePath:)")));
- (NSString *)hashToHexData:(NSString *)data __attribute__((swift_name("hashToHex(data:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryDirectory")))
@interface SLCLInMemoryDirectory : SLCLBase <SLCLDirectory>
- (instancetype)initWithAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("init(absolutePath:)"))) __attribute__((objc_designated_initializer));
- (id<SLCLDirectory>)childDirectoryName:(NSString *)name __attribute__((swift_name("childDirectory(name:)")));
- (id<SLCLFile>)childFileName:(NSString *)name __attribute__((swift_name("childFile(name:)")));
- (BOOL)doCopyAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("doCopy(absolutePath:)")));
- (BOOL)create __attribute__((swift_name("create()")));
- (BOOL)delete __attribute__((swift_name("delete()")));
- (BOOL)moveAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("move(absolutePath:)")));
@property (readonly) NSString *absolutePath __attribute__((swift_name("absolutePath")));
@property (readonly) NSArray<id<SLCLPath>> *children __attribute__((swift_name("children")));
@property (readonly) BOOL exists __attribute__((swift_name("exists")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSArray<NSString *> *pathComponents __attribute__((swift_name("pathComponents")));
@property (readonly) int64_t remainingSpaceBytes __attribute__((swift_name("remainingSpaceBytes")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryFile")))
@interface SLCLInMemoryFile : SLCLBase <SLCLFile>
- (instancetype)initWithAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("init(absolutePath:)"))) __attribute__((objc_designated_initializer));
- (BOOL)appendBytes:(SLCLKotlinByteArray *)bytes __attribute__((swift_name("append(bytes:)")));
- (BOOL)appendContent:(NSString *)content __attribute__((swift_name("append(content:)")));
- (BOOL)doCopyAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("doCopy(absolutePath:)")));
- (BOOL)create __attribute__((swift_name("create()")));
- (BOOL)delete __attribute__((swift_name("delete()")));
- (BOOL)moveAbsolutePath:(NSString *)absolutePath __attribute__((swift_name("move(absolutePath:)")));
- (BOOL)overwriteBytes:(SLCLKotlinByteArray *)bytes __attribute__((swift_name("overwrite(bytes:)")));
- (BOOL)overwriteContent:(NSString *)content __attribute__((swift_name("overwrite(content:)")));
- (SLCLKotlinByteArray *)readBytes __attribute__((swift_name("readBytes()")));
- (NSArray<NSString *> *)readLines __attribute__((swift_name("readLines()")));
- (NSString *)readText __attribute__((swift_name("readText()")));
@property (readonly) NSString *absolutePath __attribute__((swift_name("absolutePath")));
@property (readonly) BOOL exists __attribute__((swift_name("exists")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSArray<NSString *> *pathComponents __attribute__((swift_name("pathComponents")));
@property (readonly) int64_t remainingSpaceBytes __attribute__((swift_name("remainingSpaceBytes")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDefinition")))
@interface SLCLDatabaseDefinition : SLCLBase
- (instancetype)initWithName:(NSString *)name schema:(id<SLCLRuntimeSqlDriverSchema>)schema __attribute__((swift_name("init(name:schema:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (id<SLCLRuntimeSqlDriverSchema>)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDatabaseDefinition *)doCopyName:(NSString *)name schema:(id<SLCLRuntimeSqlDriverSchema>)schema __attribute__((swift_name("doCopy(name:schema:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) id<SLCLRuntimeSqlDriverSchema> schema __attribute__((swift_name("schema")));
@end;

__attribute__((swift_name("PerformAppMigration")))
@protocol SLCLPerformAppMigration
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MigratePlaintextDbToSqlCipher")))
@interface SLCLMigratePlaintextDbToSqlCipher : SLCLBase <SLCLPerformAppMigration>
- (instancetype)initWithDbName:(NSString *)dbName passphrase:(NSString *)passphrase tmpDir:(id<SLCLDirectory>)tmpDir logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dbName:passphrase:tmpDir:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SqlDriverFactory")))
@interface SLCLSqlDriverFactory : SLCLBase
- (instancetype)initWithDatabaseDefinition:(SLCLDatabaseDefinition *)databaseDefinition passphrase:(NSString *)passphrase __attribute__((swift_name("init(databaseDefinition:passphrase:)"))) __attribute__((objc_designated_initializer));
- (id<SLCLRuntimeSqlDriver>)createDriver __attribute__((swift_name("createDriver()")));
@end;

__attribute__((swift_name("DeleteAppTemporaryFiles")))
@protocol SLCLDeleteAppTemporaryFiles
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDeleteAppTemporaryFiles")))
@interface SLCLDefaultDeleteAppTemporaryFiles : SLCLBase <SLCLDeleteAppTemporaryFiles>
- (instancetype)initWithAppTmpDirectory:(id<SLCLDirectory>)appTmpDirectory logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(appTmpDirectory:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MainContextScope")))
@interface SLCLMainContextScope : SLCLBase <SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(mainContext:logger:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((swift_name("AnalyticsLogger")))
@protocol SLCLAnalyticsLogger
@required
- (void)logEventName:(NSString *)name parameters:(NSDictionary<NSString *, id> * _Nullable)parameters __attribute__((swift_name("logEvent(name:parameters:)")));
- (void)logScreenViewName:(NSString *)name __attribute__((swift_name("logScreenView(name:)")));
- (void)setUserPropertyName:(NSString *)name value:(NSString * _Nullable)value __attribute__((swift_name("setUserProperty(name:value:)")));
@property BOOL collectionEnabled __attribute__((swift_name("collectionEnabled")));
@end;

__attribute__((swift_name("AppcuesClient")))
@protocol SLCLAppcuesClient
@required
- (void)anonymousProperties:(NSDictionary<NSString *, id> * _Nullable)properties __attribute__((swift_name("anonymous(properties:)")));
- (void)identifyUserId:(NSString *)userId properties:(NSDictionary<NSString *, id> * _Nullable)properties __attribute__((swift_name("identify(userId:properties:)")));
- (void)reset __attribute__((swift_name("reset()")));
@end;

__attribute__((swift_name("ErrorReporter")))
@protocol SLCLErrorReporter
@required
- (void)reportError:(NSString *)error __attribute__((swift_name("report(error:)")));
- (void)reportOnceKey:(NSString *)key error:(NSString *)error __attribute__((swift_name("reportOnce(key:error:)")));
@end;

__attribute__((swift_name("Logger")))
@protocol SLCLLogger
@required
- (void)dMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("d(message:error:)")));
- (void)eMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("e(message:error:)")));
- (void)iMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("i(message:error:)")));
- (void)vMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("v(message:error:)")));
- (void)wMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("w(message:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CombinedLogger")))
@interface SLCLCombinedLogger : SLCLBase <SLCLLogger>
- (instancetype)initWithLoggers:(NSArray<id<SLCLLogger>> *)loggers __attribute__((swift_name("init(loggers:)"))) __attribute__((objc_designated_initializer));
- (void)dMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("d(message:error:)")));
- (void)eMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("e(message:error:)")));
- (void)iMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("i(message:error:)")));
- (void)vMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("v(message:error:)")));
- (void)wMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("w(message:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultLogger")))
@interface SLCLDefaultLogger : SLCLBase <SLCLLogger>
- (instancetype)initWithTag:(NSString *)tag formatter:(id<SLCLLogFormatter>)formatter writer:(id<SLCLLogWriter>)writer __attribute__((swift_name("init(tag:formatter:writer:)"))) __attribute__((objc_designated_initializer));
- (void)dMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("d(message:error:)")));
- (void)eMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("e(message:error:)")));
- (void)iMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("i(message:error:)")));
- (void)vMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("v(message:error:)")));
- (void)wMessage:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("w(message:error:)")));
@end;

__attribute__((swift_name("LogFormatter")))
@protocol SLCLLogFormatter
@required
- (NSString *)formatLevel:(SLCLLogLevel *)level tag:(NSString *)tag message:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("format(level:tag:message:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogLevel")))
@interface SLCLLogLevel : SLCLKotlinEnum<SLCLLogLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLLogLevel *verbose __attribute__((swift_name("verbose")));
@property (class, readonly) SLCLLogLevel *debug __attribute__((swift_name("debug")));
@property (class, readonly) SLCLLogLevel *info __attribute__((swift_name("info")));
@property (class, readonly) SLCLLogLevel *warning __attribute__((swift_name("warning")));
@property (class, readonly) SLCLLogLevel *error __attribute__((swift_name("error")));
+ (SLCLKotlinArray<SLCLLogLevel *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((swift_name("LogReader")))
@protocol SLCLLogReader
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readWithCompletionHandler:(void (^)(id<SLCLKotlinx_coroutines_coreFlow> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("read(completionHandler:)")));
@end;

__attribute__((swift_name("LogWriter")))
@protocol SLCLLogWriter
@required
- (void)writeMessage:(NSString *)message __attribute__((swift_name("write(message:)")));
@property (readonly) BOOL hasTimestamps __attribute__((swift_name("hasTimestamps")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintLogWriter")))
@interface SLCLPrintLogWriter : SLCLBase <SLCLLogWriter>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)writeMessage:(NSString *)message __attribute__((swift_name("write(message:)")));
@property (readonly) BOOL hasTimestamps __attribute__((swift_name("hasTimestamps")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RotatingFileLogReader")))
@interface SLCLRotatingFileLogReader : SLCLBase <SLCLLogReader>
- (instancetype)initWithLogsDir:(id<SLCLDirectory>)logsDir encryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider __attribute__((swift_name("init(logsDir:encryptionProvider:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readWithCompletionHandler:(void (^)(id<SLCLKotlinx_coroutines_coreFlow> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("read(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RotatingFileLogWriter")))
@interface SLCLRotatingFileLogWriter : SLCLBase <SLCLLogWriter>
- (instancetype)initWithLogsDir:(id<SLCLDirectory>)logsDir daysToLog:(int32_t)daysToLog timeProvider:(id<SLCLTimeProvider>)timeProvider timeFormatter:(id<SLCLTimeFormatter>)timeFormatter fileSizeFormatter:(id<SLCLFileSizeFormatter>)fileSizeFormatter environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo appInfo:(id<SLCLAppInfo>)appInfo encryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider __attribute__((swift_name("init(logsDir:daysToLog:timeProvider:timeFormatter:fileSizeFormatter:environmentInfo:appInfo:encryptionProvider:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLRotatingFileLogWriterCompanion *companion __attribute__((swift_name("companion")));
- (void)writeMessage:(NSString *)message __attribute__((swift_name("write(message:)")));
@property (readonly) BOOL hasTimestamps __attribute__((swift_name("hasTimestamps")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RotatingFileLogWriter.Companion")))
@interface SLCLRotatingFileLogWriterCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRotatingFileLogWriterCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *LOG_DELIMITER __attribute__((swift_name("LOG_DELIMITER")));
@property (readonly) NSString *LOG_FILE_NAME_TIME_FORMAT __attribute__((swift_name("LOG_FILE_NAME_TIME_FORMAT")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechLiveLogFormatter")))
@interface SLCLSpeechLiveLogFormatter : SLCLBase <SLCLLogFormatter>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)formatLevel:(SLCLLogLevel *)level tag:(NSString *)tag message:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("format(level:tag:message:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimestampedLogFormatter")))
@interface SLCLTimestampedLogFormatter : SLCLBase <SLCLLogFormatter>
- (instancetype)initWithLogFormatter:(id<SLCLLogFormatter>)logFormatter timeProvider:(id<SLCLTimeProvider>)timeProvider timeFormatter:(id<SLCLTimeFormatter>)timeFormatter __attribute__((swift_name("init(logFormatter:timeProvider:timeFormatter:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLTimestampedLogFormatterCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)formatLevel:(SLCLLogLevel *)level tag:(NSString *)tag message:(NSString *)message error:(NSString * _Nullable)error __attribute__((swift_name("format(level:tag:message:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimestampedLogFormatter.Companion")))
@interface SLCLTimestampedLogFormatterCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLTimestampedLogFormatterCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *TIMESTAMP_FORMAT __attribute__((swift_name("TIMESTAMP_FORMAT")));
@end;

__attribute__((swift_name("EncryptionProvider")))
@protocol SLCLEncryptionProvider
@required
- (id<SLCLFile> _Nullable)decryptFileFile:(id<SLCLFile>)file __attribute__((swift_name("decryptFile(file:)")));
- (NSString *)decryptLogLineMessage:(NSString *)message __attribute__((swift_name("decryptLogLine(message:)")));
- (BOOL)encryptFileFile:(id<SLCLFile>)file __attribute__((swift_name("encryptFile(file:)")));
- (NSString *)encryptLogLineMessage:(NSString *)message __attribute__((swift_name("encryptLogLine(message:)")));
- (BOOL)isFileEncryptedFile:(id<SLCLFile>)file __attribute__((swift_name("isFileEncrypted(file:)")));
- (void)setLoggerLogger:(id<SLCLLogger>)logger __attribute__((swift_name("setLogger(logger:)")));
@property (readonly) NSString *databaseEncryptionPassphrase __attribute__((swift_name("databaseEncryptionPassphrase")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DummyEncryptionProvider")))
@interface SLCLDummyEncryptionProvider : SLCLBase <SLCLEncryptionProvider>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<SLCLFile>)decryptFileFile:(id<SLCLFile>)file __attribute__((swift_name("decryptFile(file:)")));
- (NSString *)decryptLogLineMessage:(NSString *)message __attribute__((swift_name("decryptLogLine(message:)")));
- (BOOL)encryptFileFile:(id<SLCLFile>)file __attribute__((swift_name("encryptFile(file:)")));
- (NSString *)encryptLogLineMessage:(NSString *)message __attribute__((swift_name("encryptLogLine(message:)")));
- (BOOL)isFileEncryptedFile:(id<SLCLFile>)file __attribute__((swift_name("isFileEncrypted(file:)")));
- (void)setLoggerLogger:(id<SLCLLogger>)logger __attribute__((swift_name("setLogger(logger:)")));
@property (readonly) NSString *databaseEncryptionPassphrase __attribute__((swift_name("databaseEncryptionPassphrase")));
@end;

__attribute__((swift_name("TimeFormatter")))
@protocol SLCLTimeFormatter
@required
- (NSString *)formatMillisecondsUtc:(int64_t)millisecondsUtc format:(NSString *)format useLocalTimeZone:(BOOL)useLocalTimeZone __attribute__((swift_name("format(millisecondsUtc:format:useLocalTimeZone:)")));
- (int64_t)parseTime:(NSString *)time format:(NSString *)format useLocalTimeZone:(BOOL)useLocalTimeZone __attribute__((swift_name("parse(time:format:useLocalTimeZone:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IosTimeFormatter")))
@interface SLCLIosTimeFormatter : SLCLBase <SLCLTimeFormatter>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)formatMillisecondsUtc:(int64_t)millisecondsUtc format:(NSString *)format useLocalTimeZone:(BOOL)useLocalTimeZone __attribute__((swift_name("format(millisecondsUtc:format:useLocalTimeZone:)")));
- (int64_t)parseTime:(NSString *)time format:(NSString *)format useLocalTimeZone:(BOOL)useLocalTimeZone __attribute__((swift_name("parse(time:format:useLocalTimeZone:)")));
@end;

__attribute__((swift_name("TimeProvider")))
@protocol SLCLTimeProvider
@required
@property (readonly) int64_t millisecondsUtc __attribute__((swift_name("millisecondsUtc")));
@end;

__attribute__((swift_name("DictationPropertiesContract")))
@protocol SLCLDictationPropertiesContract
@required
@end;

__attribute__((swift_name("DictationPropertiesContractPresenter")))
@protocol SLCLDictationPropertiesContractPresenter <SLCLBasePresenter>
@required
- (void)onAddImageFromCameraClick __attribute__((swift_name("onAddImageFromCameraClick()")));
- (void)onAddImageFromGalleryClick __attribute__((swift_name("onAddImageFromGalleryClick()")));
- (void)onCloseClick __attribute__((swift_name("onCloseClick()")));
- (void)onNewImageAttachmentSelectedImageFile:(id<SLCLFile>)imageFile __attribute__((swift_name("onNewImageAttachmentSelected(imageFile:)")));
- (void)onOpenImageAttachmentClickImageFile:(id<SLCLFile>)imageFile __attribute__((swift_name("onOpenImageAttachmentClick(imageFile:)")));
- (void)onPropertyChangedProperty:(SLCLDictationProperty *)property __attribute__((swift_name("onPropertyChanged(property:)")));
- (void)onPropertyFocusProperty:(SLCLDictationProperty *)property __attribute__((swift_name("onPropertyFocus(property:)")));
- (void)onPropertySuggestionDeleteClickProperty:(SLCLDictationProperty *)property text:(NSString *)text __attribute__((swift_name("onPropertySuggestionDeleteClick(property:text:)")));
- (void)onPropertySuggestionSelectedProperty:(SLCLDictationProperty *)property __attribute__((swift_name("onPropertySuggestionSelected(property:)")));
- (void)onRemoveAttachmentClickAttachment:(SLCLAttachmentFile *)attachment __attribute__((swift_name("onRemoveAttachmentClick(attachment:)")));
- (void)onScanBarcodeClick __attribute__((swift_name("onScanBarcodeClick()")));
@end;

__attribute__((swift_name("DictationPropertiesContractView")))
@protocol SLCLDictationPropertiesContractView <SLCLBaseView>
@required
- (void)close __attribute__((swift_name("close()")));
- (void)decorateForServiceService:(SLCLService *)service __attribute__((swift_name("decorateForService(service:)")));
- (void)hideAddAttachmentButton __attribute__((swift_name("hideAddAttachmentButton()")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)showAddAttachmentButton __attribute__((swift_name("showAddAttachmentButton()")));
- (void)showBarcodeScanner __attribute__((swift_name("showBarcodeScanner()")));
- (void)showCameraForAddingAttachment __attribute__((swift_name("showCameraForAddingAttachment()")));
- (void)showFileSystemError __attribute__((swift_name("showFileSystemError()")));
- (void)showGalleryForAddingAttachment __attribute__((swift_name("showGalleryForAddingAttachment()")));
- (void)showImageAttachmentsGalleryAttachments:(NSArray<SLCLAttachment *> *)attachments currentIndex:(int32_t)currentIndex __attribute__((swift_name("showImageAttachmentsGallery(attachments:currentIndex:)")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showPropertiesProperties:(NSArray<SLCLDictationProperty *> *)properties attachmentFiles:(NSArray<SLCLAttachmentFile *> *)attachmentFiles readOnly:(BOOL)readOnly __attribute__((swift_name("showProperties(properties:attachmentFiles:readOnly:)")));
- (void)showPropertySuggestionsProperty:(SLCLDictationProperty *)property suggestions:(NSArray<NSString *> *)suggestions __attribute__((swift_name("showPropertySuggestions(property:suggestions:)")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationPropertiesPresenter")))
@interface SLCLDictationPropertiesPresenter : SLCLBase <SLCLDictationPropertiesContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger dictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy readOnly:(BOOL)readOnly applyDictationPropertyChange:(id<SLCLApplyDictationPropertyChange>)applyDictationPropertyChange getDictationPropertyList:(id<SLCLGetDictationPropertyList>)getDictationPropertyList createAttachment:(id<SLCLCreateAttachment>)createAttachment getAttachmentFiles:(id<SLCLGetAttachmentFiles>)getAttachmentFiles sortAttachmentFiles:(id<SLCLSortAttachmentFiles>)sortAttachmentFiles checkImageAttachmentLimit:(id<SLCLCheckImageAttachmentLimit>)checkImageAttachmentLimit deleteAttachment:(id<SLCLDeleteAttachment>)deleteAttachment propertySuggestionsRepository:(id<SLCLPropertySuggestionsRepository>)propertySuggestionsRepository getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser __attribute__((swift_name("init(mainContext:logger:dictationWorkingCopy:readOnly:applyDictationPropertyChange:getDictationPropertyList:createAttachment:getAttachmentFiles:sortAttachmentFiles:checkImageAttachmentLimit:deleteAttachment:propertySuggestionsRepository:getCurrentUser:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAddImageFromCameraClick __attribute__((swift_name("onAddImageFromCameraClick()")));
- (void)onAddImageFromGalleryClick __attribute__((swift_name("onAddImageFromGalleryClick()")));
- (void)onAttachViewView:(id<SLCLDictationPropertiesContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onCloseClick __attribute__((swift_name("onCloseClick()")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onNewImageAttachmentSelectedImageFile:(id<SLCLFile>)imageFile __attribute__((swift_name("onNewImageAttachmentSelected(imageFile:)")));
- (void)onOpenImageAttachmentClickImageFile:(id<SLCLFile>)imageFile __attribute__((swift_name("onOpenImageAttachmentClick(imageFile:)")));
- (void)onPropertyChangedProperty:(SLCLDictationProperty *)property __attribute__((swift_name("onPropertyChanged(property:)")));
- (void)onPropertyFocusProperty:(SLCLDictationProperty *)property __attribute__((swift_name("onPropertyFocus(property:)")));
- (void)onPropertySuggestionDeleteClickProperty:(SLCLDictationProperty *)property text:(NSString *)text __attribute__((swift_name("onPropertySuggestionDeleteClick(property:text:)")));
- (void)onPropertySuggestionSelectedProperty:(SLCLDictationProperty *)property __attribute__((swift_name("onPropertySuggestionSelected(property:)")));
- (void)onRemoveAttachmentClickAttachment:(SLCLAttachmentFile *)attachment __attribute__((swift_name("onRemoveAttachmentClick(attachment:)")));
- (void)onScanBarcodeClick __attribute__((swift_name("onScanBarcodeClick()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLDictationPropertiesContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("ApplyDictationPropertyChange")))
@protocol SLCLApplyDictationPropertyChange
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation property:(SLCLDictationProperty *)property completionHandler:(void (^)(SLCLDictation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:property:completionHandler:)")));
@end;

__attribute__((swift_name("CheckImageAttachmentLimit")))
@protocol SLCLCheckImageAttachmentLimit
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachments:(NSArray<SLCLAttachmentFile *> *)attachments completionHandler:(void (^)(SLCLCheckImageAttachmentLimitOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachments:completionHandler:)")));
@end;

__attribute__((swift_name("CheckImageAttachmentLimitOutput")))
@interface SLCLCheckImageAttachmentLimitOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckImageAttachmentLimitOutput.LimitNotReached")))
@interface SLCLCheckImageAttachmentLimitOutputLimitNotReached : SLCLCheckImageAttachmentLimitOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)limitNotReached __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCheckImageAttachmentLimitOutputLimitNotReached *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckImageAttachmentLimitOutput.LimitReached")))
@interface SLCLCheckImageAttachmentLimitOutputLimitReached : SLCLCheckImageAttachmentLimitOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)limitReached __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCheckImageAttachmentLimitOutputLimitReached *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckImageAttachmentLimitOutput.UserNotAuthenticated")))
@interface SLCLCheckImageAttachmentLimitOutputUserNotAuthenticated : SLCLCheckImageAttachmentLimitOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCheckImageAttachmentLimitOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("CreateAttachment")))
@protocol SLCLCreateAttachment
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationId:(NSString *)dictationId file:(id<SLCLFile>)file category:(SLCLDictationFileCategory *)category completionHandler:(void (^)(SLCLCreateAttachmentOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationId:file:category:completionHandler:)")));
@end;

__attribute__((swift_name("CreateAttachmentOutput")))
@interface SLCLCreateAttachmentOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateAttachmentOutput.FileSystemError")))
@interface SLCLCreateAttachmentOutputFileSystemError : SLCLCreateAttachmentOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateAttachmentOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateAttachmentOutput.Success")))
@interface SLCLCreateAttachmentOutputSuccess : SLCLCreateAttachmentOutput
- (instancetype)initWithAttachmentFile:(SLCLAttachmentFile *)attachmentFile __attribute__((swift_name("init(attachmentFile:)"))) __attribute__((objc_designated_initializer));
- (SLCLAttachmentFile *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLCreateAttachmentOutputSuccess *)doCopyAttachmentFile:(SLCLAttachmentFile *)attachmentFile __attribute__((swift_name("doCopy(attachmentFile:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLAttachmentFile *attachmentFile __attribute__((swift_name("attachmentFile")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateAttachmentOutput.UnexpectedError")))
@interface SLCLCreateAttachmentOutputUnexpectedError : SLCLCreateAttachmentOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateAttachmentOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultApplyDictationPropertyChange")))
@interface SLCLDefaultApplyDictationPropertyChange : SLCLBase <SLCLApplyDictationPropertyChange>
- (instancetype)initWithTimeProvider:(id<SLCLTimeProvider>)timeProvider dictationRepository:(id<SLCLDictationRepository>)dictationRepository __attribute__((swift_name("init(timeProvider:dictationRepository:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation property:(SLCLDictationProperty *)property completionHandler:(void (^)(SLCLDictation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:property:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckImageAttachmentLimit")))
@interface SLCLDefaultCheckImageAttachmentLimit : SLCLBase <SLCLCheckImageAttachmentLimit>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachments:(NSArray<SLCLAttachmentFile *> *)attachments completionHandler:(void (^)(SLCLCheckImageAttachmentLimitOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachments:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCreateAttachment")))
@interface SLCLDefaultCreateAttachment : SLCLBase <SLCLCreateAttachment>
- (instancetype)initWithAttachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository uuidFactory:(id<SLCLUuidFactory>)uuidFactory timeProvider:(id<SLCLTimeProvider>)timeProvider contentTypeExtractor:(id<SLCLContentTypeExtractor>)contentTypeExtractor getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository encryptFile:(id<SLCLEncryptFile>)encryptFile logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(attachmentRepository:uuidFactory:timeProvider:contentTypeExtractor:getCurrentUser:dictationFilesRepository:encryptFile:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationId:(NSString *)dictationId file:(id<SLCLFile>)file category:(SLCLDictationFileCategory *)category completionHandler:(void (^)(SLCLCreateAttachmentOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationId:file:category:completionHandler:)")));
@end;

__attribute__((swift_name("DeleteAttachment")))
@protocol SLCLDeleteAttachment
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachment:(SLCLAttachment *)attachment completionHandler:(void (^)(SLCLDeleteAttachmentOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachment:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDeleteAttachment")))
@interface SLCLDefaultDeleteAttachment : SLCLBase <SLCLDeleteAttachment>
- (instancetype)initWithAttachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(attachmentRepository:dictationFilesRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachment:(SLCLAttachment *)attachment completionHandler:(void (^)(SLCLDeleteAttachmentOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachment:completionHandler:)")));
@end;

__attribute__((swift_name("GetDictationPropertyList")))
@protocol SLCLGetDictationPropertyList
@required
- (NSArray<SLCLDictationProperty *> *)invokeDictation:(SLCLDictation *)dictation __attribute__((swift_name("invoke(dictation:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetDictationPropertyList")))
@interface SLCLDefaultGetDictationPropertyList : SLCLBase <SLCLGetDictationPropertyList>
- (instancetype)initWithUserRepository:(id<SLCLUserRepository>)userRepository __attribute__((swift_name("init(userRepository:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLDictationProperty *> *)invokeDictation:(SLCLDictation *)dictation __attribute__((swift_name("invoke(dictation:)")));
@end;

__attribute__((swift_name("DeleteAttachmentOutput")))
@interface SLCLDeleteAttachmentOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteAttachmentOutput.FileSystemError")))
@interface SLCLDeleteAttachmentOutputFileSystemError : SLCLDeleteAttachmentOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteAttachmentOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteAttachmentOutput.Success")))
@interface SLCLDeleteAttachmentOutputSuccess : SLCLDeleteAttachmentOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteAttachmentOutputSuccess *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("SortAttachmentFiles")))
@protocol SLCLSortAttachmentFiles
@required
- (NSArray<SLCLAttachmentFile *> *)invokeAttachmentFiles:(NSArray<SLCLAttachmentFile *> *)attachmentFiles __attribute__((swift_name("invoke(attachmentFiles:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SortAttachmentFilesForPropertiesView")))
@interface SLCLSortAttachmentFilesForPropertiesView : SLCLBase <SLCLSortAttachmentFiles>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSArray<SLCLAttachmentFile *> *)invokeAttachmentFiles:(NSArray<SLCLAttachmentFile *> *)attachmentFiles __attribute__((swift_name("invoke(attachmentFiles:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseCheckImageAttachmentLimit")))
@interface SLCLSpeechExecEnterpriseCheckImageAttachmentLimit : SLCLBase <SLCLCheckImageAttachmentLimit>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachments:(NSArray<SLCLAttachmentFile *> *)attachments completionHandler:(void (^)(SLCLCheckImageAttachmentLimitOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachments:completionHandler:)")));
@end;

__attribute__((swift_name("DictationPropertyData")))
@interface SLCLDictationPropertyData : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BooleanData")))
@interface SLCLBooleanData : SLCLDictationPropertyData
- (instancetype)initWithValue:(BOOL)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLBooleanData *)doCopyValue:(BOOL)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationProperty")))
@interface SLCLDictationProperty : SLCLBase
- (instancetype)initWithType:(SLCLDictationPropertyType *)type data:(SLCLDictationPropertyData *)data __attribute__((swift_name("init(type:data:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictationPropertyType *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictationPropertyData *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictationProperty *)doCopyType:(SLCLDictationPropertyType *)type data:(SLCLDictationPropertyData *)data __attribute__((swift_name("doCopy(type:data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictationPropertyData *data __attribute__((swift_name("data")));
@property (readonly) SLCLDictationPropertyType *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationPropertyType")))
@interface SLCLDictationPropertyType : SLCLKotlinEnum<SLCLDictationPropertyType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLDictationPropertyType *title __attribute__((swift_name("title")));
@property (class, readonly) SLCLDictationPropertyType *authorName __attribute__((swift_name("authorName")));
@property (class, readonly) SLCLDictationPropertyType *createdDate __attribute__((swift_name("createdDate")));
@property (class, readonly) SLCLDictationPropertyType *lastModifiedDate __attribute__((swift_name("lastModifiedDate")));
@property (class, readonly) SLCLDictationPropertyType *state __attribute__((swift_name("state")));
@property (class, readonly) SLCLDictationPropertyType *priority __attribute__((swift_name("priority")));
@property (class, readonly) SLCLDictationPropertyType *workType __attribute__((swift_name("workType")));
@property (class, readonly) SLCLDictationPropertyType *category __attribute__((swift_name("category")));
@property (class, readonly) SLCLDictationPropertyType *department __attribute__((swift_name("department")));
@property (class, readonly) SLCLDictationPropertyType *keyword __attribute__((swift_name("keyword")));
@property (class, readonly) SLCLDictationPropertyType *barcode __attribute__((swift_name("barcode")));
@property (class, readonly) SLCLDictationPropertyType *customAttribute1 __attribute__((swift_name("customAttribute1")));
@property (class, readonly) SLCLDictationPropertyType *customAttribute2 __attribute__((swift_name("customAttribute2")));
@property (class, readonly) SLCLDictationPropertyType *customAttribute3 __attribute__((swift_name("customAttribute3")));
@property (class, readonly) SLCLDictationPropertyType *customAttribute4 __attribute__((swift_name("customAttribute4")));
@property (class, readonly) SLCLDictationPropertyType *customAttribute5 __attribute__((swift_name("customAttribute5")));
@property (class, readonly) SLCLDictationPropertyType *comment __attribute__((swift_name("comment")));
@property (class, readonly) SLCLDictationPropertyType *dueDate __attribute__((swift_name("dueDate")));
+ (SLCLKotlinArray<SLCLDictationPropertyType *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IntData")))
@interface SLCLIntData : SLCLDictationPropertyData
- (instancetype)initWithValue:(int32_t)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLIntData *)doCopyValue:(int32_t)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MillisecondsUtcData")))
@interface SLCLMillisecondsUtcData : SLCLDictationPropertyData
- (instancetype)initWithValue:(int64_t)value userEditable:(BOOL)userEditable __attribute__((swift_name("init(value:userEditable:)"))) __attribute__((objc_designated_initializer));
- (int64_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLMillisecondsUtcData *)doCopyValue:(int64_t)value userEditable:(BOOL)userEditable __attribute__((swift_name("doCopy(value:userEditable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL userEditable __attribute__((swift_name("userEditable")));
@property (readonly) int64_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Priority")))
@interface SLCLPriority : SLCLKotlinEnum<SLCLPriority *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLPriorityCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLPriority *standard __attribute__((swift_name("standard")));
@property (class, readonly) SLCLPriority *high __attribute__((swift_name("high")));
@property (class, readonly) SLCLPriority *critical __attribute__((swift_name("critical")));
+ (SLCLKotlinArray<SLCLPriority *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Priority.Companion")))
@interface SLCLPriorityCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPriorityCompanion *shared __attribute__((swift_name("shared")));
- (SLCLPriority *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PriorityData")))
@interface SLCLPriorityData : SLCLDictationPropertyData
- (instancetype)initWithValue:(SLCLPriority *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (SLCLPriority *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLPriorityData *)doCopyValue:(SLCLPriority *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLPriority *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TextData")))
@interface SLCLTextData : SLCLDictationPropertyData
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLTextData *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("PropertySuggestionsRepository")))
@protocol SLCLPropertySuggestionsRepository
@required
- (void)addPropertySuggestionType:(int32_t)type value:(NSString *)value __attribute__((swift_name("addPropertySuggestion(type:value:)")));
- (void)addPropertySuggestionsType:(int32_t)type values:(NSArray<NSString *> *)values __attribute__((swift_name("addPropertySuggestions(type:values:)")));
- (void)deletePropertySuggestionType:(int32_t)type value:(NSString *)value __attribute__((swift_name("deletePropertySuggestion(type:value:)")));
- (NSArray<NSString *> *)getPropertySuggestionsType:(int32_t)type __attribute__((swift_name("getPropertySuggestions(type:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultPropertySuggestionsRepository")))
@interface SLCLDefaultPropertySuggestionsRepository : SLCLBase <SLCLPropertySuggestionsRepository>
- (instancetype)initWithSettings:(id<SLCLSettings>)settings appSettings:(id<SLCLAppSettings>)appSettings logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(settings:appSettings:logger:)"))) __attribute__((objc_designated_initializer));
- (void)addPropertySuggestionType:(int32_t)type value:(NSString *)value __attribute__((swift_name("addPropertySuggestion(type:value:)")));
- (void)addPropertySuggestionsType:(int32_t)type values:(NSArray<NSString *> *)values __attribute__((swift_name("addPropertySuggestions(type:values:)")));
- (void)deletePropertySuggestionType:(int32_t)type value:(NSString *)value __attribute__((swift_name("deletePropertySuggestion(type:value:)")));
- (NSArray<NSString *> *)getPropertySuggestionsType:(int32_t)type __attribute__((swift_name("getPropertySuggestions(type:)")));
@property (readonly) SLCLMutableDictionary<NSString *, NSArray<NSString *> *> *suggestions __attribute__((swift_name("suggestions")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertySuggestions")))
@interface SLCLPropertySuggestions : SLCLBase
- (instancetype)initWithSuggestions:(SLCLMutableDictionary<SLCLInt *, NSMutableArray<NSString *> *> *)suggestions __attribute__((swift_name("init(suggestions:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLPropertySuggestionsCompanion *companion __attribute__((swift_name("companion")));
- (SLCLMutableDictionary<SLCLInt *, NSMutableArray<NSString *> *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLPropertySuggestions *)doCopySuggestions:(SLCLMutableDictionary<SLCLInt *, NSMutableArray<NSString *> *> *)suggestions __attribute__((swift_name("doCopy(suggestions:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLMutableDictionary<SLCLInt *, NSMutableArray<NSString *> *> *suggestions __attribute__((swift_name("suggestions")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertySuggestions.Companion")))
@interface SLCLPropertySuggestionsCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPropertySuggestionsCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("ComponentRegistry")))
@protocol SLCLComponentRegistry
@required
- (id<SLCLAboutContractPresenter>)aboutPresenter __attribute__((swift_name("aboutPresenter()")));
- (id<SLCLApplicationContractPresenter>)applicationPresenter __attribute__((swift_name("applicationPresenter()")));
- (id<SLCLDictationListContractPresenter>)dictationListPresenter __attribute__((swift_name("dictationListPresenter()")));
- (id<SLCLDictationPropertiesContractPresenter>)dictationPropertiesPresenterDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy readOnly:(BOOL)readOnly __attribute__((swift_name("dictationPropertiesPresenter(dictationWorkingCopy:readOnly:)")));
- (id<SLCLLogger>)loggerTag:(NSString *)tag __attribute__((swift_name("logger(tag:)")));
- (id<SLCLPlayerContractPresenter>)playerPresenter __attribute__((swift_name("playerPresenter()")));
- (id<SLCLRecorderContractPresenter>)recorderPresenterWorkingCopy:(SLCLDictation *)workingCopy isExistingDictation:(BOOL)isExistingDictation __attribute__((swift_name("recorderPresenter(workingCopy:isExistingDictation:)")));
- (id<SLCLSecurityPromptContractPresenter>)securityPromptPresenterShownFromAppStart:(BOOL)shownFromAppStart __attribute__((swift_name("securityPromptPresenter(shownFromAppStart:)")));
- (id<SLCLSettingsContractPresenter>)settingsPresenter __attribute__((swift_name("settingsPresenter()")));
- (id<SLCLSpeechExecEnterpriseLoginContractPresenter>)speechExecEnterpriseLoginPresenter __attribute__((swift_name("speechExecEnterpriseLoginPresenter()")));
- (id<SLCLSpeechLiveLoginContractPresenter>)speechLiveLoginPresenter __attribute__((swift_name("speechLiveLoginPresenter()")));
- (id<SLCLSpeechToTextRecorderContractPresenter>)speechToTextRecorderPresenterWorkingCopy:(SLCLDictation *)workingCopy __attribute__((swift_name("speechToTextRecorderPresenter(workingCopy:)")));
- (id<SLCLStartContractPresenter>)startPresenter __attribute__((swift_name("startPresenter()")));
- (id<SLCLSupportContractPresenter>)supportPresenter __attribute__((swift_name("supportPresenter()")));
@property (readonly) id<SLCLErrorReporter> errorReporter __attribute__((swift_name("errorReporter")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultComponentRegistry")))
@interface SLCLDefaultComponentRegistry : SLCLBase <SLCLComponentRegistry>
- (instancetype)initWithAppFilesDirectory:(id<SLCLDirectory>)appFilesDirectory appTmpFilesDirectory:(id<SLCLDirectory>)appTmpFilesDirectory consoleLogWriter:(id<SLCLLogWriter>)consoleLogWriter timeProvider:(id<SLCLTimeProvider>)timeProvider timeFormatter:(id<SLCLTimeFormatter>)timeFormatter fileSizeFormatter:(id<SLCLFileSizeFormatter>)fileSizeFormatter settings:(id<SLCLSettings>)settings secureSettingsFactory:(id<SLCLSettingsFactory>)secureSettingsFactory environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo appInfo:(id<SLCLAppInfo>)appInfo errorReporter:(id<SLCLErrorReporter>)errorReporter apiClientId:(NSString *)apiClientId apiClientSecret:(NSString *)apiClientSecret apiServerEnvironment:(SLCLApiServerEnvironment *)apiServerEnvironment audioFileRecorderFactory:(id<SLCLAudioFileRecorderFactory>)audioFileRecorderFactory audioFilePlayerFactory:(id<SLCLAudioFilePlayerFactory>)audioFilePlayerFactory zipFileArchiver:(id<SLCLFileArchiver>)zipFileArchiver base64Encoder:(id<SLCLBase64Encoder>)base64Encoder sha256Hasher:(id<SLCLHasher>)sha256Hasher networkConnectivityMonitorFactory:(id<SLCLNetworkConnectivityMonitorFactory>)networkConnectivityMonitorFactory contentTypeExtractor:(id<SLCLContentTypeExtractor>)contentTypeExtractor unsupportedAudioTypes:(NSArray<SLCLAudioType *> *)unsupportedAudioTypes unsupportedAudioFormats:(NSArray<id<SLCLAudioFormat>> *)unsupportedAudioFormats signalr:(id<SLCLSignalR>)signalr analyticsLoggers:(NSArray<id<SLCLAnalyticsLogger>> *)analyticsLoggers jwtDecoder:(id<SLCLJwtDecoder>)jwtDecoder encryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider azureAppProxy:(id<SLCLAzureAppProxy>)azureAppProxy azureB2CAuthenticator:(id<SLCLAzureB2CAuthenticator>)azureB2CAuthenticator featureFlagsConfigSource:(id<SLCLConfigSource>)featureFlagsConfigSource mdmConfigSource:(id<SLCLConfigSource>)mdmConfigSource appcuesClient:(id<SLCLAppcuesClient>)appcuesClient __attribute__((swift_name("init(appFilesDirectory:appTmpFilesDirectory:consoleLogWriter:timeProvider:timeFormatter:fileSizeFormatter:settings:secureSettingsFactory:environmentInfo:appInfo:errorReporter:apiClientId:apiClientSecret:apiServerEnvironment:audioFileRecorderFactory:audioFilePlayerFactory:zipFileArchiver:base64Encoder:sha256Hasher:networkConnectivityMonitorFactory:contentTypeExtractor:unsupportedAudioTypes:unsupportedAudioFormats:signalr:analyticsLoggers:jwtDecoder:encryptionProvider:azureAppProxy:azureB2CAuthenticator:featureFlagsConfigSource:mdmConfigSource:appcuesClient:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDefaultComponentRegistryCompanion *companion __attribute__((swift_name("companion")));
- (id<SLCLAboutContractPresenter>)aboutPresenter __attribute__((swift_name("aboutPresenter()")));
- (id<SLCLApplicationContractPresenter>)applicationPresenter __attribute__((swift_name("applicationPresenter()")));
- (id<SLCLDictationListContractPresenter>)dictationListPresenter __attribute__((swift_name("dictationListPresenter()")));
- (id<SLCLDictationPropertiesContractPresenter>)dictationPropertiesPresenterDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy readOnly:(BOOL)readOnly __attribute__((swift_name("dictationPropertiesPresenter(dictationWorkingCopy:readOnly:)")));
- (id<SLCLLogger>)loggerTag:(NSString *)tag __attribute__((swift_name("logger(tag:)")));
- (id<SLCLPlayerContractPresenter>)playerPresenter __attribute__((swift_name("playerPresenter()")));
- (id<SLCLRecorderContractPresenter>)recorderPresenterWorkingCopy:(SLCLDictation *)workingCopy isExistingDictation:(BOOL)isExistingDictation __attribute__((swift_name("recorderPresenter(workingCopy:isExistingDictation:)")));
- (id<SLCLSecurityPromptContractPresenter>)securityPromptPresenterShownFromAppStart:(BOOL)shownFromAppStart __attribute__((swift_name("securityPromptPresenter(shownFromAppStart:)")));
- (id<SLCLSettingsContractPresenter>)settingsPresenter __attribute__((swift_name("settingsPresenter()")));
- (id<SLCLSpeechExecEnterpriseLoginContractPresenter>)speechExecEnterpriseLoginPresenter __attribute__((swift_name("speechExecEnterpriseLoginPresenter()")));
- (id<SLCLSpeechLiveLoginContractPresenter>)speechLiveLoginPresenter __attribute__((swift_name("speechLiveLoginPresenter()")));
- (id<SLCLSpeechToTextRecorderContractPresenter>)speechToTextRecorderPresenterWorkingCopy:(SLCLDictation *)workingCopy __attribute__((swift_name("speechToTextRecorderPresenter(workingCopy:)")));
- (id<SLCLStartContractPresenter>)startPresenter __attribute__((swift_name("startPresenter()")));
- (id<SLCLSupportContractPresenter>)supportPresenter __attribute__((swift_name("supportPresenter()")));
@property (readonly) id<SLCLErrorReporter> errorReporter __attribute__((swift_name("errorReporter")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultComponentRegistry.Companion")))
@interface SLCLDefaultComponentRegistryCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultComponentRegistryCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLLogger>)loggerTag:(NSString *)tag logsDirectory:(id<SLCLDirectory>)logsDirectory consoleLogWriter:(id<SLCLLogWriter>)consoleLogWriter timeProvider:(id<SLCLTimeProvider>)timeProvider timeFormatter:(id<SLCLTimeFormatter>)timeFormatter fileSizeFormatter:(id<SLCLFileSizeFormatter>)fileSizeFormatter environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo appInfo:(id<SLCLAppInfo>)appInfo encryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider __attribute__((swift_name("logger(tag:logsDirectory:consoleLogWriter:timeProvider:timeFormatter:fileSizeFormatter:environmentInfo:appInfo:encryptionProvider:)")));
@end;

__attribute__((swift_name("AboutContract")))
@protocol SLCLAboutContract
@required
@end;

__attribute__((swift_name("AboutContractPresenter")))
@protocol SLCLAboutContractPresenter <SLCLBasePresenter>
@required
- (void)onHelpClick __attribute__((swift_name("onHelpClick()")));
- (void)onPrivacyPolicyClick __attribute__((swift_name("onPrivacyPolicyClick()")));
- (void)onTermsOfUseClick __attribute__((swift_name("onTermsOfUseClick()")));
@end;

__attribute__((swift_name("AboutContractView")))
@protocol SLCLAboutContractView <SLCLBaseView>
@required
- (void)openUrlUrl:(NSString *)url __attribute__((swift_name("openUrl(url:)")));
- (void)showInstallIdInstallId:(NSString *)installId __attribute__((swift_name("showInstallId(installId:)")));
- (void)showVersionNumberVersionNumber:(NSString *)versionNumber __attribute__((swift_name("showVersionNumber(versionNumber:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AboutPresenter")))
@interface SLCLAboutPresenter : SLCLBase <SLCLAboutContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger appInfo:(id<SLCLAppInfo>)appInfo getHelpUrl:(id<SLCLGetHelpUrl>)getHelpUrl __attribute__((swift_name("init(mainContext:logger:appInfo:getHelpUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLAboutPresenterCompanion *companion __attribute__((swift_name("companion")));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLAboutContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onHelpClick __attribute__((swift_name("onHelpClick()")));
- (void)onPrivacyPolicyClick __attribute__((swift_name("onPrivacyPolicyClick()")));
- (void)onTermsOfUseClick __attribute__((swift_name("onTermsOfUseClick()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLAboutContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AboutPresenter.Companion")))
@interface SLCLAboutPresenterCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAboutPresenterCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *PRIVACY_POLICY __attribute__((swift_name("PRIVACY_POLICY")));
@property (readonly) NSString *TERMS_OF_USE __attribute__((swift_name("TERMS_OF_USE")));
@end;

__attribute__((swift_name("ApplicationContract")))
@protocol SLCLApplicationContract
@required
@end;

__attribute__((swift_name("ApplicationContractPresenter")))
@protocol SLCLApplicationContractPresenter <SLCLBasePresenter>
@required
- (void)onTransitionToBackground __attribute__((swift_name("onTransitionToBackground()")));
- (void)onTransitionToForegroundIsAppStart:(BOOL)isAppStart __attribute__((swift_name("onTransitionToForeground(isAppStart:)")));
- (void)setCurrentRecorderRecorder:(id<SLCLAudioFileRecorder>)recorder __attribute__((swift_name("setCurrentRecorder(recorder:)")));
@end;

__attribute__((swift_name("ApplicationContractView")))
@protocol SLCLApplicationContractView <SLCLBaseView>
@required
- (void)showSecurityPrompt __attribute__((swift_name("showSecurityPrompt()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApplicationPresenter")))
@interface SLCLApplicationPresenter : SLCLBase <SLCLApplicationContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger checkIfShouldShowSecurityPrompt:(id<SLCLCheckIfShouldShowSecurityPrompt>)checkIfShouldShowSecurityPrompt __attribute__((swift_name("init(mainContext:logger:checkIfShouldShowSecurityPrompt:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLApplicationContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onTransitionToBackground __attribute__((swift_name("onTransitionToBackground()")));
- (void)onTransitionToForegroundIsAppStart:(BOOL)isAppStart __attribute__((swift_name("onTransitionToForeground(isAppStart:)")));
- (void)setCurrentRecorderRecorder:(id<SLCLAudioFileRecorder>)recorder __attribute__((swift_name("setCurrentRecorder(recorder:)")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLApplicationContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("SecurityPromptContract")))
@protocol SLCLSecurityPromptContract
@required
@end;

__attribute__((swift_name("SecurityPromptContractPresenter")))
@protocol SLCLSecurityPromptContractPresenter <SLCLBasePresenter>
@required
- (void)onSecurityPromptFailed __attribute__((swift_name("onSecurityPromptFailed()")));
- (void)onSecurityPromptSuccessful __attribute__((swift_name("onSecurityPromptSuccessful()")));
@end;

__attribute__((swift_name("SecurityPromptContractView")))
@protocol SLCLSecurityPromptContractView <SLCLBaseView>
@required
- (void)goToDictations __attribute__((swift_name("goToDictations()")));
- (void)goToLogin __attribute__((swift_name("goToLogin()")));
- (void)hideSecurityPrompt __attribute__((swift_name("hideSecurityPrompt()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecurityPromptPresenter")))
@interface SLCLSecurityPromptPresenter : SLCLBase <SLCLSecurityPromptContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger appSettings:(id<SLCLAppSettings>)appSettings shownFromAppStart:(BOOL)shownFromAppStart __attribute__((swift_name("init(mainContext:logger:appSettings:shownFromAppStart:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLSecurityPromptContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onSecurityPromptFailed __attribute__((swift_name("onSecurityPromptFailed()")));
- (void)onSecurityPromptSuccessful __attribute__((swift_name("onSecurityPromptSuccessful()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLSecurityPromptContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("StartContract")))
@protocol SLCLStartContract
@required
@end;

__attribute__((swift_name("StartContractPresenter")))
@protocol SLCLStartContractPresenter <SLCLBasePresenter>
@required
@end;

__attribute__((swift_name("StartContractView")))
@protocol SLCLStartContractView <SLCLBaseView>
@required
- (void)goToDictations __attribute__((swift_name("goToDictations()")));
- (void)goToLogin __attribute__((swift_name("goToLogin()")));
- (void)hideAppUpdateProgress __attribute__((swift_name("hideAppUpdateProgress()")));
- (void)showAppUpdateProgress __attribute__((swift_name("showAppUpdateProgress()")));
- (void)showSecurityPrompt __attribute__((swift_name("showSecurityPrompt()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StartPresenter")))
@interface SLCLStartPresenter : SLCLBase <SLCLStartContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser checkUserAuthenticated:(id<SLCLCheckUserAuthenticated>)checkUserAuthenticated networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor performAppMigrations:(id<SLCLPerformAppMigration>)performAppMigrations deleteAppTemporaryFiles:(id<SLCLDeleteAppTemporaryFiles>)deleteAppTemporaryFiles deleteOldDictationFiles:(id<SLCLDeleteOldDictationFiles>)deleteOldDictationFiles applyMdmSettings:(id<SLCLApplyMdmSettings>)applyMdmSettings speechExecEnterpriseSettings:(SLCLSpeechExecEnterpriseSettings *)speechExecEnterpriseSettings azureAppProxy:(id<SLCLAzureAppProxy>)azureAppProxy featureFlagsConfig:(id<SLCLFeatureFlagsConfig>)featureFlagsConfig checkIfShouldShowSecurityPrompt:(id<SLCLCheckIfShouldShowSecurityPrompt>)checkIfShouldShowSecurityPrompt __attribute__((swift_name("init(mainContext:logger:getCurrentUser:checkUserAuthenticated:networkConnectivityMonitor:performAppMigrations:deleteAppTemporaryFiles:deleteOldDictationFiles:applyMdmSettings:speechExecEnterpriseSettings:azureAppProxy:featureFlagsConfig:checkIfShouldShowSecurityPrompt:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLStartContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLStartContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("ApplyMdmSettings")))
@protocol SLCLApplyMdmSettings
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((swift_name("CheckIfShouldShowSecurityPrompt")))
@protocol SLCLCheckIfShouldShowSecurityPrompt
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("CheckUserAuthenticated")))
@protocol SLCLCheckUserAuthenticated
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user completionHandler:(void (^)(SLCLBoolean * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultApplyMdmSettings")))
@interface SLCLDefaultApplyMdmSettings : SLCLBase <SLCLApplyMdmSettings>
- (instancetype)initWithPropertySuggestionsRepository:(id<SLCLPropertySuggestionsRepository>)propertySuggestionsRepository mdmConfig:(id<SLCLMdmConfig>)mdmConfig appSettings:(id<SLCLAppSettings>)appSettings __attribute__((swift_name("init(propertySuggestionsRepository:mdmConfig:appSettings:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckIfShouldShowSecurityPrompt")))
@interface SLCLDefaultCheckIfShouldShowSecurityPrompt : SLCLBase <SLCLCheckIfShouldShowSecurityPrompt>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser appSettings:(id<SLCLAppSettings>)appSettings logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:appSettings:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckUserAuthenticated")))
@interface SLCLDefaultCheckUserAuthenticated : SLCLBase <SLCLCheckUserAuthenticated>
- (instancetype)initWithIdentityService:(id<SLCLIdentityService>)identityService identifyUserForAnalytics:(id<SLCLIdentifyUserForAnalytics>)identifyUserForAnalytics resetUserForAnalytics:(id<SLCLResetUserForAnalytics>)resetUserForAnalytics __attribute__((swift_name("init(identityService:identifyUserForAnalytics:resetUserForAnalytics:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user completionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:completionHandler:)")));
@end;

__attribute__((swift_name("DeleteOldDictationFiles")))
@protocol SLCLDeleteOldDictationFiles
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDeleteOldDictationFiles")))
@interface SLCLDefaultDeleteOldDictationFiles : SLCLBase <SLCLDeleteOldDictationFiles>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository timeProvider:(id<SLCLTimeProvider>)timeProvider logger:(id<SLCLLogger>)logger daysToDelete:(int32_t)daysToDelete dictationGroups:(NSSet<SLCLDictationGroup *> *)dictationGroups deleteLocalDictationData:(id<SLCLDeleteLocalDictationData>)deleteLocalDictationData __attribute__((swift_name("init(dictationRepository:dictationFilesRepository:timeProvider:logger:daysToDelete:dictationGroups:deleteLocalDictationData:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MigrateToEncryptedFiles")))
@interface SLCLMigrateToEncryptedFiles : SLCLBase <SLCLPerformAppMigration>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository encryptFile:(id<SLCLEncryptFile>)encryptFile logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationRepository:dictationFilesRepository:encryptFile:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MigrateToEncryptedLogs")))
@interface SLCLMigrateToEncryptedLogs : SLCLBase <SLCLPerformAppMigration>
- (instancetype)initWithLogsDir:(id<SLCLDirectory>)logsDir logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(logsDir:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PerformAllPendingAppMigrations")))
@interface SLCLPerformAllPendingAppMigrations : SLCLBase <SLCLPerformAppMigration>
- (instancetype)initWithMigrations:(NSArray<id<SLCLPerformAppMigration>> *)migrations settings:(id<SLCLSettings>)settings logger:(id<SLCLLogger>)logger errorReporter:(id<SLCLErrorReporter>)errorReporter __attribute__((swift_name("init(migrations:settings:logger:errorReporter:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLPerformAllPendingAppMigrationsCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PerformAllPendingAppMigrations.Companion")))
@interface SLCLPerformAllPendingAppMigrationsCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPerformAllPendingAppMigrationsCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *KEY_PREFIX_MIGRATION_STATE __attribute__((swift_name("KEY_PREFIX_MIGRATION_STATE")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RestoreNewDictationAttachmentsAfterFaultyWorkingCopyMerge")))
@interface SLCLRestoreNewDictationAttachmentsAfterFaultyWorkingCopyMerge : SLCLBase <SLCLPerformAppMigration>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository createAttachment:(id<SLCLCreateAttachment>)createAttachment contentTypeExtractor:(id<SLCLContentTypeExtractor>)contentTypeExtractor logger:(id<SLCLLogger>)logger errorReporter:(id<SLCLErrorReporter>)errorReporter __attribute__((swift_name("init(dictationRepository:dictationFilesRepository:attachmentRepository:createAttachment:contentTypeExtractor:logger:errorReporter:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((swift_name("SpeechExecEnterpriseLoginContract")))
@protocol SLCLSpeechExecEnterpriseLoginContract
@required
@end;

__attribute__((swift_name("SpeechExecEnterpriseLoginContractPresenter")))
@protocol SLCLSpeechExecEnterpriseLoginContractPresenter <SLCLBasePresenter>
@required
- (void)onAppProxyAuthenticationCanceled __attribute__((swift_name("onAppProxyAuthenticationCanceled()")));
- (void)onAppProxyAuthenticationError __attribute__((swift_name("onAppProxyAuthenticationError()")));
- (void)onAppProxyAuthenticationSuccess __attribute__((swift_name("onAppProxyAuthenticationSuccess()")));
- (void)onAppProxyToggledUseAppProxy:(BOOL)useAppProxy __attribute__((swift_name("onAppProxyToggled(useAppProxy:)")));
- (void)onAuthorityUrlChangedAuthorityUrl:(NSString *)authorityUrl __attribute__((swift_name("onAuthorityUrlChanged(authorityUrl:)")));
- (void)onClientIdChangedClientId:(NSString *)clientId __attribute__((swift_name("onClientIdChanged(clientId:)")));
- (void)onLoginClickUsername:(NSString *)username password:(NSString *)password url:(NSString *)url authorityUrl:(NSString *)authorityUrl redirectUrl:(NSString *)redirectUrl clientId:(NSString *)clientId __attribute__((swift_name("onLoginClick(username:password:url:authorityUrl:redirectUrl:clientId:)")));
- (void)onPasswordChangedPassword:(NSString *)password __attribute__((swift_name("onPasswordChanged(password:)")));
- (void)onRedirectUrlChangedRedirectUrl:(NSString *)redirectUrl __attribute__((swift_name("onRedirectUrlChanged(redirectUrl:)")));
- (void)onUrlChangedUrl:(NSString *)url __attribute__((swift_name("onUrlChanged(url:)")));
- (void)onUsernameChangedUsername:(NSString *)username __attribute__((swift_name("onUsernameChanged(username:)")));
@end;

__attribute__((swift_name("SpeechExecEnterpriseLoginContractView")))
@protocol SLCLSpeechExecEnterpriseLoginContractView <SLCLBaseView>
@required
- (void)disableSignInButton __attribute__((swift_name("disableSignInButton()")));
- (void)enableProxyToggle __attribute__((swift_name("enableProxyToggle()")));
- (void)enableSignInButton __attribute__((swift_name("enableSignInButton()")));
- (void)goToDictationList __attribute__((swift_name("goToDictationList()")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)setApiUrlUrl:(NSString *)url __attribute__((swift_name("setApiUrl(url:)")));
- (void)setAuthorityUrlAuthorityUrl:(NSString *)authorityUrl __attribute__((swift_name("setAuthorityUrl(authorityUrl:)")));
- (void)setClientIdClientId:(NSString *)clientId __attribute__((swift_name("setClientId(clientId:)")));
- (void)setRedirectUrlRedirectUrl:(NSString *)redirectUrl __attribute__((swift_name("setRedirectUrl(redirectUrl:)")));
- (void)setUsernameUsername:(NSString *)username __attribute__((swift_name("setUsername(username:)")));
- (void)showAppProxyAuthentication __attribute__((swift_name("showAppProxyAuthentication()")));
- (void)showAppProxyAuthenticationError __attribute__((swift_name("showAppProxyAuthenticationError()")));
- (void)showCredentialError __attribute__((swift_name("showCredentialError()")));
- (void)showLicenseNotAvailableError __attribute__((swift_name("showLicenseNotAvailableError()")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showNetworkError __attribute__((swift_name("showNetworkError()")));
- (void)showNoAuthorMessageAppName:(NSString *)appName __attribute__((swift_name("showNoAuthorMessage(appName:)")));
- (void)showServerError __attribute__((swift_name("showServerError()")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
- (void)showUserNotFoundError __attribute__((swift_name("showUserNotFoundError()")));
@end;

__attribute__((swift_name("SpeechLiveLoginContract")))
@protocol SLCLSpeechLiveLoginContract
@required
@end;

__attribute__((swift_name("SpeechLiveLoginContractPresenter")))
@protocol SLCLSpeechLiveLoginContractPresenter <SLCLBasePresenter>
@required
- (void)onAccountSelectedAccount:(SLCLUser *)account __attribute__((swift_name("onAccountSelected(account:)")));
- (void)onAlternativeLoginClickEmail:(NSString *)email password:(NSString *)password __attribute__((swift_name("onAlternativeLoginClick(email:password:)")));
- (void)onIdentityProviderLoginCanceled __attribute__((swift_name("onIdentityProviderLoginCanceled()")));
- (void)onIdentityProviderLoginFailedError:(NSString *)error __attribute__((swift_name("onIdentityProviderLoginFailed(error:)")));
- (void)onIdentityTokenReceivedIdentityProviderAccessToken:(NSString *)identityProviderAccessToken __attribute__((swift_name("onIdentityTokenReceived(identityProviderAccessToken:)")));
- (void)onInfoClick __attribute__((swift_name("onInfoClick()")));
- (void)onLogInClick __attribute__((swift_name("onLogInClick()")));
- (void)onMultiFactorAuthenticationRequestAcceptedAccount:(SLCLUser *)account __attribute__((swift_name("onMultiFactorAuthenticationRequestAccepted(account:)")));
- (void)onSpeechExecEnterpriseLoginClick __attribute__((swift_name("onSpeechExecEnterpriseLoginClick()")));
@end;

__attribute__((swift_name("SpeechLiveLoginContractView")))
@protocol SLCLSpeechLiveLoginContractView <SLCLBaseView>
@required
- (void)hideAccountSelector __attribute__((swift_name("hideAccountSelector()")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)hideSpeechExecEnterpriseLoginButton __attribute__((swift_name("hideSpeechExecEnterpriseLoginButton()")));
- (void)logInWithIdentityProviderInteractively __attribute__((swift_name("logInWithIdentityProviderInteractively()")));
- (void)showAccountSelectorAccounts:(NSArray<SLCLUser *> *)accounts __attribute__((swift_name("showAccountSelector(accounts:)")));
- (void)showDictationList __attribute__((swift_name("showDictationList()")));
- (void)showFileSystemError __attribute__((swift_name("showFileSystemError()")));
- (void)showInfo __attribute__((swift_name("showInfo()")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showMultiFactorAuthenticationRequestAccount:(SLCLUser *)account __attribute__((swift_name("showMultiFactorAuthenticationRequest(account:)")));
- (void)showNetworkError __attribute__((swift_name("showNetworkError()")));
- (void)showNoAuthorMessageAppName:(NSString *)appName __attribute__((swift_name("showNoAuthorMessage(appName:)")));
- (void)showServerError __attribute__((swift_name("showServerError()")));
- (void)showSpeechExecEnterpriseLogin __attribute__((swift_name("showSpeechExecEnterpriseLogin()")));
- (void)showSpeechExecEnterpriseLoginButton __attribute__((swift_name("showSpeechExecEnterpriseLoginButton()")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
@end;

__attribute__((swift_name("GetAuthorAccountsWithEmailAndPassword")))
@protocol SLCLGetAuthorAccountsWithEmailAndPassword
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(SLCLGetAuthorAccountsWithEmailAndPasswordOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(email:password:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetAuthorAccountsWithEmailAndPassword")))
@interface SLCLDefaultGetAuthorAccountsWithEmailAndPassword : SLCLBase <SLCLGetAuthorAccountsWithEmailAndPassword>
- (instancetype)initWithIdentityService:(id<SLCLIdentityService>)identityService __attribute__((swift_name("init(identityService:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(SLCLGetAuthorAccountsWithEmailAndPasswordOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(email:password:completionHandler:)")));
@end;

__attribute__((swift_name("GetAuthorAccountsWithIdentityToken")))
@protocol SLCLGetAuthorAccountsWithIdentityToken
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeIdentityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLGetAuthorAccountsWithIdentityTokenOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(identityProviderAccessToken:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetAuthorAccountsWithIdentityToken")))
@interface SLCLDefaultGetAuthorAccountsWithIdentityToken : SLCLBase <SLCLGetAuthorAccountsWithIdentityToken>
- (instancetype)initWithIdentityService:(id<SLCLIdentityService>)identityService logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(identityService:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeIdentityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLGetAuthorAccountsWithIdentityTokenOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(identityProviderAccessToken:completionHandler:)")));
@end;

__attribute__((swift_name("GetCurrentUser")))
@protocol SLCLGetCurrentUser
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetCurrentUser")))
@interface SLCLDefaultGetCurrentUser : SLCLBase <SLCLGetCurrentUser>
- (instancetype)initWithUserRepository:(id<SLCLUserRepository>)userRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(userRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("LogOutUser")))
@protocol SLCLLogOutUser
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultLogOutUser")))
@interface SLCLDefaultLogOutUser : SLCLBase <SLCLLogOutUser>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser identityService:(id<SLCLIdentityService>)identityService userRepository:(id<SLCLUserRepository>)userRepository azureB2CAuthenticator:(id<SLCLAzureB2CAuthenticator>)azureB2CAuthenticator resetUserForAnalytics:(id<SLCLResetUserForAnalytics>)resetUserForAnalytics __attribute__((swift_name("init(getCurrentUser:identityService:userRepository:azureB2CAuthenticator:resetUserForAnalytics:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((swift_name("UpdateMfaStatus")))
@protocol SLCLUpdateMfaStatus
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user enableMfa:(BOOL)enableMfa identityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLUpdateMfaStatusOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:enableMfa:identityProviderAccessToken:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultUpdateMfaStatus")))
@interface SLCLDefaultUpdateMfaStatus : SLCLBase <SLCLUpdateMfaStatus>
- (instancetype)initWithIdentityService:(id<SLCLIdentityService>)identityService __attribute__((swift_name("init(identityService:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user enableMfa:(BOOL)enableMfa identityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLUpdateMfaStatusOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:enableMfa:identityProviderAccessToken:completionHandler:)")));
@end;

__attribute__((swift_name("GetAuthorAccountsWithEmailAndPasswordOutput")))
@interface SLCLGetAuthorAccountsWithEmailAndPasswordOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithEmailAndPasswordOutput.NetworkError")))
@interface SLCLGetAuthorAccountsWithEmailAndPasswordOutputNetworkError : SLCLGetAuthorAccountsWithEmailAndPasswordOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithEmailAndPasswordOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithEmailAndPasswordOutput.NoAuthorRoleFound")))
@interface SLCLGetAuthorAccountsWithEmailAndPasswordOutputNoAuthorRoleFound : SLCLGetAuthorAccountsWithEmailAndPasswordOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noAuthorRoleFound __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithEmailAndPasswordOutputNoAuthorRoleFound *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithEmailAndPasswordOutput.ServerError")))
@interface SLCLGetAuthorAccountsWithEmailAndPasswordOutputServerError : SLCLGetAuthorAccountsWithEmailAndPasswordOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithEmailAndPasswordOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithEmailAndPasswordOutput.Success")))
@interface SLCLGetAuthorAccountsWithEmailAndPasswordOutputSuccess : SLCLGetAuthorAccountsWithEmailAndPasswordOutput
- (instancetype)initWithAccounts:(NSArray<SLCLUser *> *)accounts __attribute__((swift_name("init(accounts:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLUser *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLGetAuthorAccountsWithEmailAndPasswordOutputSuccess *)doCopyAccounts:(NSArray<SLCLUser *> *)accounts __attribute__((swift_name("doCopy(accounts:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLUser *> *accounts __attribute__((swift_name("accounts")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithEmailAndPasswordOutput.UnexpectedError")))
@interface SLCLGetAuthorAccountsWithEmailAndPasswordOutputUnexpectedError : SLCLGetAuthorAccountsWithEmailAndPasswordOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithEmailAndPasswordOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("GetAuthorAccountsWithIdentityTokenOutput")))
@interface SLCLGetAuthorAccountsWithIdentityTokenOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithIdentityTokenOutput.NetworkError")))
@interface SLCLGetAuthorAccountsWithIdentityTokenOutputNetworkError : SLCLGetAuthorAccountsWithIdentityTokenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithIdentityTokenOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithIdentityTokenOutput.NoAuthorRoleFound")))
@interface SLCLGetAuthorAccountsWithIdentityTokenOutputNoAuthorRoleFound : SLCLGetAuthorAccountsWithIdentityTokenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noAuthorRoleFound __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithIdentityTokenOutputNoAuthorRoleFound *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithIdentityTokenOutput.ServerError")))
@interface SLCLGetAuthorAccountsWithIdentityTokenOutputServerError : SLCLGetAuthorAccountsWithIdentityTokenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithIdentityTokenOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithIdentityTokenOutput.Success")))
@interface SLCLGetAuthorAccountsWithIdentityTokenOutputSuccess : SLCLGetAuthorAccountsWithIdentityTokenOutput
- (instancetype)initWithAccounts:(NSArray<SLCLUser *> *)accounts __attribute__((swift_name("init(accounts:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLUser *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLGetAuthorAccountsWithIdentityTokenOutputSuccess *)doCopyAccounts:(NSArray<SLCLUser *> *)accounts __attribute__((swift_name("doCopy(accounts:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLUser *> *accounts __attribute__((swift_name("accounts")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAuthorAccountsWithIdentityTokenOutput.UnexpectedError")))
@interface SLCLGetAuthorAccountsWithIdentityTokenOutputUnexpectedError : SLCLGetAuthorAccountsWithIdentityTokenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetAuthorAccountsWithIdentityTokenOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("IdentifyUserForAnalytics")))
@protocol SLCLIdentifyUserForAnalytics
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IdentifyUserForAppcues")))
@interface SLCLIdentifyUserForAppcues : SLCLBase <SLCLIdentifyUserForAnalytics>
- (instancetype)initWithB2CAuthenticator:(id<SLCLAzureB2CAuthenticator>)b2CAuthenticator logger:(id<SLCLLogger>)logger tokenDecoder:(id<SLCLJwtDecoder>)tokenDecoder appcuesClient:(id<SLCLAppcuesClient>)appcuesClient __attribute__((swift_name("init(b2CAuthenticator:logger:tokenDecoder:appcuesClient:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:completionHandler_:)")));
@end;

__attribute__((swift_name("LogInUserWithAccount")))
@protocol SLCLLogInUserWithAccount
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAccount:(SLCLUser *)account completionHandler:(void (^)(SLCLLogInUserWithAccountOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(account:completionHandler:)")));
@end;

__attribute__((swift_name("LogInUserWithAccountOutput")))
@interface SLCLLogInUserWithAccountOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogInUserWithAccountOutput.FileSystemError")))
@interface SLCLLogInUserWithAccountOutputFileSystemError : SLCLLogInUserWithAccountOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLogInUserWithAccountOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogInUserWithAccountOutput.NetworkError")))
@interface SLCLLogInUserWithAccountOutputNetworkError : SLCLLogInUserWithAccountOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLogInUserWithAccountOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogInUserWithAccountOutput.ServerError")))
@interface SLCLLogInUserWithAccountOutputServerError : SLCLLogInUserWithAccountOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLogInUserWithAccountOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogInUserWithAccountOutput.Success")))
@interface SLCLLogInUserWithAccountOutputSuccess : SLCLLogInUserWithAccountOutput
- (instancetype)initWithUser:(SLCLUser *)user __attribute__((swift_name("init(user:)"))) __attribute__((objc_designated_initializer));
- (SLCLUser *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLogInUserWithAccountOutputSuccess *)doCopyUser:(SLCLUser *)user __attribute__((swift_name("doCopy(user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLUser *user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogInUserWithAccountOutput.UnexpectedError")))
@interface SLCLLogInUserWithAccountOutputUnexpectedError : SLCLLogInUserWithAccountOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLogInUserWithAccountOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogInUserWithAuthorAccount")))
@interface SLCLLogInUserWithAuthorAccount : SLCLBase <SLCLLogInUserWithAccount>
- (instancetype)initWithIdentityService:(id<SLCLIdentityService>)identityService userRepository:(id<SLCLUserRepository>)userRepository userFilesRepository:(id<SLCLUserFilesRepository>)userFilesRepository logger:(id<SLCLLogger>)logger identifyUserForAnalytics:(id<SLCLIdentifyUserForAnalytics>)identifyUserForAnalytics __attribute__((swift_name("init(identityService:userRepository:userFilesRepository:logger:identifyUserForAnalytics:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAccount:(SLCLUser *)account completionHandler:(void (^)(SLCLLogInUserWithAccountOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(account:completionHandler:)")));
@end;

__attribute__((swift_name("ResetUserForAnalytics")))
@protocol SLCLResetUserForAnalytics
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResetUserForAppcues")))
@interface SLCLResetUserForAppcues : SLCLBase <SLCLResetUserForAnalytics>
- (instancetype)initWithAppcuesClient:(id<SLCLAppcuesClient>)appcuesClient __attribute__((swift_name("init(appcuesClient:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseLogOutUser")))
@interface SLCLSpeechExecEnterpriseLogOutUser : SLCLBase <SLCLLogOutUser>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser identityService:(id<SLCLIdentityService>)identityService userRepository:(id<SLCLUserRepository>)userRepository azureAppProxy:(id<SLCLAzureAppProxy>)azureAppProxy __attribute__((swift_name("init(getCurrentUser:identityService:userRepository:azureAppProxy:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((swift_name("UpdateMfaStatusOutput")))
@interface SLCLUpdateMfaStatusOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateMfaStatusOutput.ApiError")))
@interface SLCLUpdateMfaStatusOutputApiError : SLCLUpdateMfaStatusOutput
- (instancetype)initWithError:(SLCLApiError *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (SLCLApiError *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUpdateMfaStatusOutputApiError *)doCopyError:(SLCLApiError *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLApiError *error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateMfaStatusOutput.Success")))
@interface SLCLUpdateMfaStatusOutputSuccess : SLCLUpdateMfaStatusOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUpdateMfaStatusOutputSuccess *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("UserFilesRepository")))
@protocol SLCLUserFilesRepository
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllUsersDirectoryWithCompletionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllUsersDirectory(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserDirectoryUserId:(NSString *)userId completionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUserDirectory(userId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultUserFilesRepository")))
@interface SLCLDefaultUserFilesRepository : SLCLBase <SLCLUserFilesRepository>
- (instancetype)initWithAppFilesDirectory:(id<SLCLDirectory>)appFilesDirectory __attribute__((swift_name("init(appFilesDirectory:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllUsersDirectoryWithCompletionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllUsersDirectory(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserDirectoryUserId:(NSString *)userId completionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUserDirectory(userId:completionHandler:)")));
@end;

__attribute__((swift_name("UserRepository")))
@protocol SLCLUserRepository
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)addOrUpdateUserUser:(SLCLUser *)user completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("addOrUpdateUser(user:completionHandler:)")));
- (SLCLService * _Nullable)getCurrentService __attribute__((swift_name("getCurrentService()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCurrentUserWithCompletionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getCurrentUser(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserId:(NSString *)id completionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getUser(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUsersWithCompletionHandler:(void (^)(NSArray<SLCLUser *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUsers(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeUserId:(NSString *)id completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeUser(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)setCurrentUserUser:(SLCLUser *)user completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setCurrentUser(user:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InMemoryUserRepository")))
@interface SLCLInMemoryUserRepository : SLCLBase <SLCLUserRepository>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)addOrUpdateUserUser:(SLCLUser *)user completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("addOrUpdateUser(user:completionHandler:)")));
- (SLCLService * _Nullable)getCurrentService __attribute__((swift_name("getCurrentService()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCurrentUserWithCompletionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getCurrentUser(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserId:(NSString *)id completionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getUser(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUsersWithCompletionHandler:(void (^)(NSArray<SLCLUser *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUsers(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeUserId:(NSString *)id completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeUser(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)setCurrentUserUser:(SLCLUser *)user completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setCurrentUser(user:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SqlDelightUserRepository")))
@interface SLCLSqlDelightUserRepository : SLCLBase <SLCLUserRepository>
- (instancetype)initWithUserQueries:(id<SLCLUserQueries>)userQueries logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(userQueries:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)addOrUpdateUserUser:(SLCLUser *)user completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("addOrUpdateUser(user:completionHandler:)")));
- (SLCLService * _Nullable)getCurrentService __attribute__((swift_name("getCurrentService()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCurrentUserWithCompletionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getCurrentUser(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserId:(NSString *)id completionHandler:(void (^)(SLCLUser * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getUser(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUsersWithCompletionHandler:(void (^)(NSArray<SLCLUser *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUsers(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeUserId:(NSString *)id completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeUser(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)setCurrentUserUser:(SLCLUser *)user completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setCurrentUser(user:completionHandler:)")));
@end;

__attribute__((swift_name("AzureAppProxy")))
@protocol SLCLAzureAppProxy
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccessTokenForceRefresh:(BOOL)forceRefresh completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccessToken(forceRefresh:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)initializeProxyClientClientId:(NSString *)clientId redirectUrl:(NSString *)redirectUrl authorityUrl:(NSString *)authorityUrl scope:(NSString *)scope completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("initializeProxyClient(clientId:redirectUrl:authorityUrl:scope:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)signOutFromProxyWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("signOutFromProxy(completionHandler:)")));
@property id<SLCLLogger> _Nullable logger __attribute__((swift_name("logger")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AzureAppProxyCompanion")))
@interface SLCLAzureAppProxyCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAzureAppProxyCompanion *shared __attribute__((swift_name("shared")));
- (NSString *)getScopeUrl:(NSString *)url __attribute__((swift_name("getScope(url:)")));
@end;

__attribute__((swift_name("AzureB2CAuthenticator")))
@protocol SLCLAzureB2CAuthenticator
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTokenWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getToken(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)signOutWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("signOut(completionHandler:)")));
@property id<SLCLLogger> _Nullable logger __attribute__((swift_name("logger")));
@end;

__attribute__((swift_name("IdentityService")))
@protocol SLCLIdentityService
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)authHeadersUserId:(NSString *)userId completionHandler:(void (^)(NSDictionary<NSString *, NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("authHeaders(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)checkAuthenticatedUserAccountId:(NSString *)userAccountId completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("checkAuthenticated(userAccountId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccountsIdentityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLEither<NSArray<SLCLUser *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccounts(identityProviderAccessToken:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccountsEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(SLCLEither<NSArray<SLCLUser *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccounts(email:password:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEndpointConfigurationUserAccountId:(NSString *)userAccountId endpointName:(SLCLApiEndpoint *)endpointName completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getEndpointConfiguration(userAccountId:endpointName:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginUser:(SLCLUser *)user completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("login(user:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)logoutUserAccountId:(NSString *)userAccountId fromAllDevices:(BOOL)fromAllDevices completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("logout(userAccountId:fromAllDevices:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)renewLoginUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("renewLogin(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateMfaStatusUser:(SLCLUser *)user enableMfa:(BOOL)enableMfa identityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateMfaStatus(user:enableMfa:identityProviderAccessToken:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseSettings")))
@interface SLCLSpeechExecEnterpriseSettings : SLCLBase
- (instancetype)initWithSettings:(id<SLCLSettings>)settings __attribute__((swift_name("init(settings:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSpeechExecEnterpriseSettingsCompanion *companion __attribute__((swift_name("companion")));
- (void)clear __attribute__((swift_name("clear()")));
@property NSString *apiBaseUrl __attribute__((swift_name("apiBaseUrl")));
@property NSString *appProxyAuthorityUrl __attribute__((swift_name("appProxyAuthorityUrl")));
@property NSString *appProxyClientId __attribute__((swift_name("appProxyClientId")));
@property NSString *appProxyRedirectUrl __attribute__((swift_name("appProxyRedirectUrl")));
@property (readonly) BOOL isAppProxyEnabled __attribute__((swift_name("isAppProxyEnabled")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseSettings.Companion")))
@interface SLCLSpeechExecEnterpriseSettingsCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechExecEnterpriseSettingsCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *API_BASE_URL_KEY __attribute__((swift_name("API_BASE_URL_KEY")));
@property (readonly) NSString *APP_PROXY_AUTHORITY_URL __attribute__((swift_name("APP_PROXY_AUTHORITY_URL")));
@property (readonly) NSString *APP_PROXY_CLIENT_ID __attribute__((swift_name("APP_PROXY_CLIENT_ID")));
@property (readonly) NSString *APP_PROXY_REDIRECT_URL __attribute__((swift_name("APP_PROXY_REDIRECT_URL")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorResponseDto")))
@interface SLCLErrorResponseDto : SLCLBase
- (instancetype)initWithError:(NSString *)error errorDescription:(NSString *)errorDescription __attribute__((swift_name("init(error:errorDescription:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLErrorResponseDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLErrorResponseDto *)doCopyError:(NSString *)error errorDescription:(NSString *)errorDescription __attribute__((swift_name("doCopy(error:errorDescription:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *error __attribute__((swift_name("error")));
@property (readonly) NSString *errorDescription __attribute__((swift_name("errorDescription")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorResponseDto.Companion")))
@interface SLCLErrorResponseDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLErrorResponseDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenRequestDto")))
@interface SLCLTokenRequestDto : SLCLBase
- (instancetype)initWithGrantType:(NSString *)grantType username:(NSString *)username password:(NSString *)password __attribute__((swift_name("init(grantType:username:password:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLTokenRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLTokenRequestDto *)doCopyGrantType:(NSString *)grantType username:(NSString *)username password:(NSString *)password __attribute__((swift_name("doCopy(grantType:username:password:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *grantType __attribute__((swift_name("grantType")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenRequestDto.Companion")))
@interface SLCLTokenRequestDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLTokenRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenResponseDto")))
@interface SLCLTokenResponseDto : SLCLBase
- (instancetype)initWithAccessToken:(NSString *)accessToken tokenType:(NSString *)tokenType expiresIn:(int64_t)expiresIn userName:(NSString *)userName issued:(NSString *)issued expires:(NSString *)expires roles:(NSString *)roles userAccountId:(NSString *)userAccountId __attribute__((swift_name("init(accessToken:tokenType:expiresIn:userName:issued:expires:roles:userAccountId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLTokenResponseDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLTokenResponseDto *)doCopyAccessToken:(NSString *)accessToken tokenType:(NSString *)tokenType expiresIn:(int64_t)expiresIn userName:(NSString *)userName issued:(NSString *)issued expires:(NSString *)expires roles:(NSString *)roles userAccountId:(NSString *)userAccountId __attribute__((swift_name("doCopy(accessToken:tokenType:expiresIn:userName:issued:expires:roles:userAccountId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accessToken __attribute__((swift_name("accessToken")));
@property (readonly) NSString *expires __attribute__((swift_name("expires")));
@property (readonly) int64_t expiresIn __attribute__((swift_name("expiresIn")));
@property (readonly) NSString *issued __attribute__((swift_name("issued")));
@property (readonly) NSString *roles __attribute__((swift_name("roles")));
@property (readonly) NSString *tokenType __attribute__((swift_name("tokenType")));
@property (readonly) NSString *userAccountId __attribute__((swift_name("userAccountId")));
@property (readonly) NSString *userName __attribute__((swift_name("userName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenResponseDto.Companion")))
@interface SLCLTokenResponseDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLTokenResponseDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechLiveIdentityService")))
@interface SLCLSpeechLiveIdentityService : SLCLBase <SLCLIdentityService>
- (instancetype)initWithHttpClient:(SLCLKtor_client_coreHttpClient *)httpClient logger:(id<SLCLLogger>)logger tokenStore:(id<SLCLTokenStore>)tokenStore appInfo:(id<SLCLAppInfo>)appInfo environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo apiVersion:(int32_t)apiVersion apiClientId:(NSString *)apiClientId apiClientSecret:(NSString *)apiClientSecret apiServerEnvironment:(SLCLApiServerEnvironment *)apiServerEnvironment networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor sha256Hasher:(id<SLCLHasher>)sha256Hasher base64Encoder:(id<SLCLBase64Encoder>)base64Encoder jwtDecoder:(id<SLCLJwtDecoder>)jwtDecoder endpointConfigStore:(id<SLCLEndpointConfigStore>)endpointConfigStore __attribute__((swift_name("init(httpClient:logger:tokenStore:appInfo:environmentInfo:apiVersion:apiClientId:apiClientSecret:apiServerEnvironment:networkConnectivityMonitor:sha256Hasher:base64Encoder:jwtDecoder:endpointConfigStore:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSpeechLiveIdentityServiceCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)authHeadersUserId:(NSString *)userId completionHandler:(void (^)(NSDictionary<NSString *, NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("authHeaders(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)checkAuthenticatedUserAccountId:(NSString *)userAccountId completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("checkAuthenticated(userAccountId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccountsIdentityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLEither<NSArray<SLCLUser *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccounts(identityProviderAccessToken:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccountsEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(SLCLEither<NSArray<SLCLUser *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccounts(email:password:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEndpointConfigurationUserAccountId:(NSString *)userAccountId endpointName:(SLCLApiEndpoint *)endpointName completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getEndpointConfiguration(userAccountId:endpointName:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginUser:(SLCLUser *)user completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("login(user:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)logoutUserAccountId:(NSString *)userAccountId fromAllDevices:(BOOL)fromAllDevices completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("logout(userAccountId:fromAllDevices:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)renewLoginUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("renewLogin(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateMfaStatusUser:(SLCLUser *)user enableMfa:(BOOL)enableMfa identityProviderAccessToken:(NSString *)identityProviderAccessToken completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateMfaStatus(user:enableMfa:identityProviderAccessToken:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechLiveIdentityService.Companion")))
@interface SLCLSpeechLiveIdentityServiceCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechLiveIdentityServiceCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *API_VERSION_PLACEHOLDER __attribute__((swift_name("API_VERSION_PLACEHOLDER")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EndpointConfigurationListResponseDto")))
@interface SLCLEndpointConfigurationListResponseDto : SLCLBase
- (instancetype)initWithEndpoints:(NSArray<SLCLEndpointConfigurationResponseDto *> *)endpoints __attribute__((swift_name("init(endpoints:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLEndpointConfigurationListResponseDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSArray<SLCLEndpointConfigurationResponseDto *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLEndpointConfigurationListResponseDto *)doCopyEndpoints:(NSArray<SLCLEndpointConfigurationResponseDto *> *)endpoints __attribute__((swift_name("doCopy(endpoints:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLEndpointConfigurationResponseDto *> *endpoints __attribute__((swift_name("endpoints")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EndpointConfigurationListResponseDto.Companion")))
@interface SLCLEndpointConfigurationListResponseDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLEndpointConfigurationListResponseDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EndpointConfigurationResponseDto")))
@interface SLCLEndpointConfigurationResponseDto : SLCLBase
- (instancetype)initWithName:(NSString *)name url:(NSString *)url __attribute__((swift_name("init(name:url:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLEndpointConfigurationResponseDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLEndpointConfigurationResponseDto *)doCopyName:(NSString *)name url:(NSString *)url __attribute__((swift_name("doCopy(name:url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EndpointConfigurationResponseDto.Companion")))
@interface SLCLEndpointConfigurationResponseDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLEndpointConfigurationResponseDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginRequest")))
@interface SLCLLoginRequest : SLCLBase
- (instancetype)initWithEmail:(NSString *)email password:(NSString *)password client:(NSString *)client __attribute__((swift_name("init(email:password:client:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLLoginRequestCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoginRequest *)doCopyEmail:(NSString *)email password:(NSString *)password client:(NSString *)client __attribute__((swift_name("doCopy(email:password:client:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *client __attribute__((swift_name("client")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginRequest.Companion")))
@interface SLCLLoginRequestCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponse")))
@interface SLCLLoginResponse : SLCLBase
- (instancetype)initWithJwt:(NSString * _Nullable)jwt userAccounts:(NSArray<SLCLUserAccountDto *> * _Nullable)userAccounts __attribute__((swift_name("init(jwt:userAccounts:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLLoginResponseCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<SLCLUserAccountDto *> * _Nullable)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoginResponse *)doCopyJwt:(NSString * _Nullable)jwt userAccounts:(NSArray<SLCLUserAccountDto *> * _Nullable)userAccounts __attribute__((swift_name("doCopy(jwt:userAccounts:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable jwt __attribute__((swift_name("jwt")));
@property (readonly) NSArray<SLCLUserAccountDto *> * _Nullable userAccounts __attribute__((swift_name("userAccounts")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponse.Companion")))
@interface SLCLLoginResponseCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoginResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogoutRequest")))
@interface SLCLLogoutRequest : SLCLBase
- (instancetype)initWithRefreshToken:(NSString *)refreshToken __attribute__((swift_name("init(refreshToken:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLLogoutRequestCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLogoutRequest *)doCopyRefreshToken:(NSString *)refreshToken __attribute__((swift_name("doCopy(refreshToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *refreshToken __attribute__((swift_name("refreshToken")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogoutRequest.Companion")))
@interface SLCLLogoutRequestCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLogoutRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenewServiceLoginRequest")))
@interface SLCLRenewServiceLoginRequest : SLCLBase
- (instancetype)initWithRefreshToken:(NSString *)refreshToken __attribute__((swift_name("init(refreshToken:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLRenewServiceLoginRequestCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLRenewServiceLoginRequest *)doCopyRefreshToken:(NSString *)refreshToken __attribute__((swift_name("doCopy(refreshToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *refreshToken __attribute__((swift_name("refreshToken")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenewServiceLoginRequest.Companion")))
@interface SLCLRenewServiceLoginRequestCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRenewServiceLoginRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenewServiceLoginResponse")))
@interface SLCLRenewServiceLoginResponse : SLCLBase
- (instancetype)initWithJwt:(NSString *)jwt __attribute__((swift_name("init(jwt:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLRenewServiceLoginResponseCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLRenewServiceLoginResponse *)doCopyJwt:(NSString *)jwt __attribute__((swift_name("doCopy(jwt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *jwt __attribute__((swift_name("jwt")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenewServiceLoginResponse.Companion")))
@interface SLCLRenewServiceLoginResponseCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRenewServiceLoginResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLoginRequest")))
@interface SLCLServiceLoginRequest : SLCLBase
- (instancetype)initWithRegion:(NSString *)region userAccountId:(NSString *)userAccountId subscriptionId:(int32_t)subscriptionId client:(NSString *)client __attribute__((swift_name("init(region:userAccountId:subscriptionId:client:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLServiceLoginRequestCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLServiceLoginRequest *)doCopyRegion:(NSString *)region userAccountId:(NSString *)userAccountId subscriptionId:(int32_t)subscriptionId client:(NSString *)client __attribute__((swift_name("doCopy(region:userAccountId:subscriptionId:client:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *client __attribute__((swift_name("client")));
@property (readonly) NSString *region __attribute__((swift_name("region")));
@property (readonly) int32_t subscriptionId __attribute__((swift_name("subscriptionId")));
@property (readonly) NSString *userAccountId __attribute__((swift_name("userAccountId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLoginRequest.Companion")))
@interface SLCLServiceLoginRequestCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLServiceLoginRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLoginResponse")))
@interface SLCLServiceLoginResponse : SLCLBase
- (instancetype)initWithJwt:(NSString * _Nullable)jwt refreshToken:(NSString * _Nullable)refreshToken __attribute__((swift_name("init(jwt:refreshToken:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLServiceLoginResponseCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLServiceLoginResponse *)doCopyJwt:(NSString * _Nullable)jwt refreshToken:(NSString * _Nullable)refreshToken __attribute__((swift_name("doCopy(jwt:refreshToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable jwt __attribute__((swift_name("jwt")));
@property (readonly) NSString * _Nullable refreshToken __attribute__((swift_name("refreshToken")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLoginResponse.Companion")))
@interface SLCLServiceLoginResponseCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLServiceLoginResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateMfaStatusRequestDto")))
@interface SLCLUpdateMfaStatusRequestDto : SLCLBase
- (instancetype)initWithEnableMfa:(BOOL)enableMfa __attribute__((swift_name("init(enableMfa:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLUpdateMfaStatusRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUpdateMfaStatusRequestDto *)doCopyEnableMfa:(BOOL)enableMfa __attribute__((swift_name("doCopy(enableMfa:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL enableMfa __attribute__((swift_name("enableMfa")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateMfaStatusRequestDto.Companion")))
@interface SLCLUpdateMfaStatusRequestDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUpdateMfaStatusRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateMfaStatusResponseDto")))
@interface SLCLUpdateMfaStatusResponseDto : SLCLBase
- (instancetype)initWithVersion:(NSString *)version status:(int32_t)status userStatus:(NSString * _Nullable)userStatus userMessage:(NSString * _Nullable)userMessage __attribute__((swift_name("init(version:status:userStatus:userMessage:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLUpdateMfaStatusResponseDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUpdateMfaStatusResponseDto *)doCopyVersion:(NSString *)version status:(int32_t)status userStatus:(NSString * _Nullable)userStatus userMessage:(NSString * _Nullable)userMessage __attribute__((swift_name("doCopy(version:status:userStatus:userMessage:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable userMessage __attribute__((swift_name("userMessage")));
@property (readonly) NSString * _Nullable userStatus __attribute__((swift_name("userStatus")));
@property (readonly) NSString *version __attribute__((swift_name("version")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateMfaStatusResponseDto.Companion")))
@interface SLCLUpdateMfaStatusResponseDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUpdateMfaStatusResponseDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserAccountDto")))
@interface SLCLUserAccountDto : SLCLBase
- (instancetype)initWithId:(NSString *)id region:(NSString * _Nullable)region roles:(NSArray<NSString *> * _Nullable)roles subscriptionName:(NSString *)subscriptionName subscriptionId:(int32_t)subscriptionId subscriptionState:(NSString * _Nullable)subscriptionState name:(NSString * _Nullable)name subscriptionPackage:(NSString * _Nullable)subscriptionPackage isTrial:(BOOL)isTrial isMfaRequirementSatisfied:(BOOL)isMfaRequirementSatisfied __attribute__((swift_name("init(id:region:roles:subscriptionName:subscriptionId:subscriptionState:name:subscriptionPackage:isTrial:isMfaRequirementSatisfied:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLUserAccountDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<NSString *> * _Nullable)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUserAccountDto *)doCopyId:(NSString *)id region:(NSString * _Nullable)region roles:(NSArray<NSString *> * _Nullable)roles subscriptionName:(NSString *)subscriptionName subscriptionId:(int32_t)subscriptionId subscriptionState:(NSString * _Nullable)subscriptionState name:(NSString * _Nullable)name subscriptionPackage:(NSString * _Nullable)subscriptionPackage isTrial:(BOOL)isTrial isMfaRequirementSatisfied:(BOOL)isMfaRequirementSatisfied __attribute__((swift_name("doCopy(id:region:roles:subscriptionName:subscriptionId:subscriptionState:name:subscriptionPackage:isTrial:isMfaRequirementSatisfied:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isMfaRequirementSatisfied __attribute__((swift_name("isMfaRequirementSatisfied")));
@property (readonly) BOOL isTrial __attribute__((swift_name("isTrial")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable region __attribute__((swift_name("region")));
@property (readonly) NSArray<NSString *> * _Nullable roles __attribute__((swift_name("roles")));
@property (readonly) int32_t subscriptionId __attribute__((swift_name("subscriptionId")));
@property (readonly) NSString *subscriptionName __attribute__((swift_name("subscriptionName")));
@property (readonly) NSString * _Nullable subscriptionPackage __attribute__((swift_name("subscriptionPackage")));
@property (readonly) NSString * _Nullable subscriptionState __attribute__((swift_name("subscriptionState")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserAccountDto.Companion")))
@interface SLCLUserAccountDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUserAccountDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiEndpoint")))
@interface SLCLApiEndpoint : SLCLKotlinEnum<SLCLApiEndpoint *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLApiEndpointCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLApiEndpoint *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLApiEndpoint *dictationApi __attribute__((swift_name("dictationApi")));
@property (class, readonly) SLCLApiEndpoint *sttRestApi __attribute__((swift_name("sttRestApi")));
@property (class, readonly) SLCLApiEndpoint *sttStreamingRecognition __attribute__((swift_name("sttStreamingRecognition")));
+ (SLCLKotlinArray<SLCLApiEndpoint *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiEndpoint.Companion")))
@interface SLCLApiEndpointCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLApiEndpointCompanion *shared __attribute__((swift_name("shared")));
- (SLCLApiEndpoint *)fromIdId:(NSString *)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Service")))
@interface SLCLService : SLCLKotlinEnum<SLCLService *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLServiceCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLService *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLService *speechlive __attribute__((swift_name("speechlive")));
@property (class, readonly) SLCLService *speechexecEnterprise __attribute__((swift_name("speechexecEnterprise")));
+ (SLCLKotlinArray<SLCLService *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Service.Companion")))
@interface SLCLServiceCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLServiceCompanion *shared __attribute__((swift_name("shared")));
- (SLCLService *)fromIdId:(NSString *)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubscriptionPackage")))
@interface SLCLSubscriptionPackage : SLCLKotlinEnum<SLCLSubscriptionPackage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLSubscriptionPackageCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLSubscriptionPackage *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLSubscriptionPackage *smallBusinessPackage __attribute__((swift_name("smallBusinessPackage")));
@property (class, readonly) SLCLSubscriptionPackage *advancedBusinessPackage __attribute__((swift_name("advancedBusinessPackage")));
+ (SLCLKotlinArray<SLCLSubscriptionPackage *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubscriptionPackage.Companion")))
@interface SLCLSubscriptionPackageCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSubscriptionPackageCompanion *shared __attribute__((swift_name("shared")));
- (SLCLSubscriptionPackage *)fromIdId:(NSString *)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User")))
@interface SLCLUser : SLCLBase
- (instancetype)initWithEmail:(NSString *)email id:(NSString *)id region:(NSString *)region roleIds:(NSArray<NSString *> *)roleIds subscriptionId:(int32_t)subscriptionId subscriptionState:(NSString *)subscriptionState name:(NSString *)name subscriptionPackageId:(NSString *)subscriptionPackageId isTrial:(BOOL)isTrial subscriptionName:(NSString *)subscriptionName isMfaRequirementSatisfied:(BOOL)isMfaRequirementSatisfied serviceId:(NSString *)serviceId __attribute__((swift_name("init(email:id:region:roleIds:subscriptionId:subscriptionState:name:subscriptionPackageId:isTrial:subscriptionName:isMfaRequirementSatisfied:serviceId:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component11 __attribute__((swift_name("component11()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component12 __attribute__((swift_name("component12()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<NSString *> *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUser *)doCopyEmail:(NSString *)email id:(NSString *)id region:(NSString *)region roleIds:(NSArray<NSString *> *)roleIds subscriptionId:(int32_t)subscriptionId subscriptionState:(NSString *)subscriptionState name:(NSString *)name subscriptionPackageId:(NSString *)subscriptionPackageId isTrial:(BOOL)isTrial subscriptionName:(NSString *)subscriptionName isMfaRequirementSatisfied:(BOOL)isMfaRequirementSatisfied serviceId:(NSString *)serviceId __attribute__((swift_name("doCopy(email:id:region:roleIds:subscriptionId:subscriptionState:name:subscriptionPackageId:isTrial:subscriptionName:isMfaRequirementSatisfied:serviceId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isMfaRequirementSatisfied __attribute__((swift_name("isMfaRequirementSatisfied")));
@property (readonly) BOOL isTrial __attribute__((swift_name("isTrial")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *region __attribute__((swift_name("region")));
@property (readonly) NSArray<NSString *> *roleIds __attribute__((swift_name("roleIds")));
@property (readonly) NSArray<SLCLUserRole *> *roles __attribute__((swift_name("roles")));
@property (readonly) SLCLService *service __attribute__((swift_name("service")));
@property (readonly) NSString *serviceId __attribute__((swift_name("serviceId")));
@property (readonly) int32_t subscriptionId __attribute__((swift_name("subscriptionId")));
@property (readonly) NSString *subscriptionName __attribute__((swift_name("subscriptionName")));
@property (readonly) SLCLSubscriptionPackage *subscriptionPackage __attribute__((swift_name("subscriptionPackage")));
@property (readonly) NSString *subscriptionPackageId __attribute__((swift_name("subscriptionPackageId")));
@property (readonly) NSString *subscriptionState __attribute__((swift_name("subscriptionState")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserRole")))
@interface SLCLUserRole : SLCLKotlinEnum<SLCLUserRole *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLUserRoleCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLUserRole *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLUserRole *author __attribute__((swift_name("author")));
@property (class, readonly) SLCLUserRole *transcriptionist __attribute__((swift_name("transcriptionist")));
@property (class, readonly) SLCLUserRole *officeManager __attribute__((swift_name("officeManager")));
@property (class, readonly) SLCLUserRole *accountAdmin __attribute__((swift_name("accountAdmin")));
+ (SLCLKotlinArray<SLCLUserRole *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserRole.Companion")))
@interface SLCLUserRoleCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUserRoleCompanion *shared __attribute__((swift_name("shared")));
- (SLCLUserRole *)fromIdId:(NSString *)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((swift_name("SupportContract")))
@protocol SLCLSupportContract
@required
@end;

__attribute__((swift_name("SupportContractPresenter")))
@protocol SLCLSupportContractPresenter <SLCLBasePresenter>
@required
- (void)onContactSupportButtonClick __attribute__((swift_name("onContactSupportButtonClick()")));
@end;

__attribute__((swift_name("SupportContractView")))
@protocol SLCLSupportContractView <SLCLBaseView>
@required
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)showFileSystemError __attribute__((swift_name("showFileSystemError()")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showSupportFormLogsArchiveFile:(NSString *)logsArchiveFile titleInfo:(NSString *)titleInfo messageInfo:(NSString *)messageInfo __attribute__((swift_name("showSupportForm(logsArchiveFile:titleInfo:messageInfo:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupportPresenter")))
@interface SLCLSupportPresenter : SLCLBase <SLCLSupportContractPresenter, SLCLPresenterCoroutineScope>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger getLogsArchiveFile:(id<SLCLGetLogFile>)getLogsArchiveFile appInfo:(id<SLCLAppInfo>)appInfo environmentInfo:(id<SLCLEnvironmentInfo>)environmentInfo getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser deleteAppTemporaryFiles:(id<SLCLDeleteAppTemporaryFiles>)deleteAppTemporaryFiles __attribute__((swift_name("init(mainContext:logger:getLogsArchiveFile:appInfo:environmentInfo:getCurrentUser:deleteAppTemporaryFiles:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLSupportContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onContactSupportButtonClick __attribute__((swift_name("onContactSupportButtonClick()")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onFocus __attribute__((swift_name("onFocus()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLSupportContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("GetLogFile")))
@protocol SLCLGetLogFile
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetArchivedLogFile")))
@interface SLCLGetArchivedLogFile : SLCLBase <SLCLGetLogFile>
- (instancetype)initWithTempDirectory:(id<SLCLDirectory>)tempDirectory fileArchiver:(id<SLCLFileArchiver>)fileArchiver logReader:(id<SLCLLogReader>)logReader __attribute__((swift_name("init(tempDirectory:fileArchiver:logReader:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("DictationListContract")))
@protocol SLCLDictationListContract
@required
@end;

__attribute__((swift_name("DictationListContractPresenter")))
@protocol SLCLDictationListContractPresenter <SLCLBasePresenter>
@required
- (void)onDictationClickDictation:(SLCLDictation *)dictation __attribute__((swift_name("onDictationClick(dictation:)")));
- (void)onDiscardWorkingCopyAndOpenRecorderClickOriginalDictation:(SLCLDictation *)originalDictation __attribute__((swift_name("onDiscardWorkingCopyAndOpenRecorderClick(originalDictation:)")));
- (void)onGroupClickPreviousGroup:(SLCLDictationGroup *)previousGroup group:(SLCLDictationGroup *)group currentPageNumber:(int32_t)currentPageNumber __attribute__((swift_name("onGroupClick(previousGroup:group:currentPageNumber:)")));
- (void)onNewDictationClick __attribute__((swift_name("onNewDictationClick()")));
- (void)onNewSpeechRecognitionClick __attribute__((swift_name("onNewSpeechRecognitionClick()")));
- (void)onPageClickGroup:(SLCLDictationGroup *)group page:(int32_t)page __attribute__((swift_name("onPageClick(group:page:)")));
- (void)onRecoverWorkingCopyAndOpenRecorderClickDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("onRecoverWorkingCopyAndOpenRecorderClick(dictationWorkingCopy:)")));
- (void)onRefreshDictationGroups:(NSArray<SLCLDictationGroup *> *)dictationGroups __attribute__((swift_name("onRefresh(dictationGroups:)")));
- (void)onSearchClick __attribute__((swift_name("onSearchClick()")));
- (void)onSettingsClick __attribute__((swift_name("onSettingsClick()")));
@end;

__attribute__((swift_name("DictationListContractView")))
@protocol SLCLDictationListContractView <SLCLBaseView>
@required
- (void)decorateForServiceService:(SLCLService *)service __attribute__((swift_name("decorateForService(service:)")));
- (void)hideDictationPlayer __attribute__((swift_name("hideDictationPlayer()")));
- (void)hideDictationSyncProgress __attribute__((swift_name("hideDictationSyncProgress()")));
- (void)hideDownloadProgress __attribute__((swift_name("hideDownloadProgress()")));
- (void)hideErrors __attribute__((swift_name("hideErrors()")));
- (void)hideGroupLoadingGroup:(SLCLDictationGroup *)group __attribute__((swift_name("hideGroupLoading(group:)")));
- (void)hideLoadingIndicator __attribute__((swift_name("hideLoadingIndicator()")));
- (void)highlightDictationsAsUpdatedGroup:(SLCLDictationGroup *)group dictationIds:(NSArray<NSString *> *)dictationIds __attribute__((swift_name("highlightDictationsAsUpdated(group:dictationIds:)")));
- (void)showAppSettings __attribute__((swift_name("showAppSettings()")));
- (void)showAvailableNewItemActionsActions:(NSArray<SLCLDictationListNewItemAction *> *)actions __attribute__((swift_name("showAvailableNewItemActions(actions:)")));
- (void)showDictationPlayerDictation:(SLCLDictation *)dictation __attribute__((swift_name("showDictationPlayer(dictation:)")));
- (void)showDictationRecorderDictation:(SLCLDictation *)dictation isExistingDictation:(BOOL)isExistingDictation __attribute__((swift_name("showDictationRecorder(dictation:isExistingDictation:)")));
- (void)showDictationSearch __attribute__((swift_name("showDictationSearch()")));
- (void)showDictationSyncProgressCurrent:(int32_t)current total:(int32_t)total __attribute__((swift_name("showDictationSyncProgress(current:total:)")));
- (void)showDictationUploadInProgressWarning __attribute__((swift_name("showDictationUploadInProgressWarning()")));
- (void)showDictationsGroup:(SLCLDictationGroup *)group dictations:(NSArray<SLCLDictation *> *)dictations highlightedDictationIds:(NSArray<NSString *> *)highlightedDictationIds page:(int32_t)page hasMorePages:(BOOL)hasMorePages user:(SLCLUser *)user __attribute__((swift_name("showDictations(group:dictations:highlightedDictationIds:page:hasMorePages:user:)")));
- (void)showDownloadProgressName:(NSString *)name totalBytes:(int64_t)totalBytes currentBytes:(int64_t)currentBytes __attribute__((swift_name("showDownloadProgress(name:totalBytes:currentBytes:)")));
- (void)showFileSystemError __attribute__((swift_name("showFileSystemError()")));
- (void)showGroupGroup:(SLCLDictationGroup *)group __attribute__((swift_name("showGroup(group:)")));
- (void)showGroupLoadingGroup:(SLCLDictationGroup *)group __attribute__((swift_name("showGroupLoading(group:)")));
- (void)showLoadingIndicator __attribute__((swift_name("showLoadingIndicator()")));
- (void)showLogin __attribute__((swift_name("showLogin()")));
- (void)showNetworkError __attribute__((swift_name("showNetworkError()")));
- (void)showRecoveredWorkingCopyMessageOriginalDictation:(SLCLDictation *)originalDictation dictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("showRecoveredWorkingCopyMessage(originalDictation:dictationWorkingCopy:)")));
- (void)showServerError __attribute__((swift_name("showServerError()")));
- (void)showSpeechToTextRecorderDictation:(SLCLDictation *)dictation __attribute__((swift_name("showSpeechToTextRecorder(dictation:)")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
- (void)showUnsupportedAudioFormatError __attribute__((swift_name("showUnsupportedAudioFormatError()")));
@end;

__attribute__((swift_name("DictationApi")))
@protocol SLCLDictationApi
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId teamId:(NSString *)teamId completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignDictation(userId:dictationId:teamId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteAttachment(userId:dictationId:attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteDictation(userId:dictationId:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadAttachmentUserId:(NSString *)userId attachment:(SLCLAttachment *)attachment destinationFile:(id<SLCLFile>)destinationFile onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadAttachment(userId:attachment:destinationFile:onProgress:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadDictationFilesUserId:(NSString *)userId dictationId:(NSString *)dictationId destinationFile:(id<SLCLFile>)destinationFile categories:(NSArray<SLCLDictationFileCategory *> *)categories onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadDictationFiles(userId:dictationId:destinationFile:categories:onProgress:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLEither<SLCLAttachment *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachment(userId:dictationId:attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsUserId:(NSString *)userId dictationId:(NSString *)dictationId categories:(NSArray<SLCLDictationFileCategory *> *)categories page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLEither<NSArray<SLCLAttachment *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachments(userId:dictationId:categories:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLEither<SLCLDictation *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictation(userId:dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsUserId:(NSString *)userId states:(NSArray<SLCLDictationState *> *)states isArchived:(BOOL)isArchived page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLEither<NSArray<SLCLDictation *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(userId:states:isArchived:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSubscriptionAndUserInfoUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<SLCLSubscriptionAndUserInfo *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSubscriptionAndUserInfo(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendToSpeechRecognitionUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash languageCode:(NSString *)languageCode completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendToSpeechRecognition(userId:dictationId:metadataFileHash:languageCode:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendToTranscriptionServiceUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash numberOfSpeakers:(int32_t)numberOfSpeakers completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendToTranscriptionService(userId:dictationId:metadataFileHash:numberOfSpeakers:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationAudioUserId:(NSString *)userId dictationId:(NSString *)dictationId dictationFile:(id<SLCLFile>)dictationFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationAudio(userId:dictationId:dictationFile:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationPropertiesUserId:(NSString *)userId dictation:(SLCLDictation *)dictation metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationProperties(userId:dictation:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationStateUserId:(NSString *)userId dictationId:(NSString *)dictationId stateId:(int32_t)stateId metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationState(userId:dictationId:stateId:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentFile:(id<SLCLFile>)attachmentFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadAttachment(userId:dictationId:attachmentFile:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadDictationUserId:(NSString *)userId dictation:(SLCLDictation *)dictation dictationFile:(id<SLCLFile>)dictationFile transcriptionFile:(id<SLCLFile> _Nullable)transcriptionFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadDictation(userId:dictation:dictationFile:transcriptionFile:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseDictationApi")))
@interface SLCLSpeechExecEnterpriseDictationApi : SLCLBase <SLCLDictationApi>
- (instancetype)initWithSpeechExecEnterpriseSettings:(SLCLSpeechExecEnterpriseSettings *)speechExecEnterpriseSettings identityService:(id<SLCLIdentityService>)identityService timeFormatter:(id<SLCLTimeFormatter>)timeFormatter timeProvider:(id<SLCLTimeProvider>)timeProvider contentTypeExtractor:(id<SLCLContentTypeExtractor>)contentTypeExtractor logger:(id<SLCLLogger>)logger httpClient:(SLCLKtor_client_coreHttpClient *)httpClient networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor uuidFactory:(id<SLCLUuidFactory>)uuidFactory __attribute__((swift_name("init(speechExecEnterpriseSettings:identityService:timeFormatter:timeProvider:contentTypeExtractor:logger:httpClient:networkConnectivityMonitor:uuidFactory:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId teamId:(NSString *)teamId completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignDictation(userId:dictationId:teamId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteAttachment(userId:dictationId:attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteDictation(userId:dictationId:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadAttachmentUserId:(NSString *)userId attachment:(SLCLAttachment *)attachment destinationFile:(id<SLCLFile>)destinationFile onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadAttachment(userId:attachment:destinationFile:onProgress:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadDictationFilesUserId:(NSString *)userId dictationId:(NSString *)dictationId destinationFile:(id<SLCLFile>)destinationFile categories:(NSArray<SLCLDictationFileCategory *> *)categories onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadDictationFiles(userId:dictationId:destinationFile:categories:onProgress:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLEither<SLCLAttachment *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachment(userId:dictationId:attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsUserId:(NSString *)userId dictationId:(NSString *)dictationId categories:(NSArray<SLCLDictationFileCategory *> *)categories page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLEither<NSArray<SLCLAttachment *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachments(userId:dictationId:categories:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLEither<SLCLDictation *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictation(userId:dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsUserId:(NSString *)userId states:(NSArray<SLCLDictationState *> *)states isArchived:(BOOL)isArchived page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLEither<NSArray<SLCLDictation *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(userId:states:isArchived:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsByIdUserId:(NSString *)userId dictationIds:(NSArray<NSString *> *)dictationIds completionHandler:(void (^)(SLCLEither<NSArray<SLCLDictation *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationsById(userId:dictationIds:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSpeechExecUserSettingsUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<SLCLSpeechExecEnterpriseUserSettingsDto *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSpeechExecUserSettings(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSubscriptionAndUserInfoUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<SLCLSubscriptionAndUserInfo *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSubscriptionAndUserInfo(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendToSpeechRecognitionUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash languageCode:(NSString *)languageCode completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendToSpeechRecognition(userId:dictationId:metadataFileHash:languageCode:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendToTranscriptionServiceUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash numberOfSpeakers:(int32_t)numberOfSpeakers completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendToTranscriptionService(userId:dictationId:metadataFileHash:numberOfSpeakers:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationAudioUserId:(NSString *)userId dictationId:(NSString *)dictationId dictationFile:(id<SLCLFile>)dictationFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationAudio(userId:dictationId:dictationFile:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationPropertiesUserId:(NSString *)userId dictation:(SLCLDictation *)dictation metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationProperties(userId:dictation:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationStateUserId:(NSString *)userId dictationId:(NSString *)dictationId stateId:(int32_t)stateId metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationState(userId:dictationId:stateId:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentFile:(id<SLCLFile>)attachmentFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadAttachment(userId:dictationId:attachmentFile:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadDictationUserId:(NSString *)userId dictation:(SLCLDictation *)dictation dictationFile:(id<SLCLFile>)dictationFile languageCode:(NSString * _Nullable)languageCode numberOfSpeakers:(SLCLInt * _Nullable)numberOfSpeakers completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadDictation(userId:dictation:dictationFile:languageCode:numberOfSpeakers:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadDictationUserId:(NSString *)userId dictation:(SLCLDictation *)dictation dictationFile:(id<SLCLFile>)dictationFile transcriptionFile:(id<SLCLFile> _Nullable)transcriptionFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadDictation(userId:dictation:dictationFile:transcriptionFile:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseGetDictationsByIdRequestDto")))
@interface SLCLSpeechExecEnterpriseGetDictationsByIdRequestDto : SLCLBase
- (instancetype)initWithClientRequestIdentifier:(NSString *)clientRequestIdentifier dictationIds:(NSArray<NSString *> *)dictationIds __attribute__((swift_name("init(clientRequestIdentifier:dictationIds:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSpeechExecEnterpriseGetDictationsByIdRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<NSString *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechExecEnterpriseGetDictationsByIdRequestDto *)doCopyClientRequestIdentifier:(NSString *)clientRequestIdentifier dictationIds:(NSArray<NSString *> *)dictationIds __attribute__((swift_name("doCopy(clientRequestIdentifier:dictationIds:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *clientRequestIdentifier __attribute__((swift_name("clientRequestIdentifier")));
@property (readonly) NSArray<NSString *> *dictationIds __attribute__((swift_name("dictationIds")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseGetDictationsByIdRequestDto.Companion")))
@interface SLCLSpeechExecEnterpriseGetDictationsByIdRequestDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechExecEnterpriseGetDictationsByIdRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseUserSettingsDto")))
@interface SLCLSpeechExecEnterpriseUserSettingsDto : SLCLBase
- (instancetype)initWithIsNdevSrEnabled:(BOOL)IsNdevSrEnabled PreferredNdevLanguageCodes:(NSString *)PreferredNdevLanguageCodes SupportedNdevLanguageCodes:(NSString *)SupportedNdevLanguageCodes IsTranscriptionServiceEnabled:(BOOL)IsTranscriptionServiceEnabled IsMultiSpeakerTranscriptionEnabled:(BOOL)IsMultiSpeakerTranscriptionEnabled SpeechKitSRSettings:(SLCLSpeechKitSrSettingsDto * _Nullable)SpeechKitSRSettings __attribute__((swift_name("init(IsNdevSrEnabled:PreferredNdevLanguageCodes:SupportedNdevLanguageCodes:IsTranscriptionServiceEnabled:IsMultiSpeakerTranscriptionEnabled:SpeechKitSRSettings:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSpeechExecEnterpriseUserSettingsDtoCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechKitSrSettingsDto * _Nullable)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechExecEnterpriseUserSettingsDto *)doCopyIsNdevSrEnabled:(BOOL)IsNdevSrEnabled PreferredNdevLanguageCodes:(NSString *)PreferredNdevLanguageCodes SupportedNdevLanguageCodes:(NSString *)SupportedNdevLanguageCodes IsTranscriptionServiceEnabled:(BOOL)IsTranscriptionServiceEnabled IsMultiSpeakerTranscriptionEnabled:(BOOL)IsMultiSpeakerTranscriptionEnabled SpeechKitSRSettings:(SLCLSpeechKitSrSettingsDto * _Nullable)SpeechKitSRSettings __attribute__((swift_name("doCopy(IsNdevSrEnabled:PreferredNdevLanguageCodes:SupportedNdevLanguageCodes:IsTranscriptionServiceEnabled:IsMultiSpeakerTranscriptionEnabled:SpeechKitSRSettings:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL IsMultiSpeakerTranscriptionEnabled __attribute__((swift_name("IsMultiSpeakerTranscriptionEnabled")));
@property (readonly) BOOL IsNdevSrEnabled __attribute__((swift_name("IsNdevSrEnabled")));
@property (readonly) BOOL IsTranscriptionServiceEnabled __attribute__((swift_name("IsTranscriptionServiceEnabled")));
@property (readonly) NSString *PreferredNdevLanguageCodes __attribute__((swift_name("PreferredNdevLanguageCodes")));
@property (readonly) SLCLSpeechKitSrSettingsDto * _Nullable SpeechKitSRSettings __attribute__((swift_name("SpeechKitSRSettings")));
@property (readonly) NSString *SupportedNdevLanguageCodes __attribute__((swift_name("SupportedNdevLanguageCodes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseUserSettingsDto.Companion")))
@interface SLCLSpeechExecEnterpriseUserSettingsDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechExecEnterpriseUserSettingsDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechKitLanguageAndTopicDto")))
@interface SLCLSpeechKitLanguageAndTopicDto : SLCLBase
- (instancetype)initWithID:(NSString *)ID LanguageDisplayedName:(NSString *)LanguageDisplayedName TopicName:(NSString *)TopicName __attribute__((swift_name("init(ID:LanguageDisplayedName:TopicName:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSpeechKitLanguageAndTopicDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechKitLanguageAndTopicDto *)doCopyID:(NSString *)ID LanguageDisplayedName:(NSString *)LanguageDisplayedName TopicName:(NSString *)TopicName __attribute__((swift_name("doCopy(ID:LanguageDisplayedName:TopicName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *ID __attribute__((swift_name("ID")));
@property (readonly) NSString *LanguageDisplayedName __attribute__((swift_name("LanguageDisplayedName")));
@property (readonly) NSString *TopicName __attribute__((swift_name("TopicName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechKitLanguageAndTopicDto.Companion")))
@interface SLCLSpeechKitLanguageAndTopicDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechKitLanguageAndTopicDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechKitSrSettingsDto")))
@interface SLCLSpeechKitSrSettingsDto : SLCLBase
- (instancetype)initWithIsSpeechKitSREnabledForUser:(BOOL)IsSpeechKitSREnabledForUser SpeechKitSRAllowedLanguageAndTopicItems:(NSArray<SLCLSpeechKitLanguageAndTopicDto *> *)SpeechKitSRAllowedLanguageAndTopicItems __attribute__((swift_name("init(IsSpeechKitSREnabledForUser:SpeechKitSRAllowedLanguageAndTopicItems:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSpeechKitSrSettingsDtoCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<SLCLSpeechKitLanguageAndTopicDto *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechKitSrSettingsDto *)doCopyIsSpeechKitSREnabledForUser:(BOOL)IsSpeechKitSREnabledForUser SpeechKitSRAllowedLanguageAndTopicItems:(NSArray<SLCLSpeechKitLanguageAndTopicDto *> *)SpeechKitSRAllowedLanguageAndTopicItems __attribute__((swift_name("doCopy(IsSpeechKitSREnabledForUser:SpeechKitSRAllowedLanguageAndTopicItems:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL IsSpeechKitSREnabledForUser __attribute__((swift_name("IsSpeechKitSREnabledForUser")));
@property (readonly) NSArray<SLCLSpeechKitLanguageAndTopicDto *> *SpeechKitSRAllowedLanguageAndTopicItems __attribute__((swift_name("SpeechKitSRAllowedLanguageAndTopicItems")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechKitSrSettingsDto.Companion")))
@interface SLCLSpeechKitSrSettingsDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSpeechKitSrSettingsDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechLiveDictationApi")))
@interface SLCLSpeechLiveDictationApi : SLCLBase <SLCLDictationApi>
- (instancetype)initWithHttpClient:(SLCLKtor_client_coreHttpClient *)httpClient logger:(id<SLCLLogger>)logger apiServerEnvironment:(SLCLApiServerEnvironment *)apiServerEnvironment apiVersion:(int32_t)apiVersion identityService:(id<SLCLIdentityService>)identityService timeProvider:(id<SLCLTimeProvider>)timeProvider timeFormatter:(id<SLCLTimeFormatter>)timeFormatter contentTypeExtractor:(id<SLCLContentTypeExtractor>)contentTypeExtractor networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor __attribute__((swift_name("init(httpClient:logger:apiServerEnvironment:apiVersion:identityService:timeProvider:timeFormatter:contentTypeExtractor:networkConnectivityMonitor:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId teamId:(NSString *)teamId completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignDictation(userId:dictationId:teamId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteAttachment(userId:dictationId:attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteDictation(userId:dictationId:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadAttachmentUserId:(NSString *)userId attachment:(SLCLAttachment *)attachment destinationFile:(id<SLCLFile>)destinationFile onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadAttachment(userId:attachment:destinationFile:onProgress:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)downloadDictationFilesUserId:(NSString *)userId dictationId:(NSString *)dictationId destinationFile:(id<SLCLFile>)destinationFile categories:(NSArray<SLCLDictationFileCategory *> *)categories onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLEither<SLCLBoolean *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("downloadDictationFiles(userId:dictationId:destinationFile:categories:onProgress:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLEither<SLCLAttachment *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachment(userId:dictationId:attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsUserId:(NSString *)userId dictationId:(NSString *)dictationId categories:(NSArray<SLCLDictationFileCategory *> *)categories page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLEither<NSArray<SLCLAttachment *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachments(userId:dictationId:categories:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationUserId:(NSString *)userId dictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLEither<SLCLDictation *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictation(userId:dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsUserId:(NSString *)userId states:(NSArray<SLCLDictationState *> *)states isArchived:(BOOL)isArchived page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLEither<NSArray<SLCLDictation *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(userId:states:isArchived:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSubscriptionAndUserInfoUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<SLCLSubscriptionAndUserInfo *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSubscriptionAndUserInfo(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendToSpeechRecognitionUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash languageCode:(NSString *)languageCode completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendToSpeechRecognition(userId:dictationId:metadataFileHash:languageCode:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendToTranscriptionServiceUserId:(NSString *)userId dictationId:(NSString *)dictationId metadataFileHash:(NSString *)metadataFileHash numberOfSpeakers:(int32_t)numberOfSpeakers completionHandler:(void (^)(SLCLEither<SLCLKotlinUnit *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sendToTranscriptionService(userId:dictationId:metadataFileHash:numberOfSpeakers:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationAudioUserId:(NSString *)userId dictationId:(NSString *)dictationId dictationFile:(id<SLCLFile>)dictationFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationAudio(userId:dictationId:dictationFile:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationPropertiesUserId:(NSString *)userId dictation:(SLCLDictation *)dictation metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationProperties(userId:dictation:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDictationStateUserId:(NSString *)userId dictationId:(NSString *)dictationId stateId:(int32_t)stateId metadataFileHash:(NSString *)metadataFileHash completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateDictationState(userId:dictationId:stateId:metadataFileHash:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadAttachmentUserId:(NSString *)userId dictationId:(NSString *)dictationId attachmentFile:(id<SLCLFile>)attachmentFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadAttachment(userId:dictationId:attachmentFile:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadDictationUserId:(NSString *)userId dictation:(SLCLDictation *)dictation dictationFile:(id<SLCLFile>)dictationFile transcriptionFile:(id<SLCLFile> _Nullable)transcriptionFile completionHandler:(void (^)(SLCLEither<NSString *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadDictation(userId:dictation:dictationFile:transcriptionFile:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteRequestDto")))
@interface SLCLDeleteRequestDto : SLCLBase
- (instancetype)initWithMetadataFileHash:(NSString *)metadataFileHash __attribute__((swift_name("init(metadataFileHash:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDeleteRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDeleteRequestDto *)doCopyMetadataFileHash:(NSString *)metadataFileHash __attribute__((swift_name("doCopy(metadataFileHash:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *metadataFileHash __attribute__((swift_name("metadataFileHash")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteRequestDto.Companion")))
@interface SLCLDeleteRequestDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DesktopAppSettingsDto")))
@interface SLCLDesktopAppSettingsDto : SLCLBase
- (instancetype)initWithSpeechRecognitionServerUrl:(NSString *)speechRecognitionServerUrl __attribute__((swift_name("init(speechRecognitionServerUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDesktopAppSettingsDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDesktopAppSettingsDto *)doCopySpeechRecognitionServerUrl:(NSString *)speechRecognitionServerUrl __attribute__((swift_name("doCopy(speechRecognitionServerUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *speechRecognitionServerUrl __attribute__((swift_name("speechRecognitionServerUrl")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DesktopAppSettingsDto.Companion")))
@interface SLCLDesktopAppSettingsDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDesktopAppSettingsDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubscriptionAndUserInfoDto")))
@interface SLCLSubscriptionAndUserInfoDto : SLCLBase
- (instancetype)initWithTranscriptionServiceEnabled:(BOOL)transcriptionServiceEnabled transcriptionServiceAvailableMinutes:(double)transcriptionServiceAvailableMinutes sttServiceForUserEnabled:(BOOL)sttServiceForUserEnabled correctionPendingEnabled:(BOOL)correctionPendingEnabled __attribute__((swift_name("init(transcriptionServiceEnabled:transcriptionServiceAvailableMinutes:sttServiceForUserEnabled:correctionPendingEnabled:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLSubscriptionAndUserInfoDtoCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (double)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSubscriptionAndUserInfoDto *)doCopyTranscriptionServiceEnabled:(BOOL)transcriptionServiceEnabled transcriptionServiceAvailableMinutes:(double)transcriptionServiceAvailableMinutes sttServiceForUserEnabled:(BOOL)sttServiceForUserEnabled correctionPendingEnabled:(BOOL)correctionPendingEnabled __attribute__((swift_name("doCopy(transcriptionServiceEnabled:transcriptionServiceAvailableMinutes:sttServiceForUserEnabled:correctionPendingEnabled:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL correctionPendingEnabled __attribute__((swift_name("correctionPendingEnabled")));
@property (readonly) BOOL sttServiceForUserEnabled __attribute__((swift_name("sttServiceForUserEnabled")));
@property (readonly) double transcriptionServiceAvailableMinutes __attribute__((swift_name("transcriptionServiceAvailableMinutes")));
@property (readonly) BOOL transcriptionServiceEnabled __attribute__((swift_name("transcriptionServiceEnabled")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubscriptionAndUserInfoDto.Companion")))
@interface SLCLSubscriptionAndUserInfoDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSubscriptionAndUserInfoDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateDictationPropertiesResponseDto")))
@interface SLCLUpdateDictationPropertiesResponseDto : SLCLBase
- (instancetype)initWithMetadataFileHash:(NSString * _Nullable)metadataFileHash __attribute__((swift_name("init(metadataFileHash:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLUpdateDictationPropertiesResponseDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUpdateDictationPropertiesResponseDto *)doCopyMetadataFileHash:(NSString * _Nullable)metadataFileHash __attribute__((swift_name("doCopy(metadataFileHash:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable metadataFileHash __attribute__((swift_name("metadataFileHash")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateDictationPropertiesResponseDto.Companion")))
@interface SLCLUpdateDictationPropertiesResponseDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUpdateDictationPropertiesResponseDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateDictationStateRequestDto")))
@interface SLCLUpdateDictationStateRequestDto : SLCLBase
- (instancetype)initWithMetadataFileHash:(NSString *)metadataFileHash state:(int32_t)state __attribute__((swift_name("init(metadataFileHash:state:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLUpdateDictationStateRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUpdateDictationStateRequestDto *)doCopyMetadataFileHash:(NSString *)metadataFileHash state:(int32_t)state __attribute__((swift_name("doCopy(metadataFileHash:state:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *metadataFileHash __attribute__((swift_name("metadataFileHash")));
@property (readonly) int32_t state __attribute__((swift_name("state")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateDictationStateRequestDto.Companion")))
@interface SLCLUpdateDictationStateRequestDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUpdateDictationStateRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("AddOfflineDictationsToQueue")))
@protocol SLCLAddOfflineDictationsToQueue
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((swift_name("AddToUploadQueue")))
@protocol SLCLAddToUploadQueue
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationId:(NSString *)dictationId targetState:(SLCLDictationState *)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationId:targetState:speechRecognitionLanguageCode:teamId:completionHandler:)")));
@end;

__attribute__((swift_name("ChangeRemoteDictationState")))
@protocol SLCLChangeRemoteDictationState
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy newState:(SLCLDictationState *)newState completionHandler:(void (^)(SLCLChangeRemoteDictationStateOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:newState:completionHandler:)")));
@end;

__attribute__((swift_name("ChangeRemoteDictationStateOutput")))
@interface SLCLChangeRemoteDictationStateOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangeRemoteDictationStateOutput.NetworkError")))
@interface SLCLChangeRemoteDictationStateOutputNetworkError : SLCLChangeRemoteDictationStateOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLChangeRemoteDictationStateOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangeRemoteDictationStateOutput.ServerError")))
@interface SLCLChangeRemoteDictationStateOutputServerError : SLCLChangeRemoteDictationStateOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLChangeRemoteDictationStateOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangeRemoteDictationStateOutput.Success")))
@interface SLCLChangeRemoteDictationStateOutputSuccess : SLCLChangeRemoteDictationStateOutput
- (instancetype)initWithUpdatedOriginalDictation:(SLCLDictation *)updatedOriginalDictation updatedDictationWorkingCopy:(SLCLDictation *)updatedDictationWorkingCopy __attribute__((swift_name("init(updatedOriginalDictation:updatedDictationWorkingCopy:)"))) __attribute__((objc_designated_initializer));
- (SLCLChangeRemoteDictationStateOutputSuccess *)doCopyUpdatedOriginalDictation:(SLCLDictation *)updatedOriginalDictation updatedDictationWorkingCopy:(SLCLDictation *)updatedDictationWorkingCopy __attribute__((swift_name("doCopy(updatedOriginalDictation:updatedDictationWorkingCopy:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangeRemoteDictationStateOutput.UnexpectedError")))
@interface SLCLChangeRemoteDictationStateOutputUnexpectedError : SLCLChangeRemoteDictationStateOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLChangeRemoteDictationStateOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangeRemoteDictationStateOutput.UserNotAuthenticated")))
@interface SLCLChangeRemoteDictationStateOutputUserNotAuthenticated : SLCLChangeRemoteDictationStateOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLChangeRemoteDictationStateOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("CheckIfAudioFormatSupported")))
@protocol SLCLCheckIfAudioFormatSupported
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckIfAudioFormatSupportedWithBlacklist")))
@interface SLCLCheckIfAudioFormatSupportedWithBlacklist : SLCLBase <SLCLCheckIfAudioFormatSupported>
- (instancetype)initWithUnsupportedAudioTypes:(NSArray<SLCLAudioType *> *)unsupportedAudioTypes unsupportedAudioFormats:(NSArray<id<SLCLAudioFormat>> *)unsupportedAudioFormats __attribute__((swift_name("init(unsupportedAudioTypes:unsupportedAudioFormats:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((swift_name("CheckIfDirectAssignmentForSpeechToTextEnabled")))
@protocol SLCLCheckIfDirectAssignmentForSpeechToTextEnabled
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("CheckIfSpeechToTextAvailable")))
@protocol SLCLCheckIfSpeechToTextAvailable
@required
- (BOOL)invokeUser:(SLCLUser *)user subscriptionAndUserInfo:(SLCLSubscriptionAndUserInfo *)subscriptionAndUserInfo __attribute__((swift_name("invoke(user:subscriptionAndUserInfo:)")));
@end;

__attribute__((swift_name("CheckIfTranscriptionServiceAvailable")))
@protocol SLCLCheckIfTranscriptionServiceAvailable
@required
- (BOOL)invokeSubscriptionAndUserInfo:(SLCLSubscriptionAndUserInfo *)subscriptionAndUserInfo __attribute__((swift_name("invoke(subscriptionAndUserInfo:)")));
@end;

__attribute__((swift_name("CheckWorkingCopyHasUnmergedChanges")))
@protocol SLCLCheckWorkingCopyHasUnmergedChanges
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy completionHandler:(void (^)(SLCLCheckWorkingCopyHasUnmergedChangesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:completionHandler:)")));
@end;

__attribute__((swift_name("CheckWorkingCopyHasUnmergedChangesOutput")))
@interface SLCLCheckWorkingCopyHasUnmergedChangesOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckWorkingCopyHasUnmergedChangesOutput.No")))
@interface SLCLCheckWorkingCopyHasUnmergedChangesOutputNo : SLCLCheckWorkingCopyHasUnmergedChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)no __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCheckWorkingCopyHasUnmergedChangesOutputNo *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckWorkingCopyHasUnmergedChangesOutput.UnexpectedError")))
@interface SLCLCheckWorkingCopyHasUnmergedChangesOutputUnexpectedError : SLCLCheckWorkingCopyHasUnmergedChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCheckWorkingCopyHasUnmergedChangesOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckWorkingCopyHasUnmergedChangesOutput.Yes")))
@interface SLCLCheckWorkingCopyHasUnmergedChangesOutputYes : SLCLCheckWorkingCopyHasUnmergedChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)yes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCheckWorkingCopyHasUnmergedChangesOutputYes *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("ConvertWorkingCopyToNewDictation")))
@protocol SLCLConvertWorkingCopyToNewDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy completionHandler:(void (^)(SLCLConvertWorkingCopyToNewDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:completionHandler:)")));
@end;

__attribute__((swift_name("ConvertWorkingCopyToNewDictationOutput")))
@interface SLCLConvertWorkingCopyToNewDictationOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConvertWorkingCopyToNewDictationOutput.FileSystemError")))
@interface SLCLConvertWorkingCopyToNewDictationOutputFileSystemError : SLCLConvertWorkingCopyToNewDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLConvertWorkingCopyToNewDictationOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConvertWorkingCopyToNewDictationOutput.Success")))
@interface SLCLConvertWorkingCopyToNewDictationOutputSuccess : SLCLConvertWorkingCopyToNewDictationOutput
- (instancetype)initWithNewDictation:(SLCLDictation *)newDictation __attribute__((swift_name("init(newDictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLConvertWorkingCopyToNewDictationOutputSuccess *)doCopyNewDictation:(SLCLDictation *)newDictation __attribute__((swift_name("doCopy(newDictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=doNewDictation) SLCLDictation *newDictation __attribute__((swift_name("newDictation")));
@end;

__attribute__((swift_name("CreateDictation")))
@protocol SLCLCreateDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLCreateDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("CreateDictationOutput")))
@interface SLCLCreateDictationOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDictationOutput.FileSystemError")))
@interface SLCLCreateDictationOutputFileSystemError : SLCLCreateDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateDictationOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDictationOutput.Success")))
@interface SLCLCreateDictationOutputSuccess : SLCLCreateDictationOutput
- (instancetype)initWithDictation:(SLCLDictation *)dictation __attribute__((swift_name("init(dictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLCreateDictationOutputSuccess *)doCopyDictation:(SLCLDictation *)dictation __attribute__((swift_name("doCopy(dictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictation __attribute__((swift_name("dictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDictationOutput.UnexpectedError")))
@interface SLCLCreateDictationOutputUnexpectedError : SLCLCreateDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateDictationOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("CreateDictationWorkingCopy")))
@protocol SLCLCreateDictationWorkingCopy
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalDictation:(SLCLDictation *)originalDictation completionHandler:(void (^)(SLCLCreateDictationWorkingCopyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalDictation:completionHandler:)")));
@end;

__attribute__((swift_name("CreateDictationWorkingCopyOutput")))
@interface SLCLCreateDictationWorkingCopyOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDictationWorkingCopyOutput.FileSystemError")))
@interface SLCLCreateDictationWorkingCopyOutputFileSystemError : SLCLCreateDictationWorkingCopyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateDictationWorkingCopyOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDictationWorkingCopyOutput.Success")))
@interface SLCLCreateDictationWorkingCopyOutputSuccess : SLCLCreateDictationWorkingCopyOutput
- (instancetype)initWithDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("init(dictationWorkingCopy:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLCreateDictationWorkingCopyOutputSuccess *)doCopyDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("doCopy(dictationWorkingCopy:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictationWorkingCopy __attribute__((swift_name("dictationWorkingCopy")));
@end;

__attribute__((swift_name("CreateEmptyAudioFile")))
@protocol SLCLCreateEmptyAudioFile
@required
- (SLCLCreateEmptyAudioFileOutput *)invokeAudioFile:(id<SLCLFile>)audioFile audioSettings:(SLCLAudioSettings *)audioSettings __attribute__((swift_name("invoke(audioFile:audioSettings:)")));
@end;

__attribute__((swift_name("CreateEmptyAudioFileOutput")))
@interface SLCLCreateEmptyAudioFileOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateEmptyAudioFileOutput.FileSystemError")))
@interface SLCLCreateEmptyAudioFileOutputFileSystemError : SLCLCreateEmptyAudioFileOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateEmptyAudioFileOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateEmptyAudioFileOutput.Success")))
@interface SLCLCreateEmptyAudioFileOutputSuccess : SLCLCreateEmptyAudioFileOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLCreateEmptyAudioFileOutputSuccess *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("DecryptAttachments")))
@protocol SLCLDecryptAttachments
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachments:(NSArray<SLCLAttachmentFile *> *)attachments completionHandler:(void (^)(NSArray<SLCLAttachmentFile *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachments:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultAddOfflineDictationsToQueue")))
@interface SLCLDefaultAddOfflineDictationsToQueue : SLCLBase <SLCLAddOfflineDictationsToQueue>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationRepository:(id<SLCLDictationRepository>)dictationRepository addToUploadQueue:(id<SLCLAddToUploadQueue>)addToUploadQueue uploadQueueRepository:(id<SLCLUploadQueueRepository>)uploadQueueRepository startUploadingNextAvailableDictation:(id<SLCLStartUploadingNextAvailableDictation>)startUploadingNextAvailableDictation logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationRepository:addToUploadQueue:uploadQueueRepository:startUploadingNextAvailableDictation:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultAddToUploadQueue")))
@interface SLCLDefaultAddToUploadQueue : SLCLBase <SLCLAddToUploadQueue>
- (instancetype)initWithUploadQueueRepository:(id<SLCLUploadQueueRepository>)uploadQueueRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository getOriginalDictationFromWorkingCopy:(id<SLCLGetOriginalDictationFromWorkingCopy>)getOriginalDictationFromWorkingCopy createDictationWorkingCopy:(id<SLCLCreateDictationWorkingCopy>)createDictationWorkingCopy getWorkingCopyFromOriginalDictation:(id<SLCLGetWorkingCopyFromOriginalDictation>)getWorkingCopyFromOriginalDictation mergeWorkingCopyWithOriginal:(id<SLCLMergeWorkingCopyWithOriginal>)mergeWorkingCopyWithOriginal logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(uploadQueueRepository:dictationRepository:getOriginalDictationFromWorkingCopy:createDictationWorkingCopy:getWorkingCopyFromOriginalDictation:mergeWorkingCopyWithOriginal:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationId:(NSString *)dictationId targetState:(SLCLDictationState *)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationId:targetState:speechRecognitionLanguageCode:teamId:completionHandler:)")));
@property (readonly) id<SLCLCreateDictationWorkingCopy> createDictationWorkingCopy __attribute__((swift_name("createDictationWorkingCopy")));
@property (readonly) id<SLCLDictationRepository> dictationRepository __attribute__((swift_name("dictationRepository")));
@property (readonly) id<SLCLGetOriginalDictationFromWorkingCopy> getOriginalDictationFromWorkingCopy __attribute__((swift_name("getOriginalDictationFromWorkingCopy")));
@property (readonly) id<SLCLGetWorkingCopyFromOriginalDictation> getWorkingCopyFromOriginalDictation __attribute__((swift_name("getWorkingCopyFromOriginalDictation")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property (readonly) id<SLCLMergeWorkingCopyWithOriginal> mergeWorkingCopyWithOriginal __attribute__((swift_name("mergeWorkingCopyWithOriginal")));
@property (readonly) id<SLCLUploadQueueRepository> uploadQueueRepository __attribute__((swift_name("uploadQueueRepository")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultChangeRemoteDictationState")))
@interface SLCLDefaultChangeRemoteDictationState : SLCLBase <SLCLChangeRemoteDictationState>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi timeProvider:(id<SLCLTimeProvider>)timeProvider getOriginalDictationFromWorkingCopy:(id<SLCLGetOriginalDictationFromWorkingCopy>)getOriginalDictationFromWorkingCopy dictationRepository:(id<SLCLDictationRepository>)dictationRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationApi:timeProvider:getOriginalDictationFromWorkingCopy:dictationRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy newState:(SLCLDictationState *)newState completionHandler:(void (^)(SLCLChangeRemoteDictationStateOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:newState:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckIfDirectAssignmentForSpeechToTextEnabled")))
@interface SLCLDefaultCheckIfDirectAssignmentForSpeechToTextEnabled : SLCLBase <SLCLCheckIfDirectAssignmentForSpeechToTextEnabled>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi featureFlagsConfig:(id<SLCLFeatureFlagsConfig>)featureFlagsConfig logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationApi:featureFlagsConfig:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckIfSpeechToTextAvailable")))
@interface SLCLDefaultCheckIfSpeechToTextAvailable : SLCLBase <SLCLCheckIfSpeechToTextAvailable>
- (instancetype)initWithLogger:(id<SLCLLogger>)logger appSettings:(id<SLCLAppSettings>)appSettings __attribute__((swift_name("init(logger:appSettings:)"))) __attribute__((objc_designated_initializer));
- (BOOL)invokeUser:(SLCLUser *)user subscriptionAndUserInfo:(SLCLSubscriptionAndUserInfo *)subscriptionAndUserInfo __attribute__((swift_name("invoke(user:subscriptionAndUserInfo:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckIfTranscriptionServiceAvailable")))
@interface SLCLDefaultCheckIfTranscriptionServiceAvailable : SLCLBase <SLCLCheckIfTranscriptionServiceAvailable>
- (instancetype)initWithLogger:(id<SLCLLogger>)logger __attribute__((swift_name("init(logger:)"))) __attribute__((objc_designated_initializer));
- (BOOL)invokeSubscriptionAndUserInfo:(SLCLSubscriptionAndUserInfo *)subscriptionAndUserInfo __attribute__((swift_name("invoke(subscriptionAndUserInfo:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCheckWorkingCopyHasUnmergedChanges")))
@interface SLCLDefaultCheckWorkingCopyHasUnmergedChanges : SLCLBase <SLCLCheckWorkingCopyHasUnmergedChanges>
- (instancetype)initWithGetOriginalDictationFromWorkingCopy:(id<SLCLGetOriginalDictationFromWorkingCopy>)getOriginalDictationFromWorkingCopy attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository generateDictationFileHash:(SLCLDefaultGenerateDictationFileHash *)generateDictationFileHash dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getOriginalDictationFromWorkingCopy:attachmentRepository:generateDictationFileHash:dictationFilesRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy completionHandler:(void (^)(SLCLCheckWorkingCopyHasUnmergedChangesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultConvertWorkingCopyToNewDictation")))
@interface SLCLDefaultConvertWorkingCopyToNewDictation : SLCLBase <SLCLConvertWorkingCopyToNewDictation>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository generateAutoIncrementingFileName:(id<SLCLGenerateAutoIncrementingFileName>)generateAutoIncrementingFileName timeProvider:(id<SLCLTimeProvider>)timeProvider encryptFile:(id<SLCLEncryptFile>)encryptFile decryptFile:(id<SLCLDecryptFile>)decryptFile logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationRepository:attachmentRepository:dictationFilesRepository:generateAutoIncrementingFileName:timeProvider:encryptFile:decryptFile:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy completionHandler:(void (^)(SLCLConvertWorkingCopyToNewDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCreateDictation")))
@interface SLCLDefaultCreateDictation : SLCLBase <SLCLCreateDictation>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser generateAutoIncrementingFileName:(id<SLCLGenerateAutoIncrementingFileName>)generateAutoIncrementingFileName getDictationAudioFileNamePattern:(id<SLCLGetDictationAudioFileNamePattern>)getDictationAudioFileNamePattern uuidFactory:(id<SLCLUuidFactory>)uuidFactory timeProvider:(id<SLCLTimeProvider>)timeProvider getCurrentAudioSettings:(id<SLCLGetCurrentAudioSettings>)getCurrentAudioSettings dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository createEmptyAudioFile:(id<SLCLCreateEmptyAudioFile>)createEmptyAudioFile createAttachment:(id<SLCLCreateAttachment>)createAttachment appSettings:(id<SLCLAppSettings>)appSettings logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:generateAutoIncrementingFileName:getDictationAudioFileNamePattern:uuidFactory:timeProvider:getCurrentAudioSettings:dictationFilesRepository:dictationRepository:createEmptyAudioFile:createAttachment:appSettings:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(SLCLCreateDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCreateDictationWorkingCopy")))
@interface SLCLDefaultCreateDictationWorkingCopy : SLCLBase <SLCLCreateDictationWorkingCopy>
- (instancetype)initWithUuidFactory:(id<SLCLUuidFactory>)uuidFactory dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(uuidFactory:dictationRepository:attachmentRepository:dictationFilesRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalDictation:(SLCLDictation *)originalDictation completionHandler:(void (^)(SLCLCreateDictationWorkingCopyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalDictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultCreateEmptyAudioFile")))
@interface SLCLDefaultCreateEmptyAudioFile : SLCLBase <SLCLCreateEmptyAudioFile>
- (instancetype)initWithAudioFileRecorder:(id<SLCLAudioFileRecorder>)audioFileRecorder logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(audioFileRecorder:logger:)"))) __attribute__((objc_designated_initializer));
- (SLCLCreateEmptyAudioFileOutput *)invokeAudioFile:(id<SLCLFile>)audioFile audioSettings:(SLCLAudioSettings *)audioSettings __attribute__((swift_name("invoke(audioFile:audioSettings:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDecryptAttachments")))
@interface SLCLDefaultDecryptAttachments : SLCLBase <SLCLDecryptAttachments>
- (instancetype)initWithDecryptFile:(id<SLCLDecryptFile>)decryptFile logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(decryptFile:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAttachments:(NSArray<SLCLAttachmentFile *> *)attachments completionHandler:(void (^)(NSArray<SLCLAttachmentFile *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(attachments:completionHandler:)")));
@end;

__attribute__((swift_name("DeleteDictation")))
@protocol SLCLDeleteDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(SLCLDeleteDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDeleteDictation")))
@interface SLCLDefaultDeleteDictation : SLCLBase <SLCLDeleteDictation>
- (instancetype)initWithDictationApi:(id<SLCLDictationApi>)dictationApi getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser deleteLocalDictationData:(id<SLCLDeleteLocalDictationData>)deleteLocalDictationData __attribute__((swift_name("init(dictationApi:getCurrentUser:deleteLocalDictationData:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(SLCLDeleteDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@property (readonly) id<SLCLDeleteLocalDictationData> deleteLocalDictationData __attribute__((swift_name("deleteLocalDictationData")));
@end;

__attribute__((swift_name("DeleteLocalDictationData")))
@protocol SLCLDeleteLocalDictationData
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLDeleteLocalDictationDataOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDeleteLocalDictationData")))
@interface SLCLDefaultDeleteLocalDictationData : SLCLBase <SLCLDeleteLocalDictationData>
- (instancetype)initWithDiscardDictationWorkingCopy:(id<SLCLDiscardDictationWorkingCopy>)discardDictationWorkingCopy dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(discardDictationWorkingCopy:dictationRepository:attachmentRepository:dictationFilesRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLDeleteLocalDictationDataOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationId:completionHandler:)")));
@end;

__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotely")))
@protocol SLCLDeleteLocalDictationIfDeletedRemotely
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(SLCLDeleteLocalDictationIfDeletedRemotelyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDeleteLocalDictationIfDeletedRemotely")))
@interface SLCLDefaultDeleteLocalDictationIfDeletedRemotely : SLCLBase <SLCLDeleteLocalDictationIfDeletedRemotely>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi deleteLocalDictationData:(id<SLCLDeleteLocalDictationData>)deleteLocalDictationData logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationApi:deleteLocalDictationData:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(SLCLDeleteLocalDictationIfDeletedRemotelyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((swift_name("DiscardDictationWorkingCopy")))
@protocol SLCLDiscardDictationWorkingCopy
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalDictationId:(NSString *)originalDictationId completionHandler:(void (^)(SLCLDiscardDictationWorkingCopyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalDictationId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDiscardDictationWorkingCopy")))
@interface SLCLDefaultDiscardDictationWorkingCopy : SLCLBase <SLCLDiscardDictationWorkingCopy>
- (instancetype)initWithGetWorkingCopyFromOriginalDictation:(id<SLCLGetWorkingCopyFromOriginalDictation>)getWorkingCopyFromOriginalDictation dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getWorkingCopyFromOriginalDictation:dictationRepository:attachmentRepository:dictationFilesRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalDictationId:(NSString *)originalDictationId completionHandler:(void (^)(SLCLDiscardDictationWorkingCopyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalDictationId:completionHandler:)")));
@end;

__attribute__((swift_name("DownloadDictationFiles")))
@protocol SLCLDownloadDictationFiles
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLDownloadDictationFilesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:onProgress:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDownloadDictationFiles")))
@interface SLCLDefaultDownloadDictationFiles : SLCLBase <SLCLDownloadDictationFiles>
- (instancetype)initWithDictationApi:(id<SLCLDictationApi>)dictationApi attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor encryptFile:(id<SLCLEncryptFile>)encryptFile logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationApi:attachmentRepository:dictationRepository:dictationFilesRepository:getCurrentUser:networkConnectivityMonitor:encryptFile:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLDownloadDictationFilesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:onProgress:completionHandler:)")));
@end;

__attribute__((swift_name("GenerateAutoIncrementingFileName")))
@protocol SLCLGenerateAutoIncrementingFileName
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeExistingNames:(NSArray<NSString *> *)existingNames existingNamesContainExtension:(BOOL)existingNamesContainExtension namePattern:(NSString *)namePattern extension:(NSString *)extension increment:(int32_t)increment completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(existingNames:existingNamesContainExtension:namePattern:extension:increment:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGenerateAutoIncrementingFileName")))
@interface SLCLDefaultGenerateAutoIncrementingFileName : SLCLBase <SLCLGenerateAutoIncrementingFileName>
- (instancetype)initWithLogger:(id<SLCLLogger>)logger __attribute__((swift_name("init(logger:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLDefaultGenerateAutoIncrementingFileNameCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeExistingNames:(NSArray<NSString *> *)existingNames existingNamesContainExtension:(BOOL)existingNamesContainExtension namePattern:(NSString *)namePattern extension:(NSString *)extension increment:(int32_t)increment completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(existingNames:existingNamesContainExtension:namePattern:extension:increment:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGenerateAutoIncrementingFileName.Companion")))
@interface SLCLDefaultGenerateAutoIncrementingFileNameCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDefaultGenerateAutoIncrementingFileNameCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKotlinRegex *SPECIAL_CHARS_REGEX __attribute__((swift_name("SPECIAL_CHARS_REGEX")));
@end;

__attribute__((swift_name("GenerateDictationFileHash")))
@protocol SLCLGenerateDictationFileHash
@required
- (NSString * _Nullable)invokeFile_:(id<SLCLFile>)file __attribute__((swift_name("invoke(file_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGenerateDictationFileHash")))
@interface SLCLDefaultGenerateDictationFileHash : SLCLBase <SLCLGenerateDictationFileHash>
- (instancetype)initWithSha256Hasher:(id<SLCLHasher>)sha256Hasher base64Encoder:(id<SLCLBase64Encoder>)base64Encoder logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(sha256Hasher:base64Encoder:logger:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)invokeFile_:(id<SLCLFile>)file __attribute__((swift_name("invoke(file_:)")));
@end;

__attribute__((swift_name("GetAvailableAssignees")))
@protocol SLCLGetAvailableAssignees
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLAssignee *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetAvailableAssignees")))
@interface SLCLDefaultGetAvailableAssignees : SLCLBase <SLCLGetAvailableAssignees>
- (instancetype)initWithAdminApi:(id<SLCLAdminApi>)adminApi getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser logger:(id<SLCLLogger>)logger appSettings:(id<SLCLAppSettings>)appSettings __attribute__((swift_name("init(adminApi:getCurrentUser:logger:appSettings:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLAssignee *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("GetOriginalDictationFromWorkingCopy")))
@protocol SLCLGetOriginalDictationFromWorkingCopy
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy completionHandler:(void (^)(SLCLGetOriginalDictationFromWorkingCopyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetOriginalDictationFromWorkingCopy")))
@interface SLCLDefaultGetOriginalDictationFromWorkingCopy : SLCLBase <SLCLGetOriginalDictationFromWorkingCopy>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy completionHandler:(void (^)(SLCLGetOriginalDictationFromWorkingCopyOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationWorkingCopy:completionHandler:)")));
@end;

__attribute__((swift_name("GetSupportedOfflineSpeechRecognitionLanguages")))
@protocol SLCLGetSupportedOfflineSpeechRecognitionLanguages
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLSpeechRecognitionLanguage *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetSupportedOfflineSpeechRecognitionLanguages")))
@interface SLCLDefaultGetSupportedOfflineSpeechRecognitionLanguages : SLCLBase <SLCLGetSupportedOfflineSpeechRecognitionLanguages>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLSpeechRecognitionLanguage *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("GetWorkingCopyFromOriginalDictation")))
@protocol SLCLGetWorkingCopyFromOriginalDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalId:(NSString *)originalId completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetWorkingCopyFromOriginalDictation")))
@interface SLCLDefaultGetWorkingCopyFromOriginalDictation : SLCLBase <SLCLGetWorkingCopyFromOriginalDictation>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalId:(NSString *)originalId completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalId:completionHandler:)")));
@end;

__attribute__((swift_name("LoadRemoteDictationsByGroup")))
@protocol SLCLLoadRemoteDictationsByGroup
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationGroup:(SLCLDictationGroup *)dictationGroup page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLLoadRemoteDictationsByGroupOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationGroup:page:pageSize:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultLoadRemoteDictationsByGroup")))
@interface SLCLDefaultLoadRemoteDictationsByGroup : SLCLBase <SLCLLoadRemoteDictationsByGroup>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationApi:(id<SLCLDictationApi>)dictationApi getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser findNewOrUpdatedDictationIds:(id<SLCLFindNewOrUpdatedDictationIds>)findNewOrUpdatedDictationIds deleteLocalDictationIfDeletedRemotely:(id<SLCLDeleteLocalDictationIfDeletedRemotely>)deleteLocalDictationIfDeletedRemotely setUploadStateOfDictation:(id<SLCLSetUploadStateOfDictation>)setUploadStateOfDictation logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationRepository:dictationApi:getCurrentUser:findNewOrUpdatedDictationIds:deleteLocalDictationIfDeletedRemotely:setUploadStateOfDictation:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationGroup:(SLCLDictationGroup *)dictationGroup page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLLoadRemoteDictationsByGroupOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationGroup:page:pageSize:completionHandler:)")));
@end;

__attribute__((swift_name("MergeWorkingCopyWithOriginal")))
@protocol SLCLMergeWorkingCopyWithOriginal
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWorkingCopy:(SLCLDictation *)workingCopy completionHandler:(void (^)(SLCLMergeWorkingCopyWithOriginalOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(workingCopy:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultMergeWorkingCopyWithOriginal")))
@interface SLCLDefaultMergeWorkingCopyWithOriginal : SLCLBase <SLCLMergeWorkingCopyWithOriginal>
- (instancetype)initWithGetOriginalDictationFromWorkingCopy:(id<SLCLGetOriginalDictationFromWorkingCopy>)getOriginalDictationFromWorkingCopy dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository logger:(id<SLCLLogger>)logger errorReporter:(id<SLCLErrorReporter>)errorReporter __attribute__((swift_name("init(getOriginalDictationFromWorkingCopy:dictationRepository:attachmentRepository:dictationFilesRepository:logger:errorReporter:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWorkingCopy:(SLCLDictation *)workingCopy completionHandler:(void (^)(SLCLMergeWorkingCopyWithOriginalOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(workingCopy:completionHandler:)")));
@end;

__attribute__((swift_name("PrepareDictationForOpen")))
@protocol SLCLPrepareDictationForOpen
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalDictation:(SLCLDictation *)originalDictation downloadDictationFilesOutput:(SLCLDownloadDictationFilesOutput *)downloadDictationFilesOutput completionHandler:(void (^)(SLCLPrepareDictationForOpenOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalDictation:downloadDictationFilesOutput:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultPrepareDictationForOpen")))
@interface SLCLDefaultPrepareDictationForOpen : SLCLBase <SLCLPrepareDictationForOpen>
- (instancetype)initWithGetDictationWorkingCopy:(id<SLCLGetWorkingCopyFromOriginalDictation>)getDictationWorkingCopy createDictationWorkingCopy:(id<SLCLCreateDictationWorkingCopy>)createDictationWorkingCopy dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser getDictationEditableStates:(id<SLCLGetDictationEditableStates>)getDictationEditableStates uploadQueueRepository:(id<SLCLUploadQueueRepository>)uploadQueueRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getDictationWorkingCopy:createDictationWorkingCopy:dictationFilesRepository:getCurrentUser:getDictationEditableStates:uploadQueueRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOriginalDictation:(SLCLDictation *)originalDictation downloadDictationFilesOutput:(SLCLDownloadDictationFilesOutput *)downloadDictationFilesOutput completionHandler:(void (^)(SLCLPrepareDictationForOpenOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(originalDictation:downloadDictationFilesOutput:completionHandler:)")));
@end;

__attribute__((swift_name("RenameDictationAudioFile")))
@protocol SLCLRenameDictationAudioFile
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation newName:(NSString *)newName completionHandler:(void (^)(SLCLRenameDictationAudioFileOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:newName:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultRenameDictationAudioFile")))
@interface SLCLDefaultRenameDictationAudioFile : SLCLBase <SLCLRenameDictationAudioFile>
- (instancetype)initWithDictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository encryptFile:(id<SLCLEncryptFile>)encryptFile decryptFile:(id<SLCLDecryptFile>)decryptFile logger:(id<SLCLLogger>)logger errorReporter:(id<SLCLErrorReporter>)errorReporter __attribute__((swift_name("init(dictationFilesRepository:dictationRepository:attachmentRepository:encryptFile:decryptFile:logger:errorReporter:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation newName:(NSString *)newName completionHandler:(void (^)(SLCLRenameDictationAudioFileOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:newName:completionHandler:)")));
@end;

__attribute__((swift_name("ResetDictationUploadQueueState")))
@protocol SLCLResetDictationUploadQueueState
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultResetDictationUploadQueueState")))
@interface SLCLDefaultResetDictationUploadQueueState : SLCLBase <SLCLResetDictationUploadQueueState>
- (instancetype)initWithUploadQueueRepository:(id<SLCLUploadQueueRepository>)uploadQueueRepository logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(uploadQueueRepository:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((swift_name("SaveAllDictationChanges")))
@protocol SLCLSaveAllDictationChanges
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation targetState:(SLCLDictationState *)targetState onUploadAttachmentsProgress:(void (^)(SLCLInt *, SLCLInt *))onUploadAttachmentsProgress onDeleteAttachmentsProgress:(void (^)(SLCLInt *, SLCLInt *))onDeleteAttachmentsProgress speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId completionHandler:(void (^)(SLCLSaveAllDictationChangesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:targetState:onUploadAttachmentsProgress:onDeleteAttachmentsProgress:speechRecognitionLanguageCode:teamId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultSaveAllDictationChanges")))
@interface SLCLDefaultSaveAllDictationChanges : SLCLBase <SLCLSaveAllDictationChanges>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor dictationApi:(id<SLCLDictationApi>)dictationApi dictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository logger:(id<SLCLLogger>)logger generateDictationFileHash:(id<SLCLGenerateDictationFileHash>)generateDictationFileHash mergeWorkingCopyWithOriginal:(id<SLCLMergeWorkingCopyWithOriginal>)mergeWorkingCopyWithOriginal getOriginalDictationFromWorkingCopy:(id<SLCLGetOriginalDictationFromWorkingCopy>)getOriginalDictationFromWorkingCopy getWorkingCopyFromOriginalDictation:(id<SLCLGetWorkingCopyFromOriginalDictation>)getWorkingCopyFromOriginalDictation createDictationWorkingCopy:(id<SLCLCreateDictationWorkingCopy>)createDictationWorkingCopy convertWorkingCopyToNewDictation:(id<SLCLConvertWorkingCopyToNewDictation>)convertWorkingCopyToNewDictation uploadNewDictation:(id<SLCLUploadNewDictation>)uploadNewDictation errorReporter:(id<SLCLErrorReporter>)errorReporter decryptFile:(id<SLCLDecryptFile>)decryptFile __attribute__((swift_name("init(getCurrentUser:networkConnectivityMonitor:dictationApi:dictationRepository:dictationFilesRepository:attachmentRepository:logger:generateDictationFileHash:mergeWorkingCopyWithOriginal:getOriginalDictationFromWorkingCopy:getWorkingCopyFromOriginalDictation:createDictationWorkingCopy:convertWorkingCopyToNewDictation:uploadNewDictation:errorReporter:decryptFile:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation targetState:(SLCLDictationState *)targetState onUploadAttachmentsProgress:(void (^)(SLCLInt *, SLCLInt *))onUploadAttachmentsProgress onDeleteAttachmentsProgress:(void (^)(SLCLInt *, SLCLInt *))onDeleteAttachmentsProgress speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId completionHandler:(void (^)(SLCLSaveAllDictationChangesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:targetState:onUploadAttachmentsProgress:onDeleteAttachmentsProgress:speechRecognitionLanguageCode:teamId:completionHandler:)")));
@end;

__attribute__((swift_name("SetUploadStateOfDictation")))
@protocol SLCLSetUploadStateOfDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictations:(NSArray<SLCLDictation *> *)dictations completionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictations:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultSetUploadStateOfDictation")))
@interface SLCLDefaultSetUploadStateOfDictation : SLCLBase <SLCLSetUploadStateOfDictation>
- (instancetype)initWithUploadQueueRepository:(id<SLCLUploadQueueRepository>)uploadQueueRepository __attribute__((swift_name("init(uploadQueueRepository:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictations:(NSArray<SLCLDictation *> *)dictations completionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictations:completionHandler:)")));
@end;

__attribute__((swift_name("StartUploadingNextAvailableDictation")))
@protocol SLCLStartUploadingNextAvailableDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultStartUploadingNextAvailableDictation")))
@interface SLCLDefaultStartUploadingNextAvailableDictation : SLCLBase <SLCLStartUploadingNextAvailableDictation>
- (instancetype)initWithUploadQueueRepository:(id<SLCLUploadQueueRepository>)uploadQueueRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository saveAllDictationChanges:(id<SLCLSaveAllDictationChanges>)saveAllDictationChanges addToUploadQueue:(id<SLCLAddToUploadQueue>)addToUploadQueue getWorkingCopyFromOriginalDictation:(id<SLCLGetWorkingCopyFromOriginalDictation>)getWorkingCopyFromOriginalDictation logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(uploadQueueRepository:dictationRepository:saveAllDictationChanges:addToUploadQueue:getWorkingCopyFromOriginalDictation:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@property (readonly) id<SLCLAddToUploadQueue> addToUploadQueue __attribute__((swift_name("addToUploadQueue")));
@property (readonly) id<SLCLDictationRepository> dictationRepository __attribute__((swift_name("dictationRepository")));
@property (readonly) id<SLCLGetWorkingCopyFromOriginalDictation> getWorkingCopyFromOriginalDictation __attribute__((swift_name("getWorkingCopyFromOriginalDictation")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property (readonly) id<SLCLSaveAllDictationChanges> saveAllDictationChanges __attribute__((swift_name("saveAllDictationChanges")));
@property (readonly) id<SLCLUploadQueueRepository> uploadQueueRepository __attribute__((swift_name("uploadQueueRepository")));
@end;

__attribute__((swift_name("DeleteDictationOutput")))
@interface SLCLDeleteDictationOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteDictationOutput.FileSystemError")))
@interface SLCLDeleteDictationOutputFileSystemError : SLCLDeleteDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteDictationOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteDictationOutput.NetworkError")))
@interface SLCLDeleteDictationOutputNetworkError : SLCLDeleteDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteDictationOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteDictationOutput.ServerError")))
@interface SLCLDeleteDictationOutputServerError : SLCLDeleteDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteDictationOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteDictationOutput.Success")))
@interface SLCLDeleteDictationOutputSuccess : SLCLDeleteDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteDictationOutputSuccess *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteDictationOutput.UnexpectedError")))
@interface SLCLDeleteDictationOutputUnexpectedError : SLCLDeleteDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteDictationOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteDictationOutput.UserNotAuthenticated")))
@interface SLCLDeleteDictationOutputUserNotAuthenticated : SLCLDeleteDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteDictationOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("DeleteLocalDictationDataOutput")))
@interface SLCLDeleteLocalDictationDataOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationDataOutput.FileSystemError")))
@interface SLCLDeleteLocalDictationDataOutputFileSystemError : SLCLDeleteLocalDictationDataOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationDataOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationDataOutput.Success")))
@interface SLCLDeleteLocalDictationDataOutputSuccess : SLCLDeleteLocalDictationDataOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationDataOutputSuccess *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.Deleted")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputDeleted : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)deleted __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputDeleted *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.DeletionNotRequired")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputDeletionNotRequired : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)deletionNotRequired __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputDeletionNotRequired *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.FileSystemError")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputFileSystemError : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.NetworkError")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputNetworkError : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.ServerError")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputServerError : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.UnexpectedError")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputUnexpectedError : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteLocalDictationIfDeletedRemotelyOutput.UserNotAuthenticated")))
@interface SLCLDeleteLocalDictationIfDeletedRemotelyOutputUserNotAuthenticated : SLCLDeleteLocalDictationIfDeletedRemotelyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDeleteLocalDictationIfDeletedRemotelyOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("DiscardDictationWorkingCopyOutput")))
@interface SLCLDiscardDictationWorkingCopyOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DiscardDictationWorkingCopyOutput.FileSystemError")))
@interface SLCLDiscardDictationWorkingCopyOutputFileSystemError : SLCLDiscardDictationWorkingCopyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDiscardDictationWorkingCopyOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DiscardDictationWorkingCopyOutput.Success")))
@interface SLCLDiscardDictationWorkingCopyOutputSuccess : SLCLDiscardDictationWorkingCopyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDiscardDictationWorkingCopyOutputSuccess *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("DownloadDictationFilesOutput")))
@interface SLCLDownloadDictationFilesOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DownloadDictationFilesOutput.FileSystemError")))
@interface SLCLDownloadDictationFilesOutputFileSystemError : SLCLDownloadDictationFilesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDownloadDictationFilesOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DownloadDictationFilesOutput.NetworkError")))
@interface SLCLDownloadDictationFilesOutputNetworkError : SLCLDownloadDictationFilesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)networkError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDownloadDictationFilesOutputNetworkError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DownloadDictationFilesOutput.ServerError")))
@interface SLCLDownloadDictationFilesOutputServerError : SLCLDownloadDictationFilesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serverError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDownloadDictationFilesOutputServerError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DownloadDictationFilesOutput.Success")))
@interface SLCLDownloadDictationFilesOutputSuccess : SLCLDownloadDictationFilesOutput
- (instancetype)initWithDictation:(SLCLDictation *)dictation __attribute__((swift_name("init(dictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDownloadDictationFilesOutputSuccess *)doCopyDictation:(SLCLDictation *)dictation __attribute__((swift_name("doCopy(dictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictation __attribute__((swift_name("dictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DownloadDictationFilesOutput.UnexpectedError")))
@interface SLCLDownloadDictationFilesOutputUnexpectedError : SLCLDownloadDictationFilesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDownloadDictationFilesOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DownloadDictationFilesOutput.UserNotAuthenticated")))
@interface SLCLDownloadDictationFilesOutputUserNotAuthenticated : SLCLDownloadDictationFilesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDownloadDictationFilesOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("FindNewOrUpdatedDictationIds")))
@protocol SLCLFindNewOrUpdatedDictationIds
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOld:(NSArray<SLCLDictation *> *)old new:(NSArray<SLCLDictation *> *)new_ completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(old:new:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FindNewOrUpdatedDictationIdsForStates")))
@interface SLCLFindNewOrUpdatedDictationIdsForStates : SLCLBase <SLCLFindNewOrUpdatedDictationIds>
- (instancetype)initWithStates:(NSSet<SLCLDictationState *> *)states __attribute__((swift_name("init(states:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeOld:(NSArray<SLCLDictation *> *)old new:(NSArray<SLCLDictation *> *)new_ completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(old:new:completionHandler:)")));
@end;

__attribute__((swift_name("GetAttachmentFiles")))
@protocol SLCLGetAttachmentFiles
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSArray<SLCLAttachmentFile *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((swift_name("GetDictationAudioFileNamePattern")))
@protocol SLCLGetDictationAudioFileNamePattern
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetDictationAudioFileNamePatternBasedOnEmail")))
@interface SLCLGetDictationAudioFileNamePatternBasedOnEmail : SLCLBase <SLCLGetDictationAudioFileNamePattern>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeUser:(SLCLUser *)user completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(user:completionHandler:)")));
@end;

__attribute__((swift_name("GetDictationById")))
@protocol SLCLGetDictationById
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeId:(NSString *)id completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(id:completionHandler:)")));
@end;

__attribute__((swift_name("GetDictationEditableStates")))
@protocol SLCLGetDictationEditableStates
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSSet<SLCLDictationState *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("GetDictationListNewItemActions")))
@protocol SLCLGetDictationListNewItemActions
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLDictationListNewItemAction *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetLocalAttachmentFiles")))
@interface SLCLGetLocalAttachmentFiles : SLCLBase <SLCLGetAttachmentFiles>
- (instancetype)initWithDictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository supportedTypes:(NSSet<NSString *> *)supportedTypes decryptAttachments:(id<SLCLDecryptAttachments>)decryptAttachments supportedSubtypes:(NSSet<NSString *> *)supportedSubtypes __attribute__((swift_name("init(dictationFilesRepository:attachmentRepository:supportedTypes:decryptAttachments:supportedSubtypes:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSArray<SLCLAttachmentFile *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetLocalDictationById")))
@interface SLCLGetLocalDictationById : SLCLBase <SLCLGetDictationById>
- (instancetype)initWithDictationRepository:(id<SLCLDictationRepository>)dictationRepository __attribute__((swift_name("init(dictationRepository:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeId:(NSString *)id completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(id:completionHandler:)")));
@end;

__attribute__((swift_name("GetOriginalDictationFromWorkingCopyOutput")))
@interface SLCLGetOriginalDictationFromWorkingCopyOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetOriginalDictationFromWorkingCopyOutput.Success")))
@interface SLCLGetOriginalDictationFromWorkingCopyOutputSuccess : SLCLGetOriginalDictationFromWorkingCopyOutput
- (instancetype)initWithOriginal:(SLCLDictation *)original __attribute__((swift_name("init(original:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLGetOriginalDictationFromWorkingCopyOutputSuccess *)doCopyOriginal:(SLCLDictation *)original __attribute__((swift_name("doCopy(original:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *original __attribute__((swift_name("original")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetOriginalDictationFromWorkingCopyOutput.UnexpectedError")))
@interface SLCLGetOriginalDictationFromWorkingCopyOutputUnexpectedError : SLCLGetOriginalDictationFromWorkingCopyOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLGetOriginalDictationFromWorkingCopyOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("GetRememberedAssigneeId")))
@protocol SLCLGetRememberedAssigneeId
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSpeechExecEnterpriseDictationEditableStates")))
@interface SLCLGetSpeechExecEnterpriseDictationEditableStates : SLCLBase <SLCLGetDictationEditableStates>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSSet<SLCLDictationState *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSpeechLiveEditableDictationStates")))
@interface SLCLGetSpeechLiveEditableDictationStates : SLCLBase <SLCLGetDictationEditableStates>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSSet<SLCLDictationState *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetUserSpecificDictationListNewItemActions")))
@interface SLCLGetUserSpecificDictationListNewItemActions : SLCLBase <SLCLGetDictationListNewItemActions>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationApi:(id<SLCLDictationApi>)dictationApi checkIfSpeechToTextAvailable:(id<SLCLCheckIfSpeechToTextAvailable>)checkIfSpeechToTextAvailable logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationApi:checkIfSpeechToTextAvailable:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLDictationListNewItemAction *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("LoadRemoteDictationsByGroupOutput")))
@interface SLCLLoadRemoteDictationsByGroupOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadRemoteDictationsByGroupOutput.NetworkError")))
@interface SLCLLoadRemoteDictationsByGroupOutputNetworkError : SLCLLoadRemoteDictationsByGroupOutput
- (instancetype)initWithDictations:(NSArray<SLCLDictation *> *)dictations user:(SLCLUser *)user __attribute__((swift_name("init(dictations:user:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLDictation *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUser *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoadRemoteDictationsByGroupOutputNetworkError *)doCopyDictations:(NSArray<SLCLDictation *> *)dictations user:(SLCLUser *)user __attribute__((swift_name("doCopy(dictations:user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLDictation *> *dictations __attribute__((swift_name("dictations")));
@property (readonly) SLCLUser *user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadRemoteDictationsByGroupOutput.ServerError")))
@interface SLCLLoadRemoteDictationsByGroupOutputServerError : SLCLLoadRemoteDictationsByGroupOutput
- (instancetype)initWithDictations:(NSArray<SLCLDictation *> *)dictations user:(SLCLUser *)user __attribute__((swift_name("init(dictations:user:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLDictation *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUser *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoadRemoteDictationsByGroupOutputServerError *)doCopyDictations:(NSArray<SLCLDictation *> *)dictations user:(SLCLUser *)user __attribute__((swift_name("doCopy(dictations:user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLDictation *> *dictations __attribute__((swift_name("dictations")));
@property (readonly) SLCLUser *user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadRemoteDictationsByGroupOutput.Success")))
@interface SLCLLoadRemoteDictationsByGroupOutputSuccess : SLCLLoadRemoteDictationsByGroupOutput
- (instancetype)initWithDictations:(NSArray<SLCLDictation *> *)dictations changedDictationIds:(NSArray<NSString *> *)changedDictationIds user:(SLCLUser *)user __attribute__((swift_name("init(dictations:changedDictationIds:user:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLDictation *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<NSString *> *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUser *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoadRemoteDictationsByGroupOutputSuccess *)doCopyDictations:(NSArray<SLCLDictation *> *)dictations changedDictationIds:(NSArray<NSString *> *)changedDictationIds user:(SLCLUser *)user __attribute__((swift_name("doCopy(dictations:changedDictationIds:user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> *changedDictationIds __attribute__((swift_name("changedDictationIds")));
@property (readonly) NSArray<SLCLDictation *> *dictations __attribute__((swift_name("dictations")));
@property (readonly) SLCLUser *user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadRemoteDictationsByGroupOutput.UnexpectedError")))
@interface SLCLLoadRemoteDictationsByGroupOutputUnexpectedError : SLCLLoadRemoteDictationsByGroupOutput
- (instancetype)initWithDictations:(NSArray<SLCLDictation *> *)dictations user:(SLCLUser *)user __attribute__((swift_name("init(dictations:user:)"))) __attribute__((objc_designated_initializer));
- (NSArray<SLCLDictation *> *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUser *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLoadRemoteDictationsByGroupOutputUnexpectedError *)doCopyDictations:(NSArray<SLCLDictation *> *)dictations user:(SLCLUser *)user __attribute__((swift_name("doCopy(dictations:user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SLCLDictation *> *dictations __attribute__((swift_name("dictations")));
@property (readonly) SLCLUser *user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadRemoteDictationsByGroupOutput.UserNotAuthenticated")))
@interface SLCLLoadRemoteDictationsByGroupOutputUserNotAuthenticated : SLCLLoadRemoteDictationsByGroupOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLLoadRemoteDictationsByGroupOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("MergeWorkingCopyWithOriginalOutput")))
@interface SLCLMergeWorkingCopyWithOriginalOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MergeWorkingCopyWithOriginalOutput.FileSystemError")))
@interface SLCLMergeWorkingCopyWithOriginalOutputFileSystemError : SLCLMergeWorkingCopyWithOriginalOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLMergeWorkingCopyWithOriginalOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MergeWorkingCopyWithOriginalOutput.Success")))
@interface SLCLMergeWorkingCopyWithOriginalOutputSuccess : SLCLMergeWorkingCopyWithOriginalOutput
- (instancetype)initWithMergedDictation:(SLCLDictation *)mergedDictation __attribute__((swift_name("init(mergedDictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLMergeWorkingCopyWithOriginalOutputSuccess *)doCopyMergedDictation:(SLCLDictation *)mergedDictation __attribute__((swift_name("doCopy(mergedDictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *mergedDictation __attribute__((swift_name("mergedDictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MergeWorkingCopyWithOriginalOutput.UnexpectedError")))
@interface SLCLMergeWorkingCopyWithOriginalOutputUnexpectedError : SLCLMergeWorkingCopyWithOriginalOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLMergeWorkingCopyWithOriginalOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("PrepareDictationForOpenOutput")))
@interface SLCLPrepareDictationForOpenOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.DictationUploading")))
@interface SLCLPrepareDictationForOpenOutputDictationUploading : SLCLPrepareDictationForOpenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dictationUploading __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPrepareDictationForOpenOutputDictationUploading *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.FileSystemError")))
@interface SLCLPrepareDictationForOpenOutputFileSystemError : SLCLPrepareDictationForOpenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPrepareDictationForOpenOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.ReadOnlyDueToDownloadError")))
@interface SLCLPrepareDictationForOpenOutputReadOnlyDueToDownloadError : SLCLPrepareDictationForOpenOutput
- (instancetype)initWithOriginalDictation:(SLCLDictation *)originalDictation __attribute__((swift_name("init(originalDictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLPrepareDictationForOpenOutputReadOnlyDueToDownloadError *)doCopyOriginalDictation:(SLCLDictation *)originalDictation __attribute__((swift_name("doCopy(originalDictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *originalDictation __attribute__((swift_name("originalDictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.ReadOnlyDueToRemoteLocking")))
@interface SLCLPrepareDictationForOpenOutputReadOnlyDueToRemoteLocking : SLCLPrepareDictationForOpenOutput
- (instancetype)initWithOriginalDictation:(SLCLDictation *)originalDictation __attribute__((swift_name("init(originalDictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLPrepareDictationForOpenOutputReadOnlyDueToRemoteLocking *)doCopyOriginalDictation:(SLCLDictation *)originalDictation __attribute__((swift_name("doCopy(originalDictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *originalDictation __attribute__((swift_name("originalDictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.ReadWrite")))
@interface SLCLPrepareDictationForOpenOutputReadWrite : SLCLPrepareDictationForOpenOutput
- (instancetype)initWithOriginalDictation:(SLCLDictation *)originalDictation dictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("init(originalDictation:dictationWorkingCopy:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictation *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLPrepareDictationForOpenOutputReadWrite *)doCopyOriginalDictation:(SLCLDictation *)originalDictation dictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("doCopy(originalDictation:dictationWorkingCopy:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictationWorkingCopy __attribute__((swift_name("dictationWorkingCopy")));
@property (readonly) SLCLDictation *originalDictation __attribute__((swift_name("originalDictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.RecoveredWorkingCopy")))
@interface SLCLPrepareDictationForOpenOutputRecoveredWorkingCopy : SLCLPrepareDictationForOpenOutput
- (instancetype)initWithOriginalDictation:(SLCLDictation *)originalDictation dictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("init(originalDictation:dictationWorkingCopy:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictation *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLPrepareDictationForOpenOutputRecoveredWorkingCopy *)doCopyOriginalDictation:(SLCLDictation *)originalDictation dictationWorkingCopy:(SLCLDictation *)dictationWorkingCopy __attribute__((swift_name("doCopy(originalDictation:dictationWorkingCopy:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictationWorkingCopy __attribute__((swift_name("dictationWorkingCopy")));
@property (readonly) SLCLDictation *originalDictation __attribute__((swift_name("originalDictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.Unavailable")))
@interface SLCLPrepareDictationForOpenOutputUnavailable : SLCLPrepareDictationForOpenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unavailable __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPrepareDictationForOpenOutputUnavailable *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.UnexpectedError")))
@interface SLCLPrepareDictationForOpenOutputUnexpectedError : SLCLPrepareDictationForOpenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPrepareDictationForOpenOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrepareDictationForOpenOutput.UserNotAuthenticated")))
@interface SLCLPrepareDictationForOpenOutputUserNotAuthenticated : SLCLPrepareDictationForOpenOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLPrepareDictationForOpenOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("RenameDictationAudioFileOutput")))
@interface SLCLRenameDictationAudioFileOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenameDictationAudioFileOutput.FileSystemError")))
@interface SLCLRenameDictationAudioFileOutputFileSystemError : SLCLRenameDictationAudioFileOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRenameDictationAudioFileOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenameDictationAudioFileOutput.Success")))
@interface SLCLRenameDictationAudioFileOutputSuccess : SLCLRenameDictationAudioFileOutput
- (instancetype)initWithUpdatedDictation:(SLCLDictation *)updatedDictation updatedAudioAttachmentFile:(SLCLAttachmentFile *)updatedAudioAttachmentFile updatedTranscriptionAttachmentFile:(SLCLAttachmentFile * _Nullable)updatedTranscriptionAttachmentFile __attribute__((swift_name("init(updatedDictation:updatedAudioAttachmentFile:updatedTranscriptionAttachmentFile:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAttachmentFile *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAttachmentFile * _Nullable)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLRenameDictationAudioFileOutputSuccess *)doCopyUpdatedDictation:(SLCLDictation *)updatedDictation updatedAudioAttachmentFile:(SLCLAttachmentFile *)updatedAudioAttachmentFile updatedTranscriptionAttachmentFile:(SLCLAttachmentFile * _Nullable)updatedTranscriptionAttachmentFile __attribute__((swift_name("doCopy(updatedDictation:updatedAudioAttachmentFile:updatedTranscriptionAttachmentFile:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLAttachmentFile *updatedAudioAttachmentFile __attribute__((swift_name("updatedAudioAttachmentFile")));
@property (readonly) SLCLDictation *updatedDictation __attribute__((swift_name("updatedDictation")));
@property (readonly) SLCLAttachmentFile * _Nullable updatedTranscriptionAttachmentFile __attribute__((swift_name("updatedTranscriptionAttachmentFile")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenameDictationAudioFileOutput.UnexpectedError")))
@interface SLCLRenameDictationAudioFileOutputUnexpectedError : SLCLRenameDictationAudioFileOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLRenameDictationAudioFileOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("SaveAllDictationChangesOutput")))
@interface SLCLSaveAllDictationChangesOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.AssigningToTranscriptionistFailed")))
@interface SLCLSaveAllDictationChangesOutputAssigningToTranscriptionistFailed : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)assigningToTranscriptionistFailed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputAssigningToTranscriptionistFailed *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.ChangesSavedToNewDictation")))
@interface SLCLSaveAllDictationChangesOutputChangesSavedToNewDictation : SLCLSaveAllDictationChangesOutput
- (instancetype)initWithDictationCopy:(SLCLDictation *)dictationCopy __attribute__((swift_name("init(dictationCopy:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSaveAllDictationChangesOutputChangesSavedToNewDictation *)doCopyDictationCopy:(SLCLDictation *)dictationCopy __attribute__((swift_name("doCopy(dictationCopy:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictationCopy __attribute__((swift_name("dictationCopy")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.FileSystemError")))
@interface SLCLSaveAllDictationChangesOutputFileSystemError : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.SavedAndUploaded")))
@interface SLCLSaveAllDictationChangesOutputSavedAndUploaded : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)savedAndUploaded __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputSavedAndUploaded *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.SavedLocally")))
@interface SLCLSaveAllDictationChangesOutputSavedLocally : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)savedLocally __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputSavedLocally *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.SendingToSpeechRecognitionFailed")))
@interface SLCLSaveAllDictationChangesOutputSendingToSpeechRecognitionFailed : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sendingToSpeechRecognitionFailed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputSendingToSpeechRecognitionFailed *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.SendingToTranscriptionServiceFailed")))
@interface SLCLSaveAllDictationChangesOutputSendingToTranscriptionServiceFailed : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sendingToTranscriptionServiceFailed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputSendingToTranscriptionServiceFailed *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaveAllDictationChangesOutput.UnexpectedError")))
@interface SLCLSaveAllDictationChangesOutputUnexpectedError : SLCLSaveAllDictationChangesOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLSaveAllDictationChangesOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("SaveAssigneeIdToRemember")))
@protocol SLCLSaveAssigneeIdToRemember
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeAssigneeId:(NSString *)assigneeId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(assigneeId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseAddOfflineDictationsToQueue")))
@interface SLCLSpeechExecEnterpriseAddOfflineDictationsToQueue : SLCLBase <SLCLAddOfflineDictationsToQueue>
- (instancetype)initWithStartUploadingNextAvailableDictation:(id<SLCLStartUploadingNextAvailableDictation>)startUploadingNextAvailableDictation __attribute__((swift_name("init(startUploadingNextAvailableDictation:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseDownloadDictationFiles")))
@interface SLCLSpeechExecEnterpriseDownloadDictationFiles : SLCLBase <SLCLDownloadDictationFiles>
- (instancetype)initWithDictationApi:(SLCLSpeechExecEnterpriseDictationApi *)dictationApi attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor encryptFile:(id<SLCLEncryptFile>)encryptFile deleteAttachment:(id<SLCLDeleteAttachment>)deleteAttachment logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationApi:attachmentRepository:dictationRepository:dictationFilesRepository:getCurrentUser:networkConnectivityMonitor:encryptFile:deleteAttachment:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation onProgress:(void (^)(SLCLLong *, SLCLLong *))onProgress completionHandler:(void (^)(SLCLDownloadDictationFilesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:onProgress:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseGetAvailableAssignees")))
@interface SLCLSpeechExecEnterpriseGetAvailableAssignees : SLCLBase <SLCLGetAvailableAssignees>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLAssignee *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseGetDictationListNewItemActions")))
@interface SLCLSpeechExecEnterpriseGetDictationListNewItemActions : SLCLBase <SLCLGetDictationListNewItemActions>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLDictationListNewItemAction *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseGetSupportedOfflineSpeechRecognitionLanguages")))
@interface SLCLSpeechExecEnterpriseGetSupportedOfflineSpeechRecognitionLanguages : SLCLBase <SLCLGetSupportedOfflineSpeechRecognitionLanguages>
- (instancetype)initWithDictationApi:(SLCLSpeechExecEnterpriseDictationApi *)dictationApi getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser getSupportedOfflineSpeechRecognitionLanguages:(SLCLDefaultGetSupportedOfflineSpeechRecognitionLanguages *)getSupportedOfflineSpeechRecognitionLanguages __attribute__((swift_name("init(dictationApi:getCurrentUser:getSupportedOfflineSpeechRecognitionLanguages:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<SLCLSpeechRecognitionLanguage *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseSaveAllDictationChanges")))
@interface SLCLSpeechExecEnterpriseSaveAllDictationChanges : SLCLBase <SLCLSaveAllDictationChanges>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor getOriginalDictationFromWorkingCopy:(id<SLCLGetOriginalDictationFromWorkingCopy>)getOriginalDictationFromWorkingCopy getWorkingCopyFromOriginalDictation:(id<SLCLGetWorkingCopyFromOriginalDictation>)getWorkingCopyFromOriginalDictation dictationRepository:(id<SLCLDictationRepository>)dictationRepository errorReporter:(id<SLCLErrorReporter>)errorReporter mergeWorkingCopyWithOriginal:(id<SLCLMergeWorkingCopyWithOriginal>)mergeWorkingCopyWithOriginal uploadNewDictation:(id<SLCLUploadNewDictation>)uploadNewDictation dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository createDictationWorkingCopy:(id<SLCLCreateDictationWorkingCopy>)createDictationWorkingCopy convertWorkingCopyToNewDictation:(id<SLCLConvertWorkingCopyToNewDictation>)convertWorkingCopyToNewDictation timeProvider:(id<SLCLTimeProvider>)timeProvider logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:networkConnectivityMonitor:getOriginalDictationFromWorkingCopy:getWorkingCopyFromOriginalDictation:dictationRepository:errorReporter:mergeWorkingCopyWithOriginal:uploadNewDictation:dictationFilesRepository:createDictationWorkingCopy:convertWorkingCopyToNewDictation:timeProvider:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation targetState:(SLCLDictationState *)targetState onUploadAttachmentsProgress:(void (^)(SLCLInt *, SLCLInt *))onUploadAttachmentsProgress onDeleteAttachmentsProgress:(void (^)(SLCLInt *, SLCLInt *))onDeleteAttachmentsProgress speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId completionHandler:(void (^)(SLCLSaveAllDictationChangesOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:targetState:onUploadAttachmentsProgress:onDeleteAttachmentsProgress:speechRecognitionLanguageCode:teamId:completionHandler:)")));
@end;

__attribute__((swift_name("UploadNewDictation")))
@protocol SLCLUploadNewDictation
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation maxTries:(int32_t)maxTries languageCode:(NSString * _Nullable)languageCode numberOfSpeakers:(SLCLInt * _Nullable)numberOfSpeakers completionHandler:(void (^)(SLCLUploadNewDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:maxTries:languageCode:numberOfSpeakers:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseUploadNewDictation")))
@interface SLCLSpeechExecEnterpriseUploadNewDictation : SLCLBase <SLCLUploadNewDictation>
- (instancetype)initWithDictationApi:(SLCLSpeechExecEnterpriseDictationApi *)dictationApi dictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser decryptFile:(id<SLCLDecryptFile>)decryptFile getDictationAudioFileNamePattern:(id<SLCLGetDictationAudioFileNamePattern>)getDictationAudioFileNamePattern generateAutoIncrementingFileName:(id<SLCLGenerateAutoIncrementingFileName>)generateAutoIncrementingFileName logger:(id<SLCLLogger>)logger renameDictationAudioFile:(id<SLCLRenameDictationAudioFile>)renameDictationAudioFile errorReporter:(id<SLCLErrorReporter>)errorReporter __attribute__((swift_name("init(dictationApi:dictationRepository:dictationFilesRepository:getCurrentUser:decryptFile:getDictationAudioFileNamePattern:generateAutoIncrementingFileName:logger:renameDictationAudioFile:errorReporter:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation maxTries:(int32_t)maxTries languageCode:(NSString * _Nullable)languageCode numberOfSpeakers:(SLCLInt * _Nullable)numberOfSpeakers completionHandler:(void (^)(SLCLUploadNewDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:maxTries:languageCode:numberOfSpeakers:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseUploadNewDictation.UploadDictationErrors")))
@interface SLCLSpeechExecEnterpriseUploadNewDictationUploadDictationErrors : SLCLKotlinEnum<SLCLSpeechExecEnterpriseUploadNewDictationUploadDictationErrors *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLSpeechExecEnterpriseUploadNewDictationUploadDictationErrors *dictationFileAlreadyExists __attribute__((swift_name("dictationFileAlreadyExists")));
@property (class, readonly) SLCLSpeechExecEnterpriseUploadNewDictationUploadDictationErrors *cannotCreateFinalDirectory __attribute__((swift_name("cannotCreateFinalDirectory")));
+ (SLCLKotlinArray<SLCLSpeechExecEnterpriseUploadNewDictationUploadDictationErrors *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *errorName __attribute__((swift_name("errorName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecLoadRemoteDictationsByGroup")))
@interface SLCLSpeechExecLoadRemoteDictationsByGroup : SLCLBase <SLCLLoadRemoteDictationsByGroup>
- (instancetype)initWithGetCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser dictationRepository:(id<SLCLDictationRepository>)dictationRepository dictationApi:(SLCLSpeechExecEnterpriseDictationApi *)dictationApi findNewOrUpdatedDictationIds:(id<SLCLFindNewOrUpdatedDictationIds>)findNewOrUpdatedDictationIds setUploadStateOfDictation:(id<SLCLSetUploadStateOfDictation>)setUploadStateOfDictation logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(getCurrentUser:dictationRepository:dictationApi:findNewOrUpdatedDictationIds:setUploadStateOfDictation:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictationGroup:(SLCLDictationGroup *)dictationGroup page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(SLCLLoadRemoteDictationsByGroupOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictationGroup:page:pageSize:completionHandler:)")));
@end;

__attribute__((swift_name("UploadNewDictationOutput")))
@interface SLCLUploadNewDictationOutput : SLCLBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadNewDictationOutput.ApiError")))
@interface SLCLUploadNewDictationOutputApiError : SLCLUploadNewDictationOutput
- (instancetype)initWithError:(SLCLApiError *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (SLCLApiError *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUploadNewDictationOutputApiError *)doCopyError:(SLCLApiError *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLApiError *error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadNewDictationOutput.FileSystemError")))
@interface SLCLUploadNewDictationOutputFileSystemError : SLCLUploadNewDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fileSystemError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUploadNewDictationOutputFileSystemError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadNewDictationOutput.Success")))
@interface SLCLUploadNewDictationOutputSuccess : SLCLUploadNewDictationOutput
- (instancetype)initWithDictation:(SLCLDictation *)dictation __attribute__((swift_name("init(dictation:)"))) __attribute__((objc_designated_initializer));
- (SLCLDictation *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLUploadNewDictationOutputSuccess *)doCopyDictation:(SLCLDictation *)dictation __attribute__((swift_name("doCopy(dictation:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictation *dictation __attribute__((swift_name("dictation")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadNewDictationOutput.UnexpectedError")))
@interface SLCLUploadNewDictationOutputUnexpectedError : SLCLUploadNewDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unexpectedError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUploadNewDictationOutputUnexpectedError *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadNewDictationOutput.UserNotAuthenticated")))
@interface SLCLUploadNewDictationOutputUserNotAuthenticated : SLCLUploadNewDictationOutput
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userNotAuthenticated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUploadNewDictationOutputUserNotAuthenticated *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadNewDictationWithRenameOnConflict")))
@interface SLCLUploadNewDictationWithRenameOnConflict : SLCLBase <SLCLUploadNewDictation>
- (instancetype)initWithDictationApi:(id<SLCLDictationApi>)dictationApi dictationRepository:(id<SLCLDictationRepository>)dictationRepository attachmentRepository:(id<SLCLAttachmentRepository>)attachmentRepository dictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository getCurrentUser:(id<SLCLGetCurrentUser>)getCurrentUser decryptFile:(id<SLCLDecryptFile>)decryptFile getDictationAudioFileNamePattern:(id<SLCLGetDictationAudioFileNamePattern>)getDictationAudioFileNamePattern generateAutoIncrementingFileName:(id<SLCLGenerateAutoIncrementingFileName>)generateAutoIncrementingFileName logger:(id<SLCLLogger>)logger renameDictationAudioFile:(id<SLCLRenameDictationAudioFile>)renameDictationAudioFile errorReporter:(id<SLCLErrorReporter>)errorReporter __attribute__((swift_name("init(dictationApi:dictationRepository:attachmentRepository:dictationFilesRepository:getCurrentUser:decryptFile:getDictationAudioFileNamePattern:generateAutoIncrementingFileName:logger:renameDictationAudioFile:errorReporter:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation maxTries:(int32_t)maxTries languageCode:(NSString * _Nullable)languageCode numberOfSpeakers:(SLCLInt * _Nullable)numberOfSpeakers completionHandler:(void (^)(SLCLUploadNewDictationOutput * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:maxTries:languageCode:numberOfSpeakers:completionHandler:)")));
@end;

__attribute__((swift_name("AttachmentRepository")))
@protocol SLCLAttachmentRepository
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentAttachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLAttachment * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachment(attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsDictationId:(NSString *)dictationId completionHandler:(void (^)(NSArray<SLCLAttachment *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachments(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsOrderedByLastModifiedDictationId:(NSString *)dictationId completionHandler:(void (^)(NSArray<SLCLAttachment *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachmentsOrderedByLastModified(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getWorkingCopyOriginalId:(NSString *)originalId completionHandler:(void (^)(SLCLAttachment * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getWorkingCopy(originalId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeAttachmentAttachmentId:(NSString *)attachmentId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeAttachment(attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddAttachmentAttachment:(SLCLAttachment *)attachment completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddAttachment(attachment:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddAttachmentsAttachments:(NSArray<SLCLAttachment *> *)attachments completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddAttachments(attachments:completionHandler:)")));
@end;

__attribute__((swift_name("DictationFilesRepository")))
@protocol SLCLDictationFilesRepository
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllDictationsDirectoryWithCompletionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllDictationsDirectory(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentFileAttachment:(SLCLAttachment *)attachment completionHandler:(void (^)(id<SLCLFile> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachmentFile(attachment:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAudioFileDictation:(SLCLDictation *)dictation completionHandler:(void (^)(id<SLCLFile> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAudioFile(dictation:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationFilesDirectoryDictationId:(NSString *)dictationId completionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationFilesDirectory(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationTempDirectoryDictationId:(NSString *)dictationId completionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationTempDirectory(dictationId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultDictationFilesRepository")))
@interface SLCLDefaultDictationFilesRepository : SLCLBase <SLCLDictationFilesRepository>
- (instancetype)initWithAppFilesDirectory:(id<SLCLDirectory>)appFilesDirectory __attribute__((swift_name("init(appFilesDirectory:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllDictationsDirectoryWithCompletionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllDictationsDirectory(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentFileAttachment:(SLCLAttachment *)attachment completionHandler:(void (^)(id<SLCLFile> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachmentFile(attachment:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAudioFileDictation:(SLCLDictation *)dictation completionHandler:(void (^)(id<SLCLFile> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAudioFile(dictation:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationFilesDirectoryDictationId:(NSString *)dictationId completionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationFilesDirectory(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationTempDirectoryDictationId:(NSString *)dictationId completionHandler:(void (^)(id<SLCLDirectory> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationTempDirectory(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTempAudioFileDictation:(SLCLDictation *)dictation completionHandler:(void (^)(id<SLCLFile> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getTempAudioFile(dictation:completionHandler:)")));
@end;

__attribute__((swift_name("DictationRepository")))
@protocol SLCLDictationRepository
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAudioFileNamesUserId:(NSString *)userId completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAudioFileNames(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationId:(NSString *)id completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictation(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationWorkingCopyOriginalId:(NSString *)originalId completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationWorkingCopy(originalId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsWithCompletionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsUserId:(NSString *)userId completionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsOrderedByLastModifiedUserId:(NSString *)userId states:(NSArray<SLCLDictationState *> *)states isArchived:(BOOL)isArchived page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationsOrderedByLastModified(userId:states:isArchived:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeDictationId:(NSString *)id completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeDictation(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddDictationDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddDictation(dictation:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddDictationsDictations:(NSArray<SLCLDictation *> *)dictations completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddDictations(dictations:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SqlDelightAttachmentRepository")))
@interface SLCLSqlDelightAttachmentRepository : SLCLBase <SLCLAttachmentRepository>
- (instancetype)initWithAttachmentQueries:(id<SLCLAttachmentQueries>)attachmentQueries __attribute__((swift_name("init(attachmentQueries:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentAttachmentId:(NSString *)attachmentId completionHandler:(void (^)(SLCLAttachment * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachment(attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsDictationId:(NSString *)dictationId completionHandler:(void (^)(NSArray<SLCLAttachment *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachments(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAttachmentsOrderedByLastModifiedDictationId:(NSString *)dictationId completionHandler:(void (^)(NSArray<SLCLAttachment *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAttachmentsOrderedByLastModified(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getWorkingCopyOriginalId:(NSString *)originalId completionHandler:(void (^)(SLCLAttachment * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getWorkingCopy(originalId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeAttachmentAttachmentId:(NSString *)attachmentId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeAttachment(attachmentId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddAttachmentAttachment:(SLCLAttachment *)attachment completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddAttachment(attachment:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddAttachmentsAttachments:(NSArray<SLCLAttachment *> *)attachments completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddAttachments(attachments:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SqlDelightDictationRepository")))
@interface SLCLSqlDelightDictationRepository : SLCLBase <SLCLDictationRepository>
- (instancetype)initWithDictationQueries:(id<SLCLDictationQueries>)dictationQueries __attribute__((swift_name("init(dictationQueries:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAudioFileNamesUserId:(NSString *)userId completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAudioFileNames(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationId:(NSString *)id completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictation(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationWorkingCopyOriginalId:(NSString *)originalId completionHandler:(void (^)(SLCLDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationWorkingCopy(originalId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsWithCompletionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsUserId:(NSString *)userId completionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictations(userId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDictationsOrderedByLastModifiedUserId:(NSString *)userId states:(NSArray<SLCLDictationState *> *)states isArchived:(BOOL)isArchived page:(int32_t)page pageSize:(int32_t)pageSize completionHandler:(void (^)(NSArray<SLCLDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getDictationsOrderedByLastModified(userId:states:isArchived:page:pageSize:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeDictationId:(NSString *)id completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("removeDictation(id:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddDictationDictation:(SLCLDictation *)dictation completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddDictation(dictation:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateOrAddDictationsDictations:(NSArray<SLCLDictation *> *)dictations completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateOrAddDictations(dictations:completionHandler:)")));
@end;

__attribute__((swift_name("UploadQueueRepository")))
@protocol SLCLUploadQueueRepository
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)addDictationToUploadQueueQueuedDictation:(SLCLQueuedDictation *)queuedDictation completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("addDictationToUploadQueue(queuedDictation:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)changeRetryCountDictationId:(NSString *)dictationId retryCount:(int32_t)retryCount completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("changeRetryCount(dictationId:retryCount:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)changeUploadStateDictationId:(NSString *)dictationId state:(SLCLUploadState *)state completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("changeUploadState(dictationId:state:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteDictationFromQueueDictationId:(NSString *)dictationId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("deleteDictationFromQueue(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllDictationsInTheQueueWithCompletionHandler:(void (^)(NSArray<SLCLQueuedDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllDictationsInTheQueue(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllDictationsInTheQueueOrderedByCreatedDateWithCompletionHandler:(void (^)(NSArray<SLCLQueuedDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllDictationsInTheQueueOrderedByCreatedDate(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getQueuedDictationByIdDictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLQueuedDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getQueuedDictationById(dictationId:completionHandler:)")));
- (void)subscribeToQueueListener:(id<SLCLUploadingQueueListener>)listener __attribute__((swift_name("subscribeToQueue(listener:)")));
- (void)unsubscribeFromQueueListener:(id<SLCLUploadingQueueListener>)listener __attribute__((swift_name("unsubscribeFromQueue(listener:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SqlDelightUploadQueueRepository")))
@interface SLCLSqlDelightUploadQueueRepository : SLCLBase <SLCLUploadQueueRepository>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext uploadQueueQueries:(id<SLCLQueuedDictationQueries>)uploadQueueQueries logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(mainContext:uploadQueueQueries:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)addDictationToUploadQueueQueuedDictation:(SLCLQueuedDictation *)queuedDictation completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("addDictationToUploadQueue(queuedDictation:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)changeRetryCountDictationId:(NSString *)dictationId retryCount:(int32_t)retryCount completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("changeRetryCount(dictationId:retryCount:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)changeUploadStateDictationId:(NSString *)dictationId state:(SLCLUploadState *)state completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("changeUploadState(dictationId:state:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteDictationFromQueueDictationId:(NSString *)dictationId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("deleteDictationFromQueue(dictationId:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllDictationsInTheQueueWithCompletionHandler:(void (^)(NSArray<SLCLQueuedDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllDictationsInTheQueue(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllDictationsInTheQueueOrderedByCreatedDateWithCompletionHandler:(void (^)(NSArray<SLCLQueuedDictation *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllDictationsInTheQueueOrderedByCreatedDate(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getQueuedDictationByIdDictationId:(NSString *)dictationId completionHandler:(void (^)(SLCLQueuedDictation * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getQueuedDictationById(dictationId:completionHandler:)")));
- (void)subscribeToQueueListener:(id<SLCLUploadingQueueListener>)listener __attribute__((swift_name("subscribeToQueue(listener:)")));
- (void)unsubscribeFromQueueListener:(id<SLCLUploadingQueueListener>)listener __attribute__((swift_name("unsubscribeFromQueue(listener:)")));
@end;

__attribute__((swift_name("UploadingQueueListener")))
@protocol SLCLUploadingQueueListener
@required
- (void)onUploadinQueueChangedUploadingQueue:(NSArray<SLCLQueuedDictation *> *)uploadingQueue __attribute__((swift_name("onUploadinQueueChanged(uploadingQueue:)")));
@end;

__attribute__((swift_name("AdminApi")))
@protocol SLCLAdminApi
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAvailableAssigneesForAuthorUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<NSArray<SLCLAssignee *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAvailableAssigneesForAuthor(userId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechLiveAdminApi")))
@interface SLCLSpeechLiveAdminApi : SLCLBase <SLCLAdminApi>
- (instancetype)initWithHttpClient:(SLCLKtor_client_coreHttpClient *)httpClient logger:(id<SLCLLogger>)logger apiServerEnvironment:(SLCLApiServerEnvironment *)apiServerEnvironment identityService:(id<SLCLIdentityService>)identityService apiVersion:(int32_t)apiVersion networkConnectivityMonitor:(id<SLCLNetworkConnectivityMonitor>)networkConnectivityMonitor __attribute__((swift_name("init(httpClient:logger:apiServerEnvironment:identityService:apiVersion:networkConnectivityMonitor:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAvailableAssigneesForAuthorUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<NSArray<SLCLAssignee *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAvailableAssigneesForAuthor(userId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AssignRequestDto")))
@interface SLCLAssignRequestDto : SLCLBase
- (instancetype)initWithTeamId:(NSString *)teamId dictationId:(NSString *)dictationId __attribute__((swift_name("init(teamId:dictationId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLAssignRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAssignRequestDto *)doCopyTeamId:(NSString *)teamId dictationId:(NSString *)dictationId __attribute__((swift_name("doCopy(teamId:dictationId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *dictationId __attribute__((swift_name("dictationId")));
@property (readonly) NSString *teamId __attribute__((swift_name("teamId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AssignRequestDto.Companion")))
@interface SLCLAssignRequestDtoCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAssignRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechExecEnterpriseAdminApi")))
@interface SLCLSpeechExecEnterpriseAdminApi : SLCLBase <SLCLAdminApi>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAvailableAssigneesForAuthorUserId:(NSString *)userId completionHandler:(void (^)(SLCLEither<NSArray<SLCLAssignee *> *, SLCLApiError *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAvailableAssigneesForAuthor(userId:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Assignee")))
@interface SLCLAssignee : SLCLBase
- (instancetype)initWithId:(NSString *)id name:(NSString *)name type:(SLCLAssigneeType *)type __attribute__((swift_name("init(id:name:type:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAssigneeType *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAssignee *)doCopyId:(NSString *)id name:(NSString *)name type:(SLCLAssigneeType *)type __attribute__((swift_name("doCopy(id:name:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) SLCLAssigneeType *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AssigneeType")))
@interface SLCLAssigneeType : SLCLKotlinEnum<SLCLAssigneeType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLAssigneeTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLAssigneeType *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLAssigneeType *default_ __attribute__((swift_name("default_")));
@property (class, readonly) SLCLAssigneeType *private_ __attribute__((swift_name("private_")));
@property (class, readonly) SLCLAssigneeType *single __attribute__((swift_name("single")));
@property (class, readonly) SLCLAssigneeType *team __attribute__((swift_name("team")));
+ (SLCLKotlinArray<SLCLAssigneeType *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AssigneeType.Companion")))
@interface SLCLAssigneeTypeCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLAssigneeTypeCompanion *shared __attribute__((swift_name("shared")));
- (SLCLAssigneeType *)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Attachment")))
@interface SLCLAttachment : SLCLBase
- (instancetype)initWithId:(NSString *)id dictationId:(NSString *)dictationId name:(NSString *)name sizeBytes:(int64_t)sizeBytes originalFileHash:(NSString *)originalFileHash createdMillisecondsUtc:(int64_t)createdMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc mimeType:(NSString *)mimeType categoryId:(NSString *)categoryId createdByUserId:(NSString *)createdByUserId modifiedByUserId:(NSString *)modifiedByUserId originalId:(NSString * _Nullable)originalId __attribute__((swift_name("init(id:dictationId:name:sizeBytes:originalFileHash:createdMillisecondsUtc:uploadedMillisecondsUtc:lastModifiedMillisecondsUtc:mimeType:categoryId:createdByUserId:modifiedByUserId:originalId:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component11 __attribute__((swift_name("component11()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component12 __attribute__((swift_name("component12()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component13 __attribute__((swift_name("component13()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAttachment *)doCopyId:(NSString *)id dictationId:(NSString *)dictationId name:(NSString *)name sizeBytes:(int64_t)sizeBytes originalFileHash:(NSString *)originalFileHash createdMillisecondsUtc:(int64_t)createdMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc mimeType:(NSString *)mimeType categoryId:(NSString *)categoryId createdByUserId:(NSString *)createdByUserId modifiedByUserId:(NSString *)modifiedByUserId originalId:(NSString * _Nullable)originalId __attribute__((swift_name("doCopy(id:dictationId:name:sizeBytes:originalFileHash:createdMillisecondsUtc:uploadedMillisecondsUtc:lastModifiedMillisecondsUtc:mimeType:categoryId:createdByUserId:modifiedByUserId:originalId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLDictationFileCategory *category __attribute__((swift_name("category")));
@property (readonly) NSString *categoryId __attribute__((swift_name("categoryId")));
@property (readonly) NSString *createdByUserId __attribute__((swift_name("createdByUserId")));
@property (readonly) int64_t createdMillisecondsUtc __attribute__((swift_name("createdMillisecondsUtc")));
@property (readonly) NSString *dictationId __attribute__((swift_name("dictationId")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) NSString *mimeType __attribute__((swift_name("mimeType")));
@property (readonly) NSString *modifiedByUserId __attribute__((swift_name("modifiedByUserId")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *originalFileHash __attribute__((swift_name("originalFileHash")));
@property (readonly) NSString * _Nullable originalId __attribute__((swift_name("originalId")));
@property (readonly) int64_t sizeBytes __attribute__((swift_name("sizeBytes")));
@property (readonly) int64_t uploadedMillisecondsUtc __attribute__((swift_name("uploadedMillisecondsUtc")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AttachmentFile")))
@interface SLCLAttachmentFile : SLCLBase
- (instancetype)initWithAttachment:(SLCLAttachment *)attachment file:(id<SLCLFile>)file __attribute__((swift_name("init(attachment:file:)"))) __attribute__((objc_designated_initializer));
- (SLCLAttachment *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (id<SLCLFile>)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLAttachmentFile *)doCopyAttachment:(SLCLAttachment *)attachment file:(id<SLCLFile>)file __attribute__((swift_name("doCopy(attachment:file:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLAttachment *attachment __attribute__((swift_name("attachment")));
@property (readonly) id<SLCLFile> file __attribute__((swift_name("file")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Dictation")))
@interface SLCLDictation : SLCLBase
- (instancetype)initWithId:(NSString *)id stateId:(int32_t)stateId isArchived:(BOOL)isArchived authorId:(NSString *)authorId authorName:(NSString *)authorName lastModifiedByUserId:(NSString *)lastModifiedByUserId lastModifiedByUserName:(NSString *)lastModifiedByUserName priority:(int32_t)priority hasTranscription:(BOOL)hasTranscription hasAttachments:(BOOL)hasAttachments originalMetadataFileHash:(NSString *)originalMetadataFileHash lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc createdMillisecondsLocal:(int64_t)createdMillisecondsLocal title:(NSString *)title workType:(NSString *)workType category:(NSString *)category comment:(NSString *)comment department:(NSString *)department keyword:(NSString *)keyword dpmBarcode:(NSString *)dpmBarcode custom1:(NSString *)custom1 custom2:(NSString *)custom2 custom3:(NSString *)custom3 custom4:(NSString *)custom4 custom5:(NSString *)custom5 audioFileName:(NSString *)audioFileName durationMilliseconds:(int64_t)durationMilliseconds audioTypeId:(int32_t)audioTypeId audioFormatId:(int32_t)audioFormatId numOfChannels:(int32_t)numOfChannels sampleRate:(int32_t)sampleRate byteRate:(int32_t)byteRate blockAlign:(int32_t)blockAlign bitsPerSample:(int32_t)bitsPerSample originalId:(NSString * _Nullable)originalId assigneeId:(NSString *)assigneeId assigneeName:(NSString *)assigneeName assigneeTypeId:(int32_t)assigneeTypeId dueDateMillisecondsUtc:(int64_t)dueDateMillisecondsUtc __attribute__((swift_name("init(id:stateId:isArchived:authorId:authorName:lastModifiedByUserId:lastModifiedByUserName:priority:hasTranscription:hasAttachments:originalMetadataFileHash:lastModifiedMillisecondsUtc:uploadedMillisecondsUtc:createdMillisecondsLocal:title:workType:category:comment:department:keyword:dpmBarcode:custom1:custom2:custom3:custom4:custom5:audioFileName:durationMilliseconds:audioTypeId:audioFormatId:numOfChannels:sampleRate:byteRate:blockAlign:bitsPerSample:originalId:assigneeId:assigneeName:assigneeTypeId:dueDateMillisecondsUtc:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component10 __attribute__((swift_name("component10()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component11 __attribute__((swift_name("component11()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component12 __attribute__((swift_name("component12()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component13 __attribute__((swift_name("component13()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component14 __attribute__((swift_name("component14()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component15 __attribute__((swift_name("component15()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component16 __attribute__((swift_name("component16()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component17 __attribute__((swift_name("component17()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component18 __attribute__((swift_name("component18()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component19 __attribute__((swift_name("component19()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component20 __attribute__((swift_name("component20()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component21 __attribute__((swift_name("component21()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component22 __attribute__((swift_name("component22()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component23 __attribute__((swift_name("component23()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component24 __attribute__((swift_name("component24()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component25 __attribute__((swift_name("component25()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component26 __attribute__((swift_name("component26()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component27 __attribute__((swift_name("component27()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component28 __attribute__((swift_name("component28()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component29 __attribute__((swift_name("component29()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component30 __attribute__((swift_name("component30()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component31 __attribute__((swift_name("component31()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component32 __attribute__((swift_name("component32()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component33 __attribute__((swift_name("component33()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component34 __attribute__((swift_name("component34()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component35 __attribute__((swift_name("component35()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component36 __attribute__((swift_name("component36()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component37 __attribute__((swift_name("component37()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component38 __attribute__((swift_name("component38()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component39 __attribute__((swift_name("component39()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component40 __attribute__((swift_name("component40()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictation *)doCopyId:(NSString *)id stateId:(int32_t)stateId isArchived:(BOOL)isArchived authorId:(NSString *)authorId authorName:(NSString *)authorName lastModifiedByUserId:(NSString *)lastModifiedByUserId lastModifiedByUserName:(NSString *)lastModifiedByUserName priority:(int32_t)priority hasTranscription:(BOOL)hasTranscription hasAttachments:(BOOL)hasAttachments originalMetadataFileHash:(NSString *)originalMetadataFileHash lastModifiedMillisecondsUtc:(int64_t)lastModifiedMillisecondsUtc uploadedMillisecondsUtc:(int64_t)uploadedMillisecondsUtc createdMillisecondsLocal:(int64_t)createdMillisecondsLocal title:(NSString *)title workType:(NSString *)workType category:(NSString *)category comment:(NSString *)comment department:(NSString *)department keyword:(NSString *)keyword dpmBarcode:(NSString *)dpmBarcode custom1:(NSString *)custom1 custom2:(NSString *)custom2 custom3:(NSString *)custom3 custom4:(NSString *)custom4 custom5:(NSString *)custom5 audioFileName:(NSString *)audioFileName durationMilliseconds:(int64_t)durationMilliseconds audioTypeId:(int32_t)audioTypeId audioFormatId:(int32_t)audioFormatId numOfChannels:(int32_t)numOfChannels sampleRate:(int32_t)sampleRate byteRate:(int32_t)byteRate blockAlign:(int32_t)blockAlign bitsPerSample:(int32_t)bitsPerSample originalId:(NSString * _Nullable)originalId assigneeId:(NSString *)assigneeId assigneeName:(NSString *)assigneeName assigneeTypeId:(int32_t)assigneeTypeId dueDateMillisecondsUtc:(int64_t)dueDateMillisecondsUtc __attribute__((swift_name("doCopy(id:stateId:isArchived:authorId:authorName:lastModifiedByUserId:lastModifiedByUserName:priority:hasTranscription:hasAttachments:originalMetadataFileHash:lastModifiedMillisecondsUtc:uploadedMillisecondsUtc:createdMillisecondsLocal:title:workType:category:comment:department:keyword:dpmBarcode:custom1:custom2:custom3:custom4:custom5:audioFileName:durationMilliseconds:audioTypeId:audioFormatId:numOfChannels:sampleRate:byteRate:blockAlign:bitsPerSample:originalId:assigneeId:assigneeName:assigneeTypeId:dueDateMillisecondsUtc:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *assigneeId __attribute__((swift_name("assigneeId")));
@property (readonly) NSString *assigneeName __attribute__((swift_name("assigneeName")));
@property (readonly) SLCLAssigneeType *assigneeType __attribute__((swift_name("assigneeType")));
@property (readonly) int32_t assigneeTypeId __attribute__((swift_name("assigneeTypeId")));
@property (readonly) NSString *audioFileName __attribute__((swift_name("audioFileName")));
@property (readonly) NSString *audioFileNameWithoutExtension __attribute__((swift_name("audioFileNameWithoutExtension")));
@property (readonly) int32_t audioFormatId __attribute__((swift_name("audioFormatId")));
@property (readonly) SLCLAudioSettings *audioSettings __attribute__((swift_name("audioSettings")));
@property (readonly) SLCLAudioType *audioType __attribute__((swift_name("audioType")));
@property (readonly) int32_t audioTypeId __attribute__((swift_name("audioTypeId")));
@property (readonly) NSString *authorId __attribute__((swift_name("authorId")));
@property (readonly) NSString *authorName __attribute__((swift_name("authorName")));
@property (readonly) int32_t bitsPerSample __attribute__((swift_name("bitsPerSample")));
@property (readonly) int32_t blockAlign __attribute__((swift_name("blockAlign")));
@property (readonly) int32_t byteRate __attribute__((swift_name("byteRate")));
@property (readonly) NSString *category __attribute__((swift_name("category")));
@property (readonly) NSString *comment __attribute__((swift_name("comment")));
@property (readonly) int64_t createdMillisecondsLocal __attribute__((swift_name("createdMillisecondsLocal")));
@property (readonly) NSString *custom1 __attribute__((swift_name("custom1")));
@property (readonly) NSString *custom2 __attribute__((swift_name("custom2")));
@property (readonly) NSString *custom3 __attribute__((swift_name("custom3")));
@property (readonly) NSString *custom4 __attribute__((swift_name("custom4")));
@property (readonly) NSString *custom5 __attribute__((swift_name("custom5")));
@property (readonly) NSString *department __attribute__((swift_name("department")));
@property (readonly) NSString *dpmBarcode __attribute__((swift_name("dpmBarcode")));
@property (readonly) int64_t dueDateMillisecondsUtc __attribute__((swift_name("dueDateMillisecondsUtc")));
@property (readonly) int64_t durationMilliseconds __attribute__((swift_name("durationMilliseconds")));
@property (readonly) SLCLDictationGroup *group __attribute__((swift_name("group")));
@property (readonly) BOOL hasAttachments __attribute__((swift_name("hasAttachments")));
@property (readonly) BOOL hasTranscription __attribute__((swift_name("hasTranscription")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isArchived __attribute__((swift_name("isArchived")));
@property (readonly) NSString *keyword __attribute__((swift_name("keyword")));
@property (readonly) NSString *lastModifiedByUserId __attribute__((swift_name("lastModifiedByUserId")));
@property (readonly) NSString *lastModifiedByUserName __attribute__((swift_name("lastModifiedByUserName")));
@property (readonly) int64_t lastModifiedMillisecondsUtc __attribute__((swift_name("lastModifiedMillisecondsUtc")));
@property (readonly) int32_t numOfChannels __attribute__((swift_name("numOfChannels")));
@property (readonly) NSString * _Nullable originalId __attribute__((swift_name("originalId")));
@property (readonly) NSString *originalMetadataFileHash __attribute__((swift_name("originalMetadataFileHash")));
@property (readonly) int32_t priority __attribute__((swift_name("priority")));
@property (readonly) SLCLPriority *priorityEnum __attribute__((swift_name("priorityEnum")));
@property (readonly) int32_t sampleRate __attribute__((swift_name("sampleRate")));
@property (readonly) SLCLDictationState *state __attribute__((swift_name("state")));
@property (readonly) int32_t stateId __attribute__((swift_name("stateId")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@property SLCLUploadState * _Nullable uploadState __attribute__((swift_name("uploadState")));
@property (readonly) int64_t uploadedMillisecondsUtc __attribute__((swift_name("uploadedMillisecondsUtc")));
@property (readonly) NSString *workType __attribute__((swift_name("workType")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationFileCategory")))
@interface SLCLDictationFileCategory : SLCLKotlinEnum<SLCLDictationFileCategory *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLDictationFileCategoryCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLDictationFileCategory *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLDictationFileCategory *metadata __attribute__((swift_name("metadata")));
@property (class, readonly) SLCLDictationFileCategory *audio __attribute__((swift_name("audio")));
@property (class, readonly) SLCLDictationFileCategory *transcription __attribute__((swift_name("transcription")));
@property (class, readonly) SLCLDictationFileCategory *attachment __attribute__((swift_name("attachment")));
+ (SLCLKotlinArray<SLCLDictationFileCategory *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *id_ __attribute__((swift_name("id_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationFileCategory.Companion")))
@interface SLCLDictationFileCategoryCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDictationFileCategoryCompanion *shared __attribute__((swift_name("shared")));
- (SLCLDictationFileCategory *)fromIdId:(NSString *)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationGroup")))
@interface SLCLDictationGroup : SLCLKotlinEnum<SLCLDictationGroup *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLDictationGroupCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLDictationGroup *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLDictationGroup *draft __attribute__((swift_name("draft")));
@property (class, readonly) SLCLDictationGroup *sent __attribute__((swift_name("sent")));
@property (class, readonly) SLCLDictationGroup *finished __attribute__((swift_name("finished")));
@property (class, readonly) SLCLDictationGroup *archive __attribute__((swift_name("archive")));
+ (SLCLKotlinArray<SLCLDictationGroup *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@property (readonly) NSArray<SLCLDictationState *> *states __attribute__((swift_name("states")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationGroup.Companion")))
@interface SLCLDictationGroupCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDictationGroupCompanion *shared __attribute__((swift_name("shared")));
- (SLCLDictationGroup *)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
- (SLCLDictationGroup *)fromStateState:(SLCLDictationState *)state __attribute__((swift_name("fromState(state:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationListNewItemAction")))
@interface SLCLDictationListNewItemAction : SLCLKotlinEnum<SLCLDictationListNewItemAction *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLDictationListNewItemAction *dictation __attribute__((swift_name("dictation")));
@property (class, readonly) SLCLDictationListNewItemAction *speechToText __attribute__((swift_name("speechToText")));
+ (SLCLKotlinArray<SLCLDictationListNewItemAction *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationState")))
@interface SLCLDictationState : SLCLKotlinEnum<SLCLDictationState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLDictationStateCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLDictationState *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLDictationState *recordingInProgress __attribute__((swift_name("recordingInProgress")));
@property (class, readonly) SLCLDictationState *recordingSuspended __attribute__((swift_name("recordingSuspended")));
@property (class, readonly) SLCLDictationState *transcriptionPending __attribute__((swift_name("transcriptionPending")));
@property (class, readonly) SLCLDictationState *transcriptionInProgress __attribute__((swift_name("transcriptionInProgress")));
@property (class, readonly) SLCLDictationState *transcriptionSuspended __attribute__((swift_name("transcriptionSuspended")));
@property (class, readonly) SLCLDictationState *transcriptionFinished __attribute__((swift_name("transcriptionFinished")));
@property (class, readonly) SLCLDictationState *correctionPending __attribute__((swift_name("correctionPending")));
@property (class, readonly) SLCLDictationState *correctionInProgress __attribute__((swift_name("correctionInProgress")));
@property (class, readonly) SLCLDictationState *correctionSuspended __attribute__((swift_name("correctionSuspended")));
@property (class, readonly) SLCLDictationState *waitingForAdaptation __attribute__((swift_name("waitingForAdaptation")));
@property (class, readonly) SLCLDictationState *adaptationInProgress __attribute__((swift_name("adaptationInProgress")));
@property (class, readonly) SLCLDictationState *queuedForTranscriptionService __attribute__((swift_name("queuedForTranscriptionService")));
@property (class, readonly) SLCLDictationState *transcriptionServiceInProgress __attribute__((swift_name("transcriptionServiceInProgress")));
@property (class, readonly) SLCLDictationState *queuedForSpeechliveSpeechRecognition __attribute__((swift_name("queuedForSpeechliveSpeechRecognition")));
@property (class, readonly) SLCLDictationState *speechliveSpeechRecognitionInProgress __attribute__((swift_name("speechliveSpeechRecognitionInProgress")));
+ (SLCLKotlinArray<SLCLDictationState *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DictationState.Companion")))
@interface SLCLDictationStateCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLDictationStateCompanion *shared __attribute__((swift_name("shared")));
- (SLCLDictationState *)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QueuedDictation")))
@interface SLCLQueuedDictation : SLCLBase
- (instancetype)initWithDictationId:(NSString *)dictationId targetState:(SLCLDictationState *)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId uploadStateId:(int32_t)uploadStateId retryCount:(int32_t)retryCount createdMillisecondsUtc:(SLCLLong * _Nullable)createdMillisecondsUtc __attribute__((swift_name("init(dictationId:targetState:speechRecognitionLanguageCode:teamId:uploadStateId:retryCount:createdMillisecondsUtc:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLDictationState *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLLong * _Nullable)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLQueuedDictation *)doCopyDictationId:(NSString *)dictationId targetState:(SLCLDictationState *)targetState speechRecognitionLanguageCode:(NSString *)speechRecognitionLanguageCode teamId:(NSString * _Nullable)teamId uploadStateId:(int32_t)uploadStateId retryCount:(int32_t)retryCount createdMillisecondsUtc:(SLCLLong * _Nullable)createdMillisecondsUtc __attribute__((swift_name("doCopy(dictationId:targetState:speechRecognitionLanguageCode:teamId:uploadStateId:retryCount:createdMillisecondsUtc:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLLong * _Nullable createdMillisecondsUtc __attribute__((swift_name("createdMillisecondsUtc")));
@property (readonly) NSString *dictationId __attribute__((swift_name("dictationId")));
@property (readonly) int32_t retryCount __attribute__((swift_name("retryCount")));
@property (readonly) NSString *speechRecognitionLanguageCode __attribute__((swift_name("speechRecognitionLanguageCode")));
@property (readonly) SLCLDictationState *targetState __attribute__((swift_name("targetState")));
@property (readonly) NSString * _Nullable teamId __attribute__((swift_name("teamId")));
@property (readonly) SLCLUploadState *uploadState __attribute__((swift_name("uploadState")));
@property (readonly) int32_t uploadStateId __attribute__((swift_name("uploadStateId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeechRecognitionLanguage")))
@interface SLCLSpeechRecognitionLanguage : SLCLBase
- (instancetype)initWithNativeName:(NSString *)nativeName languageCode:(NSString *)languageCode localeLanguage:(NSString *)localeLanguage localeCountry:(NSString *)localeCountry __attribute__((swift_name("init(nativeName:languageCode:localeLanguage:localeCountry:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSpeechRecognitionLanguage *)doCopyNativeName:(NSString *)nativeName languageCode:(NSString *)languageCode localeLanguage:(NSString *)localeLanguage localeCountry:(NSString *)localeCountry __attribute__((swift_name("doCopy(nativeName:languageCode:localeLanguage:localeCountry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *languageCode __attribute__((swift_name("languageCode")));
@property (readonly) NSString *localeCountry __attribute__((swift_name("localeCountry")));
@property (readonly) NSString *localeLanguage __attribute__((swift_name("localeLanguage")));
@property (readonly) NSString *nativeName __attribute__((swift_name("nativeName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubscriptionAndUserInfo")))
@interface SLCLSubscriptionAndUserInfo : SLCLBase
- (instancetype)initWithTranscriptionServiceEnabled:(BOOL)transcriptionServiceEnabled transcriptionServiceAvailableMinutes:(double)transcriptionServiceAvailableMinutes sttForUserEnabled:(BOOL)sttForUserEnabled preferredLanguageCodes:(NSArray<NSString *> *)preferredLanguageCodes isMultiSpeakerTranscriptionEnabled:(BOOL)isMultiSpeakerTranscriptionEnabled sttCorrectionPendingFlowEnabled:(BOOL)sttCorrectionPendingFlowEnabled __attribute__((swift_name("init(transcriptionServiceEnabled:transcriptionServiceAvailableMinutes:sttForUserEnabled:preferredLanguageCodes:isMultiSpeakerTranscriptionEnabled:sttCorrectionPendingFlowEnabled:)"))) __attribute__((objc_designated_initializer));
- (BOOL)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (double)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSArray<NSString *> *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLSubscriptionAndUserInfo *)doCopyTranscriptionServiceEnabled:(BOOL)transcriptionServiceEnabled transcriptionServiceAvailableMinutes:(double)transcriptionServiceAvailableMinutes sttForUserEnabled:(BOOL)sttForUserEnabled preferredLanguageCodes:(NSArray<NSString *> *)preferredLanguageCodes isMultiSpeakerTranscriptionEnabled:(BOOL)isMultiSpeakerTranscriptionEnabled sttCorrectionPendingFlowEnabled:(BOOL)sttCorrectionPendingFlowEnabled __attribute__((swift_name("doCopy(transcriptionServiceEnabled:transcriptionServiceAvailableMinutes:sttForUserEnabled:preferredLanguageCodes:isMultiSpeakerTranscriptionEnabled:sttCorrectionPendingFlowEnabled:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isMultiSpeakerTranscriptionEnabled __attribute__((swift_name("isMultiSpeakerTranscriptionEnabled")));
@property (readonly) NSArray<NSString *> *preferredLanguageCodes __attribute__((swift_name("preferredLanguageCodes")));
@property (readonly) BOOL sttCorrectionPendingFlowEnabled __attribute__((swift_name("sttCorrectionPendingFlowEnabled")));
@property (readonly) BOOL sttForUserEnabled __attribute__((swift_name("sttForUserEnabled")));
@property (readonly) double transcriptionServiceAvailableMinutes __attribute__((swift_name("transcriptionServiceAvailableMinutes")));
@property (readonly) BOOL transcriptionServiceEnabled __attribute__((swift_name("transcriptionServiceEnabled")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadState")))
@interface SLCLUploadState : SLCLKotlinEnum<SLCLUploadState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLUploadStateCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLUploadState *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SLCLUploadState *uploading __attribute__((swift_name("uploading")));
@property (class, readonly) SLCLUploadState *queued __attribute__((swift_name("queued")));
@property (class, readonly) SLCLUploadState *editing __attribute__((swift_name("editing")));
@property (class, readonly) SLCLUploadState *savedLocally __attribute__((swift_name("savedLocally")));
@property (class, readonly) SLCLUploadState *unrecoverableError __attribute__((swift_name("unrecoverableError")));
@property (class, readonly) SLCLUploadState *sendingToTranscriptionServiceFailed __attribute__((swift_name("sendingToTranscriptionServiceFailed")));
@property (class, readonly) SLCLUploadState *sendingToSpeechRecognitionFailed __attribute__((swift_name("sendingToSpeechRecognitionFailed")));
@property (class, readonly) SLCLUploadState *assigningToTranscriptionistFailed __attribute__((swift_name("assigningToTranscriptionistFailed")));
@property (class, readonly) SLCLUploadState *failedAfterRetries __attribute__((swift_name("failedAfterRetries")));
+ (SLCLKotlinArray<SLCLUploadState *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadState.Companion")))
@interface SLCLUploadStateCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLUploadStateCompanion *shared __attribute__((swift_name("shared")));
- (SLCLUploadState *)fromIdId:(int32_t)id __attribute__((swift_name("fromId(id:)")));
@end;

__attribute__((swift_name("PlayerContract")))
@protocol SLCLPlayerContract
@required
@end;

__attribute__((swift_name("PlayerContractPresenter")))
@protocol SLCLPlayerContractPresenter <SLCLBasePresenter>
@required
- (void)onClosePlayerClick __attribute__((swift_name("onClosePlayerClick()")));
- (void)onDictationSelectedDictation:(SLCLDictation *)dictation __attribute__((swift_name("onDictationSelected(dictation:)")));
- (void)onFastForwardClick __attribute__((swift_name("onFastForwardClick()")));
- (void)onFastForwardHoldStart __attribute__((swift_name("onFastForwardHoldStart()")));
- (void)onFastForwardHoldStop __attribute__((swift_name("onFastForwardHoldStop()")));
- (void)onPauseClick __attribute__((swift_name("onPauseClick()")));
- (void)onPlayClick __attribute__((swift_name("onPlayClick()")));
- (void)onRewindClick __attribute__((swift_name("onRewindClick()")));
- (void)onRewindHoldStart __attribute__((swift_name("onRewindHoldStart()")));
- (void)onRewindHoldStop __attribute__((swift_name("onRewindHoldStop()")));
- (void)onSeekDragFinishedTimeMilliseconds:(int64_t)timeMilliseconds __attribute__((swift_name("onSeekDragFinished(timeMilliseconds:)")));
- (void)onSeekDragStarted __attribute__((swift_name("onSeekDragStarted()")));
@end;

__attribute__((swift_name("PlayerContractView")))
@protocol SLCLPlayerContractView <SLCLBaseView>
@required
- (void)closePlayer __attribute__((swift_name("closePlayer()")));
- (void)disableFastForwardButton __attribute__((swift_name("disableFastForwardButton()")));
- (void)disablePlayPauseButton __attribute__((swift_name("disablePlayPauseButton()")));
- (void)disableRewindButton __attribute__((swift_name("disableRewindButton()")));
- (void)enableFastForwardButton __attribute__((swift_name("enableFastForwardButton()")));
- (void)enablePlayPauseButton __attribute__((swift_name("enablePlayPauseButton()")));
- (void)enableRewindButton __attribute__((swift_name("enableRewindButton()")));
- (void)hideWaveform __attribute__((swift_name("hideWaveform()")));
- (void)showCurrentTimeMillisecondsTime:(int64_t)time __attribute__((swift_name("showCurrentTimeMilliseconds(time:)")));
- (void)showDurationMillisecondsTime:(int64_t)time __attribute__((swift_name("showDurationMilliseconds(time:)")));
- (void)showPauseButton __attribute__((swift_name("showPauseButton()")));
- (void)showPlayButton __attribute__((swift_name("showPlayButton()")));
- (void)showUnexpectedError __attribute__((swift_name("showUnexpectedError()")));
- (void)showWaveformDictationAudioPath:(NSString *)dictationAudioPath __attribute__((swift_name("showWaveform(dictationAudioPath:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlayerPresenter")))
@interface SLCLPlayerPresenter : SLCLBase <SLCLPlayerContractPresenter, SLCLPresenterCoroutineScope, SLCLAudioFilePlayerListener>
- (instancetype)initWithMainContext:(id<SLCLKotlinCoroutineContext>)mainContext logger:(id<SLCLLogger>)logger monitorPlaybackProgress:(id<SLCLMonitorPlaybackProgress>)monitorPlaybackProgress continuousSeek:(id<SLCLContinuousSeek>)continuousSeek getDictationAudioFile:(id<SLCLGetDictationAudioFile>)getDictationAudioFile deleteAppTemporaryFiles:(id<SLCLDeleteAppTemporaryFiles>)deleteAppTemporaryFiles player:(id<SLCLAudioFilePlayer>)player __attribute__((swift_name("init(mainContext:logger:monitorPlaybackProgress:continuousSeek:getDictationAudioFile:deleteAppTemporaryFiles:player:)"))) __attribute__((objc_designated_initializer));
- (void)cancelChildJobs __attribute__((swift_name("cancelChildJobs()")));
- (void)onAttachViewView:(id<SLCLPlayerContractView>)view __attribute__((swift_name("onAttachView(view:)")));
- (void)onClosePlayerClick __attribute__((swift_name("onClosePlayerClick()")));
- (void)onDetachView __attribute__((swift_name("onDetachView()")));
- (void)onDictationSelectedDictation:(SLCLDictation *)dictation __attribute__((swift_name("onDictationSelected(dictation:)")));
- (void)onFastForwardClick __attribute__((swift_name("onFastForwardClick()")));
- (void)onFastForwardHoldStart __attribute__((swift_name("onFastForwardHoldStart()")));
- (void)onFastForwardHoldStop __attribute__((swift_name("onFastForwardHoldStop()")));
- (void)onPauseClick __attribute__((swift_name("onPauseClick()")));
- (void)onPlayClick __attribute__((swift_name("onPlayClick()")));
- (void)onPlaybackPaused __attribute__((swift_name("onPlaybackPaused()")));
- (void)onPlaybackStarted __attribute__((swift_name("onPlaybackStarted()")));
- (void)onPlayerErrorMessage:(NSString *)message __attribute__((swift_name("onPlayerError(message:)")));
- (void)onPlayerPrepared __attribute__((swift_name("onPlayerPrepared()")));
- (void)onRewindClick __attribute__((swift_name("onRewindClick()")));
- (void)onRewindHoldStart __attribute__((swift_name("onRewindHoldStart()")));
- (void)onRewindHoldStop __attribute__((swift_name("onRewindHoldStop()")));
- (void)onSeekDragFinishedTimeMilliseconds:(int64_t)timeMilliseconds __attribute__((swift_name("onSeekDragFinished(timeMilliseconds:)")));
- (void)onSeekDragStarted __attribute__((swift_name("onSeekDragStarted()")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@property id<SLCLPlayerContractView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("ContinuousSeek")))
@protocol SLCLContinuousSeek
@required
- (id<SLCLKotlinx_coroutines_coreJob>)invokeFrequency:(int64_t)frequency offset:(int64_t)offset coroutine:(id<SLCLKotlinx_coroutines_coreCoroutineScope>)coroutine onUnexpectedError:(void (^)(void))onUnexpectedError onUpdate:(void (^)(SLCLLong *))onUpdate __attribute__((swift_name("invoke(frequency:offset:coroutine:onUnexpectedError:onUpdate:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultContinuousSeek")))
@interface SLCLDefaultContinuousSeek : SLCLBase <SLCLContinuousSeek>
- (instancetype)initWithPlayer:(id<SLCLAudioFilePlayer>)player logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(player:logger:)"))) __attribute__((objc_designated_initializer));
- (id<SLCLKotlinx_coroutines_coreJob>)invokeFrequency:(int64_t)frequency offset:(int64_t)offset coroutine:(id<SLCLKotlinx_coroutines_coreCoroutineScope>)coroutine onUnexpectedError:(void (^)(void))onUnexpectedError onUpdate:(void (^)(SLCLLong *))onUpdate __attribute__((swift_name("invoke(frequency:offset:coroutine:onUnexpectedError:onUpdate:)")));
@end;

__attribute__((swift_name("GetDictationAudioFile")))
@protocol SLCLGetDictationAudioFile
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(id<SLCLFile> _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultGetDictationAudioFile")))
@interface SLCLDefaultGetDictationAudioFile : SLCLBase <SLCLGetDictationAudioFile>
- (instancetype)initWithDictationFilesRepository:(id<SLCLDictationFilesRepository>)dictationFilesRepository decryptFile:(id<SLCLDecryptFile>)decryptFile tmpFilesDirectory:(id<SLCLDirectory>)tmpFilesDirectory logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(dictationFilesRepository:decryptFile:tmpFilesDirectory:logger:)"))) __attribute__((objc_designated_initializer));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeDictation:(SLCLDictation *)dictation completionHandler:(void (^)(id<SLCLFile> _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(dictation:completionHandler:)")));
@property (readonly) id<SLCLLogger> logger __attribute__((swift_name("logger")));
@end;

__attribute__((swift_name("MonitorPlaybackProgress")))
@protocol SLCLMonitorPlaybackProgress
@required
- (id<SLCLKotlinx_coroutines_coreJob>)invokeCoroutine:(id<SLCLKotlinx_coroutines_coreCoroutineScope>)coroutine onUnexpectedError:(void (^)(void))onUnexpectedError onUpdate:(void (^)(SLCLLong *))onUpdate __attribute__((swift_name("invoke(coroutine:onUnexpectedError:onUpdate:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultMonitorPlaybackProgress")))
@interface SLCLDefaultMonitorPlaybackProgress : SLCLBase <SLCLMonitorPlaybackProgress>
- (instancetype)initWithAudioFilePlayer:(id<SLCLAudioFilePlayer>)audioFilePlayer logger:(id<SLCLLogger>)logger __attribute__((swift_name("init(audioFilePlayer:logger:)"))) __attribute__((objc_designated_initializer));
- (id<SLCLKotlinx_coroutines_coreJob>)invokeCoroutine:(id<SLCLKotlinx_coroutines_coreCoroutineScope>)coroutine onUnexpectedError:(void (^)(void))onUnexpectedError onUpdate:(void (^)(SLCLLong *))onUpdate __attribute__((swift_name("invoke(coroutine:onUnexpectedError:onUpdate:)")));
@end;

__attribute__((swift_name("KotlinCharSequence")))
@protocol SLCLKotlinCharSequence
@required
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id)subSequenceStartIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("subSequence(startIndex:endIndex:)")));
@property (readonly) int32_t length __attribute__((swift_name("length")));
@end;

__attribute__((swift_name("KotlinAppendable")))
@protocol SLCLKotlinAppendable
@required
- (id<SLCLKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<SLCLKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<SLCLKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinStringBuilder")))
@interface SLCLKotlinStringBuilder : SLCLBase <SLCLKotlinCharSequence, SLCLKotlinAppendable>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithCapacity:(int32_t)capacity __attribute__((swift_name("init(capacity:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content __attribute__((swift_name("init(content:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent_:(id)content __attribute__((swift_name("init(content_:)"))) __attribute__((objc_designated_initializer));
- (SLCLKotlinStringBuilder *)appendValue__:(id _Nullable)value __attribute__((swift_name("append(value__:)")));
- (SLCLKotlinStringBuilder *)appendValue___:(BOOL)value __attribute__((swift_name("append(value___:)")));
- (SLCLKotlinStringBuilder *)appendValue____:(int8_t)value __attribute__((swift_name("append(value____:)")));
- (SLCLKotlinStringBuilder *)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (SLCLKotlinStringBuilder *)appendValue_____:(SLCLKotlinCharArray *)value __attribute__((swift_name("append(value_____:)")));
- (SLCLKotlinStringBuilder *)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (SLCLKotlinStringBuilder *)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
- (SLCLKotlinStringBuilder *)appendValue______:(double)value __attribute__((swift_name("append(value______:)")));
- (SLCLKotlinStringBuilder *)appendValue_______:(float)value __attribute__((swift_name("append(value_______:)")));
- (SLCLKotlinStringBuilder *)appendValue________:(int32_t)value __attribute__((swift_name("append(value________:)")));
- (SLCLKotlinStringBuilder *)appendValue_________:(int64_t)value __attribute__((swift_name("append(value_________:)")));
- (SLCLKotlinStringBuilder *)appendValue__________:(int16_t)value __attribute__((swift_name("append(value__________:)")));
- (SLCLKotlinStringBuilder *)appendValue___________:(NSString * _Nullable)value __attribute__((swift_name("append(value___________:)")));
- (SLCLKotlinStringBuilder *)appendRangeValue:(SLCLKotlinCharArray *)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("appendRange(value:startIndex:endIndex:)")));
- (SLCLKotlinStringBuilder *)appendRangeValue:(id)value startIndex:(int32_t)startIndex endIndex_:(int32_t)endIndex __attribute__((swift_name("appendRange(value:startIndex:endIndex_:)")));
- (int32_t)capacity __attribute__((swift_name("capacity()")));
- (SLCLKotlinStringBuilder *)deleteAtIndex:(int32_t)index __attribute__((swift_name("deleteAt(index:)")));
- (SLCLKotlinStringBuilder *)deleteRangeStartIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("deleteRange(startIndex:endIndex:)")));
- (void)ensureCapacityMinimumCapacity:(int32_t)minimumCapacity __attribute__((swift_name("ensureCapacity(minimumCapacity:)")));
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (int32_t)indexOfString:(NSString *)string __attribute__((swift_name("indexOf(string:)")));
- (int32_t)indexOfString:(NSString *)string startIndex:(int32_t)startIndex __attribute__((swift_name("indexOf(string:startIndex:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value:(id _Nullable)value __attribute__((swift_name("insert(index:value:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value_:(BOOL)value __attribute__((swift_name("insert(index:value_:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value__:(int8_t)value __attribute__((swift_name("insert(index:value__:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value___:(unichar)value __attribute__((swift_name("insert(index:value___:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value____:(SLCLKotlinCharArray *)value __attribute__((swift_name("insert(index:value____:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value_____:(id _Nullable)value __attribute__((swift_name("insert(index:value_____:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value______:(double)value __attribute__((swift_name("insert(index:value______:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value_______:(float)value __attribute__((swift_name("insert(index:value_______:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value________:(int32_t)value __attribute__((swift_name("insert(index:value________:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value_________:(int64_t)value __attribute__((swift_name("insert(index:value_________:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value__________:(int16_t)value __attribute__((swift_name("insert(index:value__________:)")));
- (SLCLKotlinStringBuilder *)insertIndex:(int32_t)index value___________:(NSString * _Nullable)value __attribute__((swift_name("insert(index:value___________:)")));
- (SLCLKotlinStringBuilder *)insertRangeIndex:(int32_t)index value:(SLCLKotlinCharArray *)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("insertRange(index:value:startIndex:endIndex:)")));
- (SLCLKotlinStringBuilder *)insertRangeIndex:(int32_t)index value:(id)value startIndex:(int32_t)startIndex endIndex_:(int32_t)endIndex __attribute__((swift_name("insertRange(index:value:startIndex:endIndex_:)")));
- (int32_t)lastIndexOfString:(NSString *)string __attribute__((swift_name("lastIndexOf(string:)")));
- (int32_t)lastIndexOfString:(NSString *)string startIndex:(int32_t)startIndex __attribute__((swift_name("lastIndexOf(string:startIndex:)")));
- (SLCLKotlinStringBuilder *)reverse __attribute__((swift_name("reverse()")));
- (void)setIndex:(int32_t)index value:(unichar)value __attribute__((swift_name("set(index:value:)")));
- (void)setLengthNewLength:(int32_t)newLength __attribute__((swift_name("setLength(newLength:)")));
- (SLCLKotlinStringBuilder *)setRangeStartIndex:(int32_t)startIndex endIndex:(int32_t)endIndex value:(NSString *)value __attribute__((swift_name("setRange(startIndex:endIndex:value:)")));
- (id)subSequenceStartIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("subSequence(startIndex:endIndex:)")));
- (NSString *)substringStartIndex:(int32_t)startIndex __attribute__((swift_name("substring(startIndex:)")));
- (NSString *)substringStartIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("substring(startIndex:endIndex:)")));
- (void)toCharArrayDestination:(SLCLKotlinCharArray *)destination destinationOffset:(int32_t)destinationOffset startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("toCharArray(destination:destinationOffset:startIndex:endIndex:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)trimToSize __attribute__((swift_name("trimToSize()")));
@property (readonly) int32_t length __attribute__((swift_name("length")));
@end;

@interface SLCLKotlinStringBuilder (Extensions)
- (void)safeInsertIndex:(int32_t)index value:(NSString *)value __attribute__((swift_name("safeInsert(index:value:)")));
@end;

@interface SLCLEither (Extensions)
- (id _Nullable)getOrDefaultDefaultValue:(id _Nullable)defaultValue __attribute__((swift_name("getOrDefault(defaultValue:)")));
- (id _Nullable)getOrThrow __attribute__((swift_name("getOrThrow()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpEngineKt")))
@interface SLCLHttpEngineKt : SLCLBase
@property (class, readonly) id<SLCLKtor_client_coreHttpClientEngine> httpEngine __attribute__((swift_name("httpEngine")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoroutinesKt")))
@interface SLCLCoroutinesKt : SLCLBase
+ (id _Nullable)runBlockingBlock:(id<SLCLKotlinSuspendFunction0>)block __attribute__((swift_name("runBlocking(block:)")));
+ (void)ensureNeverFrozen:(id)receiver __attribute__((swift_name("ensureNeverFrozen(_:)")));
@property (class, readonly) SLCLKotlinx_coroutines_coreCoroutineDispatcher *ioDispatcher __attribute__((swift_name("ioDispatcher")));
@property (class, readonly) SLCLKotlinx_coroutines_coreCoroutineDispatcher *mainDispatcher __attribute__((swift_name("mainDispatcher")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SqlDelightDbKt")))
@interface SLCLSqlDelightDbKt : SLCLBase
+ (id<SLCLSpeechLiveDb>)initializeCoreDatabaseEncryptionProvider:(id<SLCLEncryptionProvider>)encryptionProvider __attribute__((swift_name("initializeCoreDatabase(encryptionProvider:)")));
@property (class, readonly) SLCLDatabaseDefinition *coreDatabaseDefinition __attribute__((swift_name("coreDatabaseDefinition")));
@end;

__attribute__((swift_name("RuntimeQuery")))
@interface SLCLRuntimeQuery<__covariant RowType> : SLCLBase
- (instancetype)initWithQueries:(NSMutableArray<SLCLRuntimeQuery<id> *> *)queries mapper:(RowType (^)(id<SLCLRuntimeSqlCursor>))mapper __attribute__((swift_name("init(queries:mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener__:(id<SLCLRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener__:)")));
- (id<SLCLRuntimeSqlCursor>)execute __attribute__((swift_name("execute()")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
- (void)notifyDataChanged __attribute__((swift_name("notifyDataChanged()")));
- (void)removeListenerListener__:(id<SLCLRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener__:)")));
@property (readonly) RowType (^mapper)(id<SLCLRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end;

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol SLCLRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end;

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol SLCLRuntimeTransactionWithoutReturn <SLCLRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<SLCLRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end;

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol SLCLRuntimeTransactionWithReturn <SLCLRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<SLCLRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end;

__attribute__((swift_name("RuntimeCloseable")))
@protocol SLCLRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol SLCLRuntimeSqlDriver <SLCLRuntimeCloseable>
@required
- (SLCLRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (void)executeIdentifier:(SLCLInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<SLCLRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<SLCLRuntimeSqlCursor>)executeQueryIdentifier:(SLCLInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<SLCLRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:parameters:binders:)")));
- (SLCLRuntimeTransacterTransaction *)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
@end;

__attribute__((swift_name("RuntimeSqlDriverSchema")))
@protocol SLCLRuntimeSqlDriverSchema
@required
- (void)createDriver:(id<SLCLRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (void)migrateDriver:(id<SLCLRuntimeSqlDriver>)driver oldVersion:(int32_t)oldVersion newVersion:(int32_t)newVersion __attribute__((swift_name("migrate(driver:oldVersion:newVersion:)")));
@property (readonly) int32_t version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol SLCLKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<SLCLKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<SLCLKotlinCoroutineContextElement> _Nullable)getKey:(id<SLCLKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<SLCLKotlinCoroutineContext>)minusKeyKey:(id<SLCLKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<SLCLKotlinCoroutineContext>)plusContext:(id<SLCLKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface SLCLKotlinThrowable : SLCLBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (SLCLKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end;

__attribute__((swift_name("KotlinException")))
@interface SLCLKotlinException : SLCLKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinRuntimeException")))
@interface SLCLKotlinRuntimeException : SLCLKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinIllegalStateException")))
@interface SLCLKotlinIllegalStateException : SLCLKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinCancellationException")))
@interface SLCLKotlinCancellationException : SLCLKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface SLCLKotlinEnumCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SLCLKotlinArray<T> : SLCLBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SLCLInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SLCLKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface SLCLKotlinByteArray : SLCLBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(SLCLByte *(^)(SLCLInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SLCLKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol SLCLKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<SLCLKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SLCLKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol SLCLKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<SLCLKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<SLCLKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol SLCLKotlinx_serialization_coreKSerializer <SLCLKotlinx_serialization_coreSerializationStrategy, SLCLKotlinx_serialization_coreDeserializationStrategy>
@required
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol SLCLKotlinCoroutineContextElement <SLCLKotlinCoroutineContext>
@required
@property (readonly) id<SLCLKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol SLCLKotlinx_coroutines_coreJob <SLCLKotlinCoroutineContextElement>
@required
- (id<SLCLKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<SLCLKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(SLCLKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (SLCLKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<SLCLKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(SLCLKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<SLCLKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(SLCLKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<SLCLKotlinx_coroutines_coreJob>)plusOther:(id<SLCLKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<SLCLKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<SLCLKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface SLCLKotlinNothing : SLCLBase
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineExceptionHandler")))
@protocol SLCLKotlinx_coroutines_coreCoroutineExceptionHandler <SLCLKotlinCoroutineContextElement>
@required
- (void)handleExceptionContext:(id<SLCLKotlinCoroutineContext>)context exception:(SLCLKotlinThrowable *)exception __attribute__((swift_name("handleException(context:exception:)")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol SLCLKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface SLCLKtor_client_coreHttpClient : SLCLBase <SLCLKotlinx_coroutines_coreCoroutineScope, SLCLKtor_ioCloseable>
- (instancetype)initWithEngine:(id<SLCLKtor_client_coreHttpClientEngine>)engine userConfig:(SLCLKtor_client_coreHttpClientConfig<SLCLKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (SLCLKtor_client_coreHttpClient *)configBlock:(void (^)(SLCLKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<SLCLKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SLCLKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SLCLKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) SLCLKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) SLCLKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) SLCLKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) SLCLKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) SLCLKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) SLCLKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol SLCLKtor_client_coreHttpClientEngine <SLCLKotlinx_coroutines_coreCoroutineScope, SLCLKtor_ioCloseable>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(SLCLKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(SLCLKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(SLCLKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) SLCLKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) SLCLKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<SLCLKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol SLCLKotlinx_coroutines_coreFlow
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<SLCLKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface SLCLKotlinUnit : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinRegex")))
@interface SLCLKotlinRegex : SLCLBase
- (instancetype)initWithPattern:(NSString *)pattern __attribute__((swift_name("init(pattern:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPattern:(NSString *)pattern option:(SLCLKotlinRegexOption *)option __attribute__((swift_name("init(pattern:option:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPattern:(NSString *)pattern options:(NSSet<SLCLKotlinRegexOption *> *)options __attribute__((swift_name("init(pattern:options:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKotlinRegexCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)containsMatchInInput:(id)input __attribute__((swift_name("containsMatchIn(input:)")));
- (id<SLCLKotlinMatchResult> _Nullable)findInput:(id)input startIndex:(int32_t)startIndex __attribute__((swift_name("find(input:startIndex:)")));
- (id<SLCLKotlinSequence>)findAllInput:(id)input startIndex:(int32_t)startIndex __attribute__((swift_name("findAll(input:startIndex:)")));
- (id<SLCLKotlinMatchResult> _Nullable)matchAtInput:(id)input index:(int32_t)index __attribute__((swift_name("matchAt(input:index:)")));
- (id<SLCLKotlinMatchResult> _Nullable)matchEntireInput:(id)input __attribute__((swift_name("matchEntire(input:)")));
- (BOOL)matchesInput:(id)input __attribute__((swift_name("matches(input:)")));
- (BOOL)matchesAtInput:(id)input index:(int32_t)index __attribute__((swift_name("matchesAt(input:index:)")));
- (NSString *)replaceInput:(id)input transform:(id (^)(id<SLCLKotlinMatchResult>))transform __attribute__((swift_name("replace(input:transform:)")));
- (NSString *)replaceInput:(id)input replacement:(NSString *)replacement __attribute__((swift_name("replace(input:replacement:)")));
- (NSString *)replaceFirstInput:(id)input replacement:(NSString *)replacement __attribute__((swift_name("replaceFirst(input:replacement:)")));
- (NSArray<NSString *> *)splitInput:(id)input limit:(int32_t)limit __attribute__((swift_name("split(input:limit:)")));
- (id<SLCLKotlinSequence>)splitToSequenceInput:(id)input limit:(int32_t)limit __attribute__((swift_name("splitToSequence(input:limit:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSSet<SLCLKotlinRegexOption *> *options __attribute__((swift_name("options")));
@property (readonly) NSString *pattern __attribute__((swift_name("pattern")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinCharArray")))
@interface SLCLKotlinCharArray : SLCLBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(id (^)(SLCLInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SLCLKotlinCharIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(unichar)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol SLCLKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol SLCLKotlinSuspendFunction0 <SLCLKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface SLCLKotlinAbstractCoroutineContextElement : SLCLBase <SLCLKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<SLCLKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<SLCLKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol SLCLKotlinContinuationInterceptor <SLCLKotlinCoroutineContextElement>
@required
- (id<SLCLKotlinContinuation>)interceptContinuationContinuation:(id<SLCLKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<SLCLKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface SLCLKotlinx_coroutines_coreCoroutineDispatcher : SLCLKotlinAbstractCoroutineContextElement <SLCLKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<SLCLKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<SLCLKotlinCoroutineContext>)context block:(id<SLCLKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<SLCLKotlinCoroutineContext>)context block:(id<SLCLKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<SLCLKotlinContinuation>)interceptContinuationContinuation:(id<SLCLKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<SLCLKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (SLCLKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (SLCLKotlinx_coroutines_coreCoroutineDispatcher *)plusOther_:(SLCLKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<SLCLKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol SLCLRuntimeSqlCursor <SLCLRuntimeCloseable>
@required
- (SLCLKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (SLCLDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (SLCLLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (BOOL)next __attribute__((swift_name("next()")));
@end;

__attribute__((swift_name("RuntimeQueryListener")))
@protocol SLCLRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end;

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface SLCLRuntimeTransacterTransaction : SLCLBase <SLCLRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
- (void)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));
@property (readonly) SLCLRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end;

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol SLCLRuntimeSqlPreparedStatement
@required
- (void)bindBytesIndex:(int32_t)index bytes:(SLCLKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(SLCLDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(SLCLLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol SLCLKotlinCoroutineContextKey
@required
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol SLCLKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next_ __attribute__((swift_name("next_()")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface SLCLKotlinByteIterator : SLCLBase <SLCLKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SLCLByte *)next_ __attribute__((swift_name("next_()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol SLCLKotlinx_serialization_coreEncoder
@required
- (id<SLCLKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<SLCLKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<SLCLKotlinx_serialization_coreEncoder>)encodeInlineInlineDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)inlineDescriptor __attribute__((swift_name("encodeInline(inlineDescriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<SLCLKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<SLCLKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) SLCLKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol SLCLKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<SLCLKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<SLCLKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<SLCLKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) SLCLKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol SLCLKotlinx_serialization_coreDecoder
@required
- (id<SLCLKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<SLCLKotlinx_serialization_coreDecoder>)decodeInlineInlineDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)inlineDescriptor __attribute__((swift_name("decodeInline(inlineDescriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (SLCLKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<SLCLKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<SLCLKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) SLCLKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol SLCLKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol SLCLKotlinx_coroutines_coreChildHandle <SLCLKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(SLCLKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<SLCLKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol SLCLKotlinx_coroutines_coreChildJob <SLCLKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<SLCLKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end;

__attribute__((swift_name("KotlinSequence")))
@protocol SLCLKotlinSequence
@required
- (id<SLCLKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol SLCLKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<SLCLKotlinx_coroutines_coreSelectInstance>)select block:(id<SLCLKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface SLCLKtor_client_coreHttpClientEngineConfig : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property SLCLKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface SLCLKtor_client_coreHttpClientConfig<T> : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SLCLKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(SLCLKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<SLCLKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(SLCLKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(SLCLKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol SLCLKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol SLCLKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(SLCLKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(SLCLKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey_:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key_:)")));
- (id)takeKey:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<SLCLKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface SLCLKtor_eventsEvents : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(SLCLKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<SLCLKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(SLCLKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(SLCLKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface SLCLKtor_utilsPipeline<TSubject, TContext> : SLCLBase
- (instancetype)initWithPhase:(SLCLKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SLCLKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(SLCLKotlinArray<SLCLKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(SLCLKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(SLCLKtor_utilsPipelinePhase *)reference phase:(SLCLKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(SLCLKtor_utilsPipelinePhase *)reference phase:(SLCLKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(SLCLKtor_utilsPipelinePhase *)phase block:(id<SLCLKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<SLCLKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(SLCLKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(SLCLKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(SLCLKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(SLCLKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
@property (readonly) id<SLCLKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<SLCLKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface SLCLKtor_client_coreHttpReceivePipeline : SLCLKtor_utilsPipeline<SLCLKtor_client_coreHttpResponse *, SLCLKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(SLCLKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SLCLKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SLCLKotlinArray<SLCLKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface SLCLKtor_client_coreHttpRequestPipeline : SLCLKtor_utilsPipeline<id, SLCLKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(SLCLKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SLCLKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SLCLKotlinArray<SLCLKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface SLCLKtor_client_coreHttpResponsePipeline : SLCLKtor_utilsPipeline<SLCLKtor_client_coreHttpResponseContainer *, SLCLKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(SLCLKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SLCLKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SLCLKotlinArray<SLCLKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface SLCLKtor_client_coreHttpSendPipeline : SLCLKtor_utilsPipeline<id, SLCLKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(SLCLKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SLCLKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SLCLKotlinArray<SLCLKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface SLCLKtor_client_coreHttpRequestData : SLCLBase
- (instancetype)initWithUrl:(SLCLKtor_httpUrl *)url method:(SLCLKtor_httpHttpMethod *)method headers:(id<SLCLKtor_httpHeaders>)headers body:(SLCLKtor_httpOutgoingContent *)body executionContext:(id<SLCLKotlinx_coroutines_coreJob>)executionContext attributes:(id<SLCLKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<SLCLKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SLCLKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) SLCLKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<SLCLKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<SLCLKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) SLCLKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) SLCLKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface SLCLKtor_client_coreHttpResponseData : SLCLBase
- (instancetype)initWithStatusCode:(SLCLKtor_httpHttpStatusCode *)statusCode requestTime:(SLCLKtor_utilsGMTDate *)requestTime headers:(id<SLCLKtor_httpHeaders>)headers version:(SLCLKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<SLCLKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<SLCLKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<SLCLKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) SLCLKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) SLCLKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) SLCLKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol SLCLKotlinx_coroutines_coreFlowCollector
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinRegexOption")))
@interface SLCLKotlinRegexOption : SLCLKotlinEnum<SLCLKotlinRegexOption *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLKotlinRegexOption *ignoreCase __attribute__((swift_name("ignoreCase")));
@property (class, readonly) SLCLKotlinRegexOption *multiline __attribute__((swift_name("multiline")));
@property (class, readonly) SLCLKotlinRegexOption *literal __attribute__((swift_name("literal")));
@property (class, readonly) SLCLKotlinRegexOption *unixLines __attribute__((swift_name("unixLines")));
@property (class, readonly) SLCLKotlinRegexOption *comments __attribute__((swift_name("comments")));
@property (class, readonly) SLCLKotlinRegexOption *dotMatchesAll __attribute__((swift_name("dotMatchesAll")));
@property (class, readonly) SLCLKotlinRegexOption *canonEq __attribute__((swift_name("canonEq")));
+ (SLCLKotlinArray<SLCLKotlinRegexOption *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t mask __attribute__((swift_name("mask")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinRegex.Companion")))
@interface SLCLKotlinRegexCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinRegexCompanion *shared __attribute__((swift_name("shared")));
- (NSString *)escapeLiteral:(NSString *)literal __attribute__((swift_name("escape(literal:)")));
- (NSString *)escapeReplacementLiteral:(NSString *)literal __attribute__((swift_name("escapeReplacement(literal:)")));
- (SLCLKotlinRegex *)fromLiteralLiteral:(NSString *)literal __attribute__((swift_name("fromLiteral(literal:)")));
@end;

__attribute__((swift_name("KotlinMatchResult")))
@protocol SLCLKotlinMatchResult
@required
- (id<SLCLKotlinMatchResult> _Nullable)next_ __attribute__((swift_name("next_()")));
@property (readonly) SLCLKotlinMatchResultDestructured *destructured __attribute__((swift_name("destructured")));
@property (readonly) NSArray<NSString *> *groupValues __attribute__((swift_name("groupValues")));
@property (readonly) id<SLCLKotlinMatchGroupCollection> groups __attribute__((swift_name("groups")));
@property (readonly) SLCLKotlinIntRange *range __attribute__((swift_name("range")));
@property (readonly) NSString *value_ __attribute__((swift_name("value_")));
@end;

__attribute__((swift_name("KotlinCharIterator")))
@interface SLCLKotlinCharIterator : SLCLBase <SLCLKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id)next_ __attribute__((swift_name("next_()")));
- (unichar)nextChar __attribute__((swift_name("nextChar()")));
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol SLCLKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<SLCLKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface SLCLKotlinAbstractCoroutineContextKey<B, E> : SLCLBase <SLCLKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<SLCLKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<SLCLKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface SLCLKotlinx_coroutines_coreCoroutineDispatcherKey : SLCLKotlinAbstractCoroutineContextKey<id<SLCLKotlinContinuationInterceptor>, SLCLKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<SLCLKotlinCoroutineContextKey>)baseKey safeCast:(id<SLCLKotlinCoroutineContextElement> _Nullable (^)(id<SLCLKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol SLCLKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol SLCLKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<SLCLKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNullableSerializableElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SLCLKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SLCLKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) SLCLKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface SLCLKotlinx_serialization_coreSerializersModule : SLCLBase
- (void)dumpToCollector:(id<SLCLKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<SLCLKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<SLCLKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<SLCLKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));
- (id<SLCLKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<SLCLKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<SLCLKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<SLCLKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol SLCLKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface SLCLKotlinx_serialization_coreSerialKind : SLCLBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol SLCLKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<SLCLKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SLCLKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SLCLKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<SLCLKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) SLCLKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol SLCLKotlinx_coroutines_coreParentJob <SLCLKotlinx_coroutines_coreJob>
@required
- (SLCLKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol SLCLKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<SLCLKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(SLCLKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(SLCLKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<SLCLKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface SLCLKtor_client_coreProxyConfig : SLCLBase
- (instancetype)initWithUrl:(SLCLKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol SLCLKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(SLCLKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) SLCLKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface SLCLKtor_utilsAttributeKey<T> : SLCLBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface SLCLKtor_eventsEventDefinition<T> : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface SLCLKtor_utilsPipelinePhase : SLCLBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol SLCLKotlinSuspendFunction2 <SLCLKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface SLCLKtor_client_coreHttpReceivePipelinePhases : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) SLCLKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol SLCLKtor_httpHttpMessage
@required
@property (readonly) id<SLCLKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface SLCLKtor_client_coreHttpResponse : SLCLBase <SLCLKtor_httpHttpMessage, SLCLKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<SLCLKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) SLCLKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) SLCLKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) SLCLKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *version_ __attribute__((swift_name("version_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface SLCLKtor_client_coreHttpRequestPipelinePhases : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) SLCLKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol SLCLKtor_httpHttpMessageBuilder
@required
@property (readonly) SLCLKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface SLCLKtor_client_coreHttpRequestBuilder : SLCLBase <SLCLKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SLCLKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (SLCLKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<SLCLKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<SLCLKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<SLCLKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (SLCLKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(SLCLKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (SLCLKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(SLCLKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(SLCLKtor_httpURLBuilder *, SLCLKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<SLCLKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property SLCLKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<SLCLKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) SLCLKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property SLCLKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) SLCLKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface SLCLKtor_client_coreHttpResponsePipelinePhases : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) SLCLKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface SLCLKtor_client_coreHttpResponseContainer : SLCLBase
- (instancetype)initWithExpectedType:(SLCLKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (SLCLKtor_utilsTypeInfo *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (id)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(SLCLKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface SLCLKtor_client_coreHttpClientCall : SLCLBase <SLCLKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(SLCLKtor_client_coreHttpClient *)client requestData:(SLCLKtor_client_coreHttpRequestData *)requestData responseData:(SLCLKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(SLCLKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(SLCLKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(SLCLKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<SLCLKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<SLCLKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) SLCLKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<SLCLKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<SLCLKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property SLCLKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface SLCLKtor_client_coreHttpSendPipelinePhases : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) SLCLKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) SLCLKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface SLCLKtor_httpUrl : SLCLBase
@property (class, readonly, getter=companion) SLCLKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<SLCLKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) SLCLKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface SLCLKtor_httpHttpMethod : SLCLBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol SLCLKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<SLCLKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol SLCLKtor_httpHeaders <SLCLKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface SLCLKtor_httpOutgoingContent : SLCLBase
- (id _Nullable)getPropertyKey:(SLCLKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(SLCLKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<SLCLKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) SLCLLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) SLCLKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<SLCLKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) SLCLKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface SLCLKtor_httpHttpStatusCode : SLCLBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (SLCLKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface SLCLKtor_utilsGMTDate : SLCLBase <SLCLKotlinComparable>
@property (class, readonly, getter=companion) SLCLKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(SLCLKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (int32_t)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_utilsWeekDay *)component4 __attribute__((swift_name("component4()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component5 __attribute__((swift_name("component5()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component6 __attribute__((swift_name("component6()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_utilsMonth *)component7 __attribute__((swift_name("component7()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component8 __attribute__((swift_name("component8()"))) __attribute__((deprecated("use corresponding property instead")));
- (int64_t)component9 __attribute__((swift_name("component9()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(SLCLKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(SLCLKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) SLCLKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) SLCLKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface SLCLKtor_httpHttpProtocolVersion : SLCLBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinMatchResultDestructured")))
@interface SLCLKotlinMatchResultDestructured : SLCLBase
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component10 __attribute__((swift_name("component10()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (NSString *)component8 __attribute__((swift_name("component8()")));
- (NSString *)component9 __attribute__((swift_name("component9()")));
- (NSArray<NSString *> *)toList __attribute__((swift_name("toList()")));
@property (readonly) id<SLCLKotlinMatchResult> match __attribute__((swift_name("match")));
@end;

__attribute__((swift_name("KotlinIterable")))
@protocol SLCLKotlinIterable
@required
- (id<SLCLKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("KotlinCollection")))
@protocol SLCLKotlinCollection <SLCLKotlinIterable>
@required
- (BOOL)containsElement:(id _Nullable)element __attribute__((swift_name("contains(element:)")));
- (BOOL)containsAllElements:(id)elements __attribute__((swift_name("containsAll(elements:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("KotlinMatchGroupCollection")))
@protocol SLCLKotlinMatchGroupCollection <SLCLKotlinCollection>
@required
- (SLCLKotlinMatchGroup * _Nullable)getIndex_:(int32_t)index __attribute__((swift_name("get(index_:)")));
@end;

__attribute__((swift_name("KotlinIntProgression")))
@interface SLCLKotlinIntProgression : SLCLBase <SLCLKotlinIterable>
@property (class, readonly, getter=companion) SLCLKotlinIntProgressionCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (SLCLKotlinIntIterator *)iterator __attribute__((swift_name("iterator()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t first __attribute__((swift_name("first")));
@property (readonly) int32_t last __attribute__((swift_name("last")));
@property (readonly) int32_t step __attribute__((swift_name("step")));
@end;

__attribute__((swift_name("KotlinClosedRange")))
@protocol SLCLKotlinClosedRange
@required
- (BOOL)containsValue:(id)value __attribute__((swift_name("contains(value:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
@property (readonly) id endInclusive __attribute__((swift_name("endInclusive")));
@property (readonly, getter=start_) id start __attribute__((swift_name("start")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntRange")))
@interface SLCLKotlinIntRange : SLCLKotlinIntProgression <SLCLKotlinClosedRange>
- (instancetype)initWithStart:(int32_t)start endInclusive:(int32_t)endInclusive __attribute__((swift_name("init(start:endInclusive:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKotlinIntRangeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)containsValue:(SLCLInt *)value __attribute__((swift_name("contains(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLInt *endInclusive __attribute__((swift_name("endInclusive")));
@property (readonly, getter=start_) SLCLInt *start __attribute__((swift_name("start")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol SLCLKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<SLCLKotlinKClass>)kClass provider:(id<SLCLKotlinx_serialization_coreKSerializer> (^)(NSArray<id<SLCLKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<SLCLKotlinKClass>)kClass serializer:(id<SLCLKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<SLCLKotlinKClass>)baseClass actualClass:(id<SLCLKotlinKClass>)actualClass actualSerializer:(id<SLCLKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<SLCLKotlinKClass>)baseClass defaultDeserializerProvider:(id<SLCLKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<SLCLKotlinKClass>)baseClass defaultDeserializerProvider:(id<SLCLKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<SLCLKotlinKClass>)baseClass defaultSerializerProvider:(id<SLCLKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol SLCLKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol SLCLKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol SLCLKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol SLCLKotlinKClass <SLCLKotlinKDeclarationContainer, SLCLKotlinKAnnotatedElement, SLCLKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface SLCLKotlinx_coroutines_coreAtomicDesc : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(SLCLKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(SLCLKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property SLCLKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface SLCLKotlinx_coroutines_coreOpDescriptor : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(SLCLKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.PrepareOp")))
@interface SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp : SLCLKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next desc:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *)desc __attribute__((swift_name("init(affected:next:desc:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) SLCLKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *next __attribute__((swift_name("next")));
@end;

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol SLCLKtor_ioByteReadChannel
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(completionHandler:)")));
- (BOOL)cancelCause_:(SLCLKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)discardMax:(int64_t)max completionHandler:(void (^)(SLCLLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("discard(max:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)peekToDestination:(SLCLKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max completionHandler:(void (^)(SLCLLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(SLCLKtor_ioChunkBuffer *)dst completionHandler:(void (^)(SLCLInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(SLCLKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(SLCLInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler:)")));
- (int32_t)readAvailableMin:(int32_t)min block:(void (^)(SLCLKtor_ioBuffer *))block __attribute__((swift_name("readAvailable(min:block:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(SLCLInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(SLCLInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler__:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBooleanWithCompletionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBoolean(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readByteWithCompletionHandler:(void (^)(SLCLByte * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readByte(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readDoubleWithCompletionHandler:(void (^)(SLCLDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readDouble(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFloatWithCompletionHandler:(void (^)(SLCLFloat * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFloat(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(SLCLKtor_ioChunkBuffer *)dst n:(int32_t)n completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:n:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(SLCLKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler__:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readIntWithCompletionHandler:(void (^)(SLCLInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readInt(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readLongWithCompletionHandler:(void (^)(SLCLLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readLong(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readPacketSize:(int32_t)size completionHandler:(void (^)(SLCLKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readPacket(size:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readRemainingLimit:(int64_t)limit completionHandler:(void (^)(SLCLKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readRemaining(limit:completionHandler:)")));
- (void)readSessionConsumer:(void (^)(id<SLCLKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readShortWithCompletionHandler:(void (^)(SLCLShort * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readShort(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readSuspendableSessionConsumer:(id<SLCLKotlinSuspendFunction1>)consumer completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readSuspendableSession(consumer:completionHandler:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineLimit:(int32_t)limit completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8Line(limit:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineToOut:(id<SLCLKotlinAppendable>)out limit:(int32_t)limit completionHandler:(void (^)(SLCLBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8LineTo(out:limit:completionHandler:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) SLCLKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol SLCLKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<SLCLKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<SLCLKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<SLCLKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<SLCLKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface SLCLKtor_utilsStringValuesBuilderImpl : SLCLBase <SLCLKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<SLCLKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<SLCLKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<SLCLKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<SLCLKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@property (readonly) SLCLMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface SLCLKtor_httpHeadersBuilder : SLCLKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<SLCLKtor_httpHeaders>)build __attribute__((swift_name("build()")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface SLCLKtor_client_coreHttpRequestBuilderCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface SLCLKtor_httpURLBuilder : SLCLBase
- (instancetype)initWithProtocol:(SLCLKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<SLCLKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (SLCLKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<SLCLKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<SLCLKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property SLCLKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface SLCLKtor_utilsTypeInfo : SLCLBase
- (instancetype)initWithType:(id<SLCLKotlinKClass>)type reifiedType:(id<SLCLKotlinKType>)reifiedType kotlinType:(id<SLCLKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (id<SLCLKotlinKClass>)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (id<SLCLKotlinKType>)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (id<SLCLKotlinKType> _Nullable)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_utilsTypeInfo *)doCopyType:(id<SLCLKotlinKClass>)type reifiedType:(id<SLCLKotlinKType>)reifiedType kotlinType:(id<SLCLKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SLCLKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<SLCLKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<SLCLKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface SLCLKtor_client_coreHttpClientCallCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_utilsAttributeKey<id> *CustomResponse __attribute__((swift_name("CustomResponse"))) __attribute__((unavailable("This is going to be removed. Please file a ticket with clarification why and what for do you need it.")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol SLCLKtor_client_coreHttpRequest <SLCLKtor_httpHttpMessage, SLCLKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<SLCLKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) SLCLKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) SLCLKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) SLCLKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) SLCLKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface SLCLKtor_httpUrlCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol SLCLKtor_httpParameters <SLCLKtor_utilsStringValues>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface SLCLKtor_httpURLProtocol : SLCLBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (int32_t)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface SLCLKtor_httpHttpMethodCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<SLCLKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) SLCLKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) SLCLKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) SLCLKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) SLCLKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) SLCLKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) SLCLKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) SLCLKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol SLCLKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value_ __attribute__((swift_name("value_")));
@end;

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface SLCLKtor_httpHeaderValueWithParameters : SLCLBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<SLCLKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<SLCLKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface SLCLKtor_httpContentType : SLCLKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<SLCLKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<SLCLKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(SLCLKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (SLCLKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (SLCLKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface SLCLKtor_httpHttpStatusCodeCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) SLCLKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) SLCLKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) SLCLKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) SLCLKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) SLCLKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) SLCLKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) SLCLKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) SLCLKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) SLCLKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) SLCLKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) SLCLKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) SLCLKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) SLCLKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) SLCLKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) SLCLKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) SLCLKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) SLCLKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) SLCLKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) SLCLKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) SLCLKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) SLCLKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) SLCLKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) SLCLKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) SLCLKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) SLCLKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) SLCLKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) SLCLKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) SLCLKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) SLCLKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) SLCLKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) SLCLKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) SLCLKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) SLCLKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) SLCLKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) SLCLKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) SLCLKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) SLCLKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) SLCLKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) SLCLKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) SLCLKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) SLCLKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) SLCLKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) SLCLKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<SLCLKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface SLCLKtor_utilsGMTDateCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface SLCLKtor_utilsWeekDay : SLCLKotlinEnum<SLCLKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) SLCLKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) SLCLKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) SLCLKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) SLCLKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) SLCLKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) SLCLKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (SLCLKotlinArray<SLCLKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface SLCLKtor_utilsMonth : SLCLKotlinEnum<SLCLKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SLCLKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) SLCLKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) SLCLKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) SLCLKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) SLCLKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) SLCLKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) SLCLKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) SLCLKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) SLCLKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) SLCLKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) SLCLKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) SLCLKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (SLCLKotlinArray<SLCLKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface SLCLKtor_httpHttpProtocolVersionCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (SLCLKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) SLCLKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinMatchGroup")))
@interface SLCLKotlinMatchGroup : SLCLBase
- (instancetype)initWithValue:(NSString *)value range:(SLCLKotlinIntRange *)range __attribute__((swift_name("init(value:range:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKotlinIntRange *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKotlinMatchGroup *)doCopyValue:(NSString *)value range:(SLCLKotlinIntRange *)range __attribute__((swift_name("doCopy(value:range:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SLCLKotlinIntRange *range __attribute__((swift_name("range")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntProgression.Companion")))
@interface SLCLKotlinIntProgressionCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinIntProgressionCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKotlinIntProgression *)fromClosedRangeRangeStart:(int32_t)rangeStart rangeEnd:(int32_t)rangeEnd step:(int32_t)step __attribute__((swift_name("fromClosedRange(rangeStart:rangeEnd:step:)")));
@end;

__attribute__((swift_name("KotlinIntIterator")))
@interface SLCLKotlinIntIterator : SLCLBase <SLCLKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SLCLInt *)next_ __attribute__((swift_name("next_()")));
- (int32_t)nextInt __attribute__((swift_name("nextInt()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntRange.Companion")))
@interface SLCLKotlinIntRangeCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinIntRangeCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKotlinIntRange *EMPTY __attribute__((swift_name("EMPTY")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface SLCLKotlinx_coroutines_coreAtomicOp<__contravariant T> : SLCLKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) SLCLKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) id _Nullable consensus __attribute__((swift_name("consensus")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode")))
@interface SLCLKotlinx_coroutines_coreLockFreeLinkedListNode : SLCLBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)node condition:(SLCLBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(SLCLBoolean *(^)(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(SLCLBoolean *(^)(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate condition:(SLCLBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeAddLastNode:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("describeAddLast(node:)")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeRemoveFirst __attribute__((swift_name("describeRemoveFirst()")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)nextIfRemoved __attribute__((swift_name("nextIfRemoved()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(SLCLBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly, getter=next__) id next __attribute__((swift_name("next")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.AbstractAtomicDesc")))
@interface SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc : SLCLKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(SLCLKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)failureAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (id _Nullable)onPreparePrepareOp:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (void)onRemovedAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("onRemoved(affected:)")));
- (id _Nullable)prepareOp:(SLCLKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
- (BOOL)retryAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(SLCLKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface SLCLKtor_ioMemory : SLCLBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_ioMemoryCompanion *companion __attribute__((swift_name("companion")));
- (void)doCopyToDestination:(SLCLKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(SLCLKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (SLCLKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (SLCLKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end;

__attribute__((swift_name("Ktor_ioBuffer")))
@interface SLCLKtor_ioBuffer : SLCLBase
- (instancetype)initWithMemory:(SLCLKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_ioBufferCompanion *companion __attribute__((swift_name("companion")));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (SLCLKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)duplicateToCopy:(SLCLKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) SLCLKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end;

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface SLCLKtor_ioChunkBuffer : SLCLKtor_ioBuffer
- (instancetype)initWithMemory:(SLCLKtor_ioMemory *)memory origin:(SLCLKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<SLCLKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMemory:(SLCLKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_ioChunkBufferCompanion *companion __attribute__((swift_name("companion")));
- (SLCLKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (SLCLKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<SLCLKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next__) SLCLKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) SLCLKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end;

__attribute__((swift_name("Ktor_ioInput")))
@interface SLCLKtor_ioInput : SLCLBase <SLCLKtor_ioCloseable>
- (instancetype)initWithHead:(SLCLKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<SLCLKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKtor_ioInputCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)canRead __attribute__((swift_name("canRead()")));
- (void)close __attribute__((swift_name("close()")));
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (void)discardExactN:(int32_t)n __attribute__((swift_name("discardExact(n:)")));
- (SLCLKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));
- (int32_t)fillDestination:(SLCLKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (BOOL)hasBytesN:(int32_t)n __attribute__((swift_name("hasBytes(n:)")));
- (void)markNoMoreChunksAvailable __attribute__((swift_name("markNoMoreChunksAvailable()")));
- (int64_t)peekToDestination:(SLCLKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)peekToBuffer:(SLCLKtor_ioChunkBuffer *)buffer __attribute__((swift_name("peekTo(buffer:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (NSString *)readTextMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(min:max:)")));
- (int32_t)readTextOut:(id<SLCLKotlinAppendable>)out min:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(out:min:max:)")));
- (NSString *)readTextExactExactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(exactCharacters:)")));
- (void)readTextExactOut:(id<SLCLKotlinAppendable>)out exactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(out:exactCharacters:)")));
- (void)release_ __attribute__((swift_name("release()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@property (readonly) id<SLCLKtor_ioObjectPool> pool __attribute__((swift_name("pool")));
@property (readonly) int64_t remaining __attribute__((swift_name("remaining")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket")))
@interface SLCLKtor_ioByteReadPacket : SLCLKtor_ioInput
- (instancetype)initWithHead:(SLCLKtor_ioChunkBuffer *)head pool:(id<SLCLKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:pool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHead:(SLCLKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<SLCLKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SLCLKtor_ioByteReadPacketCompanion *companion __attribute__((swift_name("companion")));
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (SLCLKtor_ioByteReadPacket *)doCopy __attribute__((swift_name("doCopy()")));
- (SLCLKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));
- (int32_t)fillDestination:(SLCLKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol SLCLKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (SLCLKtor_ioChunkBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end;

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol SLCLKotlinSuspendFunction1 <SLCLKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface SLCLKtor_httpURLBuilderCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol SLCLKtor_httpParametersBuilder <SLCLKtor_utilsStringValuesBuilder>
@required
@end;

__attribute__((swift_name("KotlinKType")))
@protocol SLCLKotlinKType
@required
@property (readonly) NSArray<SLCLKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) id<SLCLKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface SLCLKtor_httpURLProtocolCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) SLCLKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) SLCLKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) SLCLKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) SLCLKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) SLCLKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, SLCLKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface SLCLKtor_httpHeaderValueParam : SLCLBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (NSString *)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (BOOL)component3 __attribute__((swift_name("component3()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface SLCLKtor_httpHeaderValueWithParametersCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<SLCLKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface SLCLKtor_httpContentTypeCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) SLCLKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface SLCLKtor_utilsWeekDayCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (SLCLKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface SLCLKtor_utilsMonthCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (SLCLKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc")))
@interface SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T> : SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)queue node:(T)node __attribute__((swift_name("init(queue:node:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishOnSuccessAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (BOOL)retryAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(SLCLKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) T node __attribute__((swift_name("node")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *originalNext __attribute__((swift_name("originalNext")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc")))
@interface SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T> : SLCLKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)queue __attribute__((swift_name("init(queue:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (id _Nullable)failureAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (BOOL)retryAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(SLCLKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@property (readonly) SLCLKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@property (readonly) T _Nullable result __attribute__((swift_name("result")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory.Companion")))
@interface SLCLKtor_ioMemoryCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_ioMemoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_ioMemory *Empty __attribute__((swift_name("Empty")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioBuffer.Companion")))
@interface SLCLKtor_ioBufferCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_ioBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_ioBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end;

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol SLCLKtor_ioObjectPool <SLCLKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioChunkBuffer.Companion")))
@interface SLCLKtor_ioChunkBufferCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_ioChunkBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_ioChunkBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<SLCLKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<SLCLKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioInput.Companion")))
@interface SLCLKtor_ioInputCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_ioInputCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket.Companion")))
@interface SLCLKtor_ioByteReadPacketCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKtor_ioByteReadPacketCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SLCLKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface SLCLKotlinKTypeProjection : SLCLBase
- (instancetype)initWithVariance:(SLCLKotlinKVariance * _Nullable)variance type:(id<SLCLKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SLCLKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (SLCLKotlinKVariance * _Nullable)component1 __attribute__((swift_name("component1()"))) __attribute__((deprecated("use corresponding property instead")));
- (id<SLCLKotlinKType> _Nullable)component2 __attribute__((swift_name("component2()"))) __attribute__((deprecated("use corresponding property instead")));
- (SLCLKotlinKTypeProjection *)doCopyVariance:(SLCLKotlinKVariance * _Nullable)variance type:(id<SLCLKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SLCLKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) SLCLKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface SLCLKotlinKVariance : SLCLKotlinEnum<SLCLKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SLCLKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) SLCLKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) SLCLKotlinKVariance *out __attribute__((swift_name("out")));
+ (SLCLKotlinArray<SLCLKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface SLCLKotlinKTypeProjectionCompanion : SLCLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SLCLKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));
- (SLCLKotlinKTypeProjection *)contravariantType:(id<SLCLKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));
- (SLCLKotlinKTypeProjection *)covariantType:(id<SLCLKotlinKType>)type __attribute__((swift_name("covariant(type:)")));
- (SLCLKotlinKTypeProjection *)invariantType:(id<SLCLKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) SLCLKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end;

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
